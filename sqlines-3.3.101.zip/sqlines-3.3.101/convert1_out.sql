-- DROP USER XDB;

CREATE USER XDB
-- SQLINES DEMO *** ssword>
;

CREATE OR REPLACE TYPE XDB."ChildNameCollTyp" AS VARRAY(2147483647) OF VARCHAR2(4000 CHAR);

CREATE OR REPLACE TYPE XDB."ContainerStatsTyp" AS OBJECT (`SYS_XDBPD$` "XDB$RAW_LIST_T",`RESOID` VARBINARY(32),`TotalRows` DOUBLE,`TotalContainers` DOUBLE,`FanOut` DECIMAL(38),`ImmediateContainers` DECIMAL(38),`LastAnalyzedDate` DATETIME(6))FINAL INSTANTIABLE ;

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_RESMD FORCE as OBJECT (
        path_name varchar2(4000),
	path_oid raw(16)
);

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_RESMDARR AS VARRAY(65536) OF xdb.DBMS_XMLSCHEMA_RESMD;

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_TABMD FORCE as OBJECT (
        schema_name  varchar2(700),
	element_name varchar2(128),
	table_name   varchar2(128),
	table_oid    raw(16)
);

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_TABMDARR AS VARRAY(65536) OF xdb.DBMS_XMLSCHEMA_TABMD;

CREATE OR REPLACE TYPE XDB."FolderListingTyp" AS OBJECT (`SYS_XDBPD$` "XDB$RAW_LIST_T",`name` VARCHAR(4000),`size` DECIMAL(38),`ChildName` "ChildNameCollTyp")NOT FINAL INSTANTIABLE ;

CREATE OR REPLACE type XDB.funcstats
                                      
authid definer as object
(
  -- SQLINES DEMO *** tion cost and selectivity functions
  j number,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
    returns doubleDECLARE ,

  -- SQLINES DEMO *** ct index statistics
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsCollect(ia sys.ODCIIndexInfo,
                                   options sys.ODCIStatsOptions,
                                   statistics OUT VARBINARY,
                                   env sys.ODCIEnv)
  returns double
  begin declare language C
  name
//

delimiter ;


//

delimiter ;

 `STATSCOLL_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    options,
    options INDICATOR STRUCT,
    statistics,
    statistics INDICATOR,
    statistics LENGTH,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  -- SQLINES DEMO ***  index statistics
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsDelete(ia sys.ODCIIndexInfo,
                                  statistics OUT VARBINARY,
                                  env sys.ODCIEnv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSDEL_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    statistics,
    statistics INDICATOR,
    statistics LENGTH,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  -- index cost
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsIndexCost(ia sys.ODCIIndexInfo,
                                     sel double,
                                     cost OUT sys.ODCICost,
                                     qi sys.ODCIQueryInfo,
                                     pred sys.ODCIPredInfo,
                                     args sys.ODCIArgDescList,
                                     strt double,
                                     stop double,
                                     depth double,
                                     valarg varchar(4000),
                                     env sys.ODCIenv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSINDCOST_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    cost,
    cost INDICATOR STRUCT,
    qi,
    qi INDICATOR STRUCT,
    pred,
    pred INDICATOR STRUCT,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    depth,
    depth INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsIndexCost(ia sys.ODCIIndexInfo,
                                     sel double,
                                     cost OUT sys.ODCICost,
                                     qi sys.ODCIQueryInfo,
                                     pred sys.ODCIPredInfo,
                                     args sys.ODCIArgDescList,
                                     strt double,
                                     stop double,
                                     valarg varchar(4000),
                                     env sys.ODCIenv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSINDCOST1_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    cost,
    cost INDICATOR STRUCT,
    qi,
    qi INDICATOR STRUCT,
    pred,
    pred INDICATOR STRUCT,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  -- function cost

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsFunctionCost(func sys.ODCIFuncInfo,
                                        cost OUT sys.ODCICost,
                                        args sys.ODCIArgDescList,
                                        colval longtext,
                                        depth double,
                                        valarg varchar(4000),
                                        env  sys.ODCIEnv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSFUNCCOST_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    func,
    func INDICATOR STRUCT,
    cost,
    cost INDICATOR STRUCT,
    args,
    args INDICATOR,
    colval,
    colval INDICATOR,
    depth,
    depth INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsFunctionCost(func sys.ODCIFuncInfo,
                                        cost OUT sys.ODCICost,
                                        args sys.ODCIArgDescList,
                                        colval longtext,
                                        valarg varchar(4000),
                                        env  sys.ODCIEnv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSFUNCCOST1_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    func,
    func INDICATOR STRUCT,
    cost,
    cost INDICATOR STRUCT,
    args,
    args INDICATOR,
    colval,
    colval INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

   static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsSelectivity(pred sys.ODCIPredInfo,
                                        sel OUT double,
                                        args sys.ODCIArgDescList,
                                        strt double,
                                        stop double,
                                        colval longtext,
                                        depth double,
                                        valarg varchar(4000),
                                       env sys.ODCIenv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSSEL_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    pred,
    pred INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    colval,
    colval INDICATOR,
    depth,
    depth INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

 -- SQLINES DEMO *** nder_path_func1
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsSelectivity(pred sys.ODCIPredInfo,
                                       sel OUT double,
                                       args sys.ODCIArgDescList,
                                       strt double,
                                       stop double,
                                       colval longtext,
                                       valarg varchar(4000),
                                       env sys.ODCIenv)
  returns double
  begin declare language C
  name
//

delimiter ;

 `STATSSEL1_XDBHI`
  library XDB.RESOURCE_VIEW_LIB
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  with context
  parameters (
    context,
    pred,
    pred INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    colval,
    colval INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber)
);

CREATE OR REPLACE type XDB.LockTokenListType as varray(2147483647) of VARCHAR2(128);

CREATE OR REPLACE type XDB.path_array                                       
as varray(32000) of xdb.path_linkinfo;

CREATE OR REPLACE type XDB.path_linkinfo                                        wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
79 aa
g0V6zG8egE2xYLkdFQIyNY27Wowwg5n0dLhcFlpW+uNy+kfZ/0cM2cHAdCulv5vAMsvuJY8J
aee4dAhpqal8xsoXKMbK77KEHe+2RC9eXltNFTFq68aVcrOxlKEC9yaI5jWpC8gKD1o0nbBt
5sgLU0BrWBucGx2mqUqkyQ==
;

CREATE OR REPLACE type XDB.token force as object (qnameid raw(8),
                                                  localname varchar(2000),
                                                  nmspcid raw(8))
NOT PERSISTABLE;

CREATE OR REPLACE type XDB.TokenIDs force is varray(10000) of(raw(8))
NOT PERSISTABLE;

CREATE OR REPLACE type XDB.Tokens force is varray(10000) of(xdb.token)
NOT PERSISTABLE;

CREATE OR REPLACE type XDB.xdb$annotation_list_t                                        as
   varray(65535) of xdb.xdb$annotation_t;

CREATE OR REPLACE type XDB.xdb$annotation_t                                        as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  appinfo         xdb.xdb$appinfo_list_t,
  documentation   xdb.xdb$documentation_list_t
)
 alter type     xdb$annotation_t add attribute (id varchar2(128)) cascade;

CREATE OR REPLACE type XDB.xdb$any_t                                        as object
(
  property         xdb.xdb$property_t,
  namespace        varchar(2000),
  process_contents xdb.xdb$processChoice,
  min_occurs       integer,
  max_occurs       varchar(20)   /* SQLINES DEMO *** incl. "unbounded" */
);

CREATE OR REPLACE type XDB.xdb$appinfo_list_t                                        as varray(1000) of xdb.xdb$appinfo_t;

CREATE OR REPLACE type XDB.xdb$appinfo_t                                       
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  anypart         varchar(4000),
  source          varchar(4000)
);

CREATE OR REPLACE type XDB.xdb$attrgroup_def_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    name            varchar(2000),               /* SQLINES DEMO *** group */

    attributes      xdb.xdb$xmltype_ref_list_t,  /* SQLINES DEMO *** hin group */
    any_attrs       xdb.xdb$xmltype_ref_list_t,  /* SQLINES DEMO *** ute decls. */
    attr_groups     xdb.xdb$xmltype_ref_list_t,          /* SQLINES DEMO *** ps */

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$attrgroup_ref_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,

    attrgroup_name  xdb.xdb$qname,   /* SQLINES DEMO *** bute group being ref-ed */
    attrgroup_ref   ref sys.xmltype,   /* SQLINES DEMO *** roup being ref-ed */

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$complex_derivation_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base            xdb.xdb$qname,

    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,

    /* SQLINES DEMO *** of the foll. can be non-null
     */
    all_kid         ref sys.xmltype,
    choice_kid      ref sys.xmltype,
    sequence_kid    ref sys.xmltype,
    group_kid       ref sys.xmltype,

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$complex_t
                                      
AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    base_type       ref sys.xmltype,      /* SQLINES DEMO *** rived types */
    name            varchar(256),
    abstract        varbinary(1),
    mixed           varbinary(1),
    final_info      xdb.xdb$derivationChoice,
    block           xdb.xdb$derivationChoice,

    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,

    /* SQLINES DEMO *** of the foll. can be non-null, else all have to be null.
     */
    all_kid         ref sys.xmltype,
    choice_kid      ref sys.xmltype,
    sequence_kid    ref sys.xmltype,
    group_kid       ref sys.xmltype,

    complexcontent  xdb.xdb$content_t,

    annotation      xdb.xdb$annotation_t,

    sqltype         varchar(30),                 /* SQLINES DEMO ***  type */
    sqlschema       varchar(30),     /* SQLINES DEMO *** ntaining SQL type */
    maintain_dom    varbinary(1),
    subtype_refs    xdb.xdb$xmltype_ref_list_t,     /* SQLINES DEMO *** ubtypes */
    id              varchar(256),
    simplecont      xdb.xdb$simplecontent_t,
    typeid          integer
)
 alter type     xdb$complex_t modify attribute
(sqltype varchar2(128), sqlschema varchar2(128)) cascade;

CREATE OR REPLACE type XDB.xdb$content_t                                       
as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    mixed           varbinary(1),

    /* SQLINES DEMO *** oll. can be non-null */
    restriction     xdb.xdb$complex_derivation_t,
    extension       xdb.xdb$complex_derivation_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$derivationChoice
                                       as object
(
    value       varbinary(2),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$documentation_list_t                                       
  as varray(1000) of xdb.xdb$documentation_t;

CREATE OR REPLACE type XDB.xdb$documentation_t                                        as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  anypart         varchar(4000),
  source          varchar(4000),
  lang            varchar(4000)
);

CREATE OR REPLACE type XDB.xdb$element_t                                       
as object
(
    property        xdb.xdb$property_t,
    subs_group      xdb.xdb$qname,
    num_cols        integer,
    nillable        varbinary(1),
    final_info      xdb.xdb$derivationChoice,
    block           xdb.xdb$derivationChoice,
    abstract        varbinary(1),
/* XDB extensions */
    mem_inline      varbinary(1),
    sql_inline      varbinary(1),
    java_inline     varbinary(1),
    maintain_dom    varbinary(1),
    default_table   varchar(30),
    default_table_schema   varchar(30),
    table_props     varchar(2000),              /* SQLINES DEMO *** string */
    java_classname  varchar(2000),
    bean_classname  varchar(2000),
    base_sqlname    varchar(61),
    cplx_type_decl  ref sys.xmltype,
    subs_group_refs xdb.xdb$xmltype_ref_list_t, /* SQLINES DEMO *** nts for which
                                             * this is the head element
                                             */
    default_xsl     varchar(2000),     /* SQLINES DEMO *** L to be applied */
    min_occurs      integer,
    max_occurs      varchar(20),     /* SQLINES DEMO *** incl. "unbounded" */
    is_folder       varbinary(1),
    maintain_order  varbinary(1),
    col_props       varchar(2000),             /* SQLINES DEMO ***  string */
    default_acl     varchar(2000),                   /* SQLINES DEMO *** L */
    head_elem_ref  ref sys.xmltype,    /* SQLINES DEMO *** nt of subs. group */
    uniques        xdb.xdb$keybase_list_t,
    keys           xdb.xdb$keybase_list_t,
    keyrefs        xdb.xdb$keybase_list_t,
    is_translatable varbinary(1),                  /* SQLINES DEMO *** ranslatable */
    xdb_max_occurs  varchar(20)                            /* xdb:maxOccurs */
)
 alter type     xdb$element_t modify attribute
(default_table          varchar2(128),
 default_table_schema   varchar2(128)
) cascade;

CREATE OR REPLACE type XDB.xdb$enum_t                                       
as object
(
    value       varbinary(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$enum_values_t                                       
as VARRAY(1000) of varchar2(1024);

CREATE OR REPLACE type XDB.xdb$enum2_t                                       
as object
(
    value       varbinary(2),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$extra_list_t                                        as varray(65535) of varchar2(2000);

CREATE OR REPLACE type XDB.xdb$facet_list_t                                        as
VARRAY(65535) of xdb.xdb$facet_t;

CREATE OR REPLACE type XDB.xdb$facet_t                                       
as object                 /* String Facet */
(
   sys_xdbpd$       xdb.xdb$raw_list_t,
   annotation       xdb.xdb$annotation_t,
   value            varchar(2000),
   fixed            varbinary(1),
   id               varchar(256)
);

CREATE OR REPLACE type XDB.xdb$formChoice                                       
as object
(
    value       varbinary(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$group_def_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    name            varchar(2000),                /* SQLINES DEMO ***  */
    /* SQLINES DEMO *** of the foll. can be non-null
     */
    all_kid         ref sys.xmltype,
    choice_kid      ref sys.xmltype,
    sequence_kid    ref sys.xmltype,

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$group_ref_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    min_occurs      integer,
    max_occurs      varchar(20), /* SQLINES DEMO *** incl. "unbounded" */

    groupref_name   xdb.xdb$qname,       /* SQLINES DEMO ***  being referenced */
    groupref_ref    ref sys.xmltype,   /* SQLINES DEMO *** being referenced */

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdbhi_im                                        wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
d2d 37c
GpQKlAFO+SClOmqzj4QxCI/Whzowg82nDNATfC/GEoteXzOiFKAJEuV3twsbr5S02AD/hkbD
gVAA0hnQDwU03zRv363RCTYzX8EITiy2RafntT+1kk6j7fnwpnVjWRrdOzwWJsI5KnwdJ7W2
rZX/r7gbrUzdTOyQhruYFJsD21q4V1QXtvKs8r5XZr2hTShfjDdUXRUvFgxw4osx2nc1c9LL
IfE90xpiM00XhJ5YBgL2kUYtcEwOfGJdNWxpZUwEV3/XguidbPNGmUMmx59y2gRd1pVGVr9M
Vou2ZSHfWZi4AnWNxYToYRhSkC4OsvUJO5dYowezjFJ9AS/me61QWfXNkev7qUqp2070Qziv
Y4X6+nlxhaf5PLFLY0Y2dxNjE57yf8aTrdxnzEKSacoeTmQuqlt0uuiKhwQKjgOTmB7VmLBL
+0URhtkedNwF1E9k1/fAof5yuZz08o5zuipVAsWYMQkLo66840iblVG8QDHfSqgupCKE0Wfa
Wi0a2P2NX2XB2gg/ncfC30gVZ/9ds8Lv4Vv6nkawUPaUIxKscYoq67FQ4mCM2ItUkDZB1Rfe
rG4CCuPV/qG+yCS/TI6/QEWWDLoMCx6Yx3YgOcsnxVfvYxDBp/7irGwc/NhMjfu72HPpNiUD
nyh7JlK/IgCirrzumrq6C2q8mkZ2Q/fCP3qHCSBBBgafeMZKNS0/mReZIJ8DbQ0S46ksGppC
OkpE2m/8d8QykIedP54zLaxzTcuZ0nK2e3rKCFano5AusL2/hRMTtU9IFbU6fgWj+ecSsD6T
Rln20C0B6aDAERrefCQUgXlADH2WJiCE5bwFGryyLrtQGePswZfK2yyMH28kpxn9n5l94dZi
L1FV0Ja1+2mSgGI=
;

CREATE OR REPLACE type XDB.xdb$import_list_t                                        as varray(65535) of xdb.xdb$import_t;

CREATE OR REPLACE type XDB.xdb$import_t                                       
as object
(
    sys_xdbpd$          xdb.xdb$raw_list_t,
    namespace           varchar(700),
    schema_location     varchar(700),
    annotation          xdb.xdb$annotation_t,
    id                  varchar(256)
);

CREATE OR REPLACE type XDB.xdb$include_list_t                                        as varray(65535) of xdb.xdb$include_t;

CREATE OR REPLACE type XDB.xdb$include_t                                       
as object
(
    sys_xdbpd$          xdb.xdb$raw_list_t,
    schema_location     varchar(700),
    annotation          xdb.xdb$annotation_t,
    id                  varchar(256)
);

CREATE OR REPLACE type XDB.xdb$javatype                                       
as object
(
    value       varbinary(2),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$keybase_list_t
                                      
as varray(1000) of xdb.xdb$keybase_t;

CREATE OR REPLACE type XDB.xdb$keybase_t
                                      
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  annotation      xdb.xdb$annotation_t,
  name            varchar(1000),               /* SQLINES DEMO *** y/keyref */
  refer           xdb.xdb$qname,             /* SQLINES DEMO *** or "keyref" */
  selector        xdb.xdb$xpathspec_t,
  fields          xdb.xdb$xpathspec_list_t
);

CREATE OR REPLACE type XDB.xdb$link_t                                        AS OBJECT
(
    parent_oid    varbinary(16),
    child_oid     varbinary(16),
    name          varchar(256),
    flags         varbinary(4),
    link_sn       varbinary(16),
    child_acloid  varbinary(16),
    child_ownerid varbinary(16),
    parent_rids   varbinary(2000)
);

CREATE OR REPLACE TYPE XDB."XDB_LINK_TYPE" AS OBJECT (`SYS_XDBPD$` "XDB$RAW_LIST_T",`ParentName` VARCHAR(256),`ChildName` VARCHAR(1024),`Name` VARCHAR(256),`Flags` VARBINARY(4),`ParentOid` VARBINARY(16),`ChildOid` VARBINARY(16),`LinkType` "XDB$ENUM_T")FINAL INSTANTIABLE ;

CREATE OR REPLACE type XDB.xdb$list_t                                        as
object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    item_type       xdb.xdb$qname,                               /* item of list */
    type_ref        ref sys.xmltype,          /* SQLINES DEMO *** st item type */
    simple_type     ref sys.xmltype            /* SQLINES DEMO *** simple type */
);

CREATE OR REPLACE type XDB.xdb$model_t                                        as
object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    min_occurs      integer,
    max_occurs      varchar(20), /* SQLINES DEMO *** incl. "unbounded" */

    elements        xdb.xdb$xmltype_ref_list_t,
    choice_kids     xdb.xdb$xmltype_ref_list_t,
    sequence_kids   xdb.xdb$xmltype_ref_list_t,
    anys            xdb.xdb$xmltype_ref_list_t,
    groups          xdb.xdb$xmltype_ref_list_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$nlocks_t                                       
 AS OBJECT
(
    PARENT_OID  VARBINARY(16),
    CHILD_NAME  VARCHAR(256),
    RAWTOKEN    VARBINARY(18)
);

CREATE OR REPLACE type XDB.xdb$notation_list_t
                                      
as varray(1000) of xdb.xdb$notation_t;

CREATE OR REPLACE type XDB.xdb$notation_t
                                      
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  annotation      xdb.xdb$annotation_t,
  name            varchar(2000),                    /* SQLINES DEMO *** ion */
  publicval       varchar(4000),
  system          varchar(4000)
);

CREATE OR REPLACE type XDB.xdb$numfacet_t                                       
as object              /* Number Facet */
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    value           integer,
    fixed           varbinary(1),
    id              varchar(256)
);

CREATE OR REPLACE type XDB.XDB$OID_LIST_T                                        AS varray(65535) of raw(16);

CREATE OR REPLACE type XDB.xdbpi_im                                       
   authid definer as object(
  notused    RAW(4),


  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIGetInterfaces (ilist OUT sys.ODCIObjectList) returns doubleDECLARE ,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexCreate(ia sys.odciindexinfo, parms varchar(4000),
      env sys.odcienv)  returns doubleDECLARE ,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexDrop(ia sys.odciindexinfo, env sys.ODCIEnv)
    returns doubleDECLARE ,

  STATIC -- SQLINES LICENSE FOR EVALUATION USE ONLY
DELIMITER //

CREATE   FUNCTION ODCIIndexTruncate(ia sys.odciindexinfo, env sys.ODCIEnv)
    RETURNS DOUBLEDECLARE ,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexInsert(ia sys.odciindexinfo, rid varchar(4000),
        newval sys.xmltype, env sys.ODCIEnv) returns doubleDECLARE ,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexDelete(ia sys.odciindexinfo, rid varchar(4000),
    oldval sys.xmltype, env sys.ODCIEnv) returns doubleDECLARE ,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexUpdate(ia sys.odciindexinfo, rid varchar(4000),
    oldval sys.xmltype, newval sys.xmltype, env sys.ODCIEnv)
    returns doubleDECLARE ,

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexStart(sctx OUT xdb.xdbpi_im,
      ia sys.odciindexinfo, op sys.odcipredinfo, qi sys.odciqueryinfo,
      strt double, stop double, pathstr varchar(4000), env sys.odcienv)
      returns doubleDECLARE ,

  member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexFetch(nrows double, rids OUT sys.odciridlist,
     env sys.odcienv) returns doubleDECLARE ,

  member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexClose (env sys.odcienv) returns double
DECLARE );

CREATE OR REPLACE type XDB.XDB$PREDECESSOR_LIST_T                                        AS
//

delimiter ;


//

delimiter ;


//

delimiter ;


//

delimiter ;


//

delimiter ;


//

delimiter ;


//

DELIMITER ;


//

delimiter ;


//

delimiter ;


//

delimiter ;

 varray(1000) of raw(16);

CREATE OR REPLACE type XDB.xdb_privileges                                       
as varray(1000) of VARCHAR2(200);

CREATE OR REPLACE type XDB.xdb$processChoice                                        as object
(
    value       varbinary(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$property_t
                                      
AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    prop_number     integer,
    /* SQLINES DEMO *** es not need to be a QName since its namespace
    must always equal the target namespace for the schema */
    name            varchar(256),
    typename        xdb.xdb$qname,
    mem_byte_length varbinary(2),       /* SQLINES DEMO ***  for variable size*/
    mem_type_code   varbinary(2),
    system          varbinary(1),
    mutable         varbinary(1),
    form            xdb.xdb$formChoice,          /* SQLINES DEMO *** lified/not */
    sqlname         varchar(30),
    sqltype         varchar(30),
    sqlschema       varchar(30),
    java_type       xdb.xdb$javatype,
    default_value   varchar(4000),
    smpl_type_decl  ref sys.xmltype,          /* SQLINES DEMO *** type */
    type_ref        ref sys.xmltype,          /* SQLINES DEMO ***  type */
    /* SQLINES DEMO ***  fields are relevant if the attr/element is defined
     * by a ref to a global attr/element
     */
    propref_name    xdb.xdb$qname,               /* SQLINES DEMO *** tr/element */
    propref_ref     ref sys.xmltype,           /* SQLINES DEMO *** r/element */
    attr_use        xdb.xdb$useChoice,             /* SQLINES DEMO *** or attrs */
    fixed_value     varchar(2000),
    global          varbinary(1),     /* SQLINES DEMO *** ttr/element declarations */
    annotation      xdb.xdb$annotation_t,
    sqlcolltype     varchar(30),                   /* SQLINES DEMO *** ame */
    sqlcollschema   varchar(30),
    hidden          varbinary(1),
    transient       xdb.xdb$transientChoice,    /* SQLINES DEMO *** manifested ? */
    id              varchar(256),
    baseprop        varbinary(1) /* SQLINES DEMO *** ed props based on this prop ? */
)
 alter type     xdb$property_t modify attribute
(sqlname         varchar2(128),
 sqltype         varchar2(128),
 sqlschema       varchar2(128),
 sqlcolltype     varchar2(128),
 sqlcollschema   varchar2(128)
) cascade;

CREATE OR REPLACE type XDB.xdb$qname                                       
as object
(
    prefix_code     varbinary(4), /* SQLINES DEMO ***  extras */
    name            varchar(2000)
);

CREATE OR REPLACE type XDB.xdb$raw_list_t                                       
as varray(2147483647) of raw(2000);

CREATE OR REPLACE type XDB.XDB$RCLIST_T                                        AS OBJECT
(
  OID    XDB$OID_LIST_T
);

CREATE OR REPLACE type XDB.XDB$RESOURCE_T                                        as object
(
  VERSIONID           INTEGER,
  CREATIONDATE        DATETIME(6),
  MODIFICATIONDATE    DATETIME(6),
  AUTHOR              VARCHAR(128),
  DISPNAME            VARCHAR(128),
  RESCOMMENT          VARCHAR(128),
  LANGUAGE            VARCHAR(128),
  CHARSET             VARCHAR(128),
  CONTYPE             VARCHAR(128),
  REFCOUNT            VARBINARY(4),
  LOCKS               VARBINARY(2000),
  ACLOID              VARBINARY(16),
  OWNERID             VARBINARY(16),
  CREATORID           VARBINARY(16),
  LASTMODIFIERID      VARBINARY(16),
  ELNUM               INTEGER,
  SCHOID              VARBINARY(16),
  XMLREF              REF SYS.XMLTYPE,
  XMLLOB              LONGBLOB,
  FLAGS               VARBINARY(4),
  RESEXTRA            LONGTEXT,
  ACTIVITYID          INTEGER,
  VCRUID              VARBINARY(16),
  PARENTS             XDB.XDB$PREDECESSOR_LIST_T,
  SBRESEXTRA          XDB.XDB$XMLTYPE_REF_LIST_T,
  SNAPSHOT            VARBINARY(6),
  ATTRCOPY            LONGBLOB,
  CTSCOPY             LONGBLOB,
  NODENUM             VARBINARY(6),
  SIZEONDISK          INTEGER,
  RCLIST              XDB.XDB$RCLIST_T,
  CHECKEDOUTBYID      VARBINARY(16),
  BASEVERSION         VARBINARY(16)
)
 alter type     XDB$RESOURCE_T modify attribute SNAPSHOT RAW(8) cascade;

CREATE OR REPLACE type XDB.xdb$schema_t                                       
as object
(
    schema_url          varchar(700), /* SQLINES DEMO *** h for an index*/
    target_namespace    varchar(2000),
    version             varchar(4000),
    num_props           integer, /* SQLINES DEMO *** ties */
    final_default       xdb.xdb$derivationChoice,
    block_default       xdb.xdb$derivationChoice,
    element_form_dflt   xdb.xdb$formChoice,
    attribute_form_dflt xdb.xdb$formChoice,
    elements            xdb.xdb$xmltype_ref_list_t,
    simple_type         xdb.xdb$xmltype_ref_list_t,
    complex_types       xdb.xdb$xmltype_ref_list_t,
    attributes          xdb.xdb$xmltype_ref_list_t,
    imports             xdb.xdb$import_list_t,
    includes            xdb.xdb$include_list_t,
    flags               varbinary(4),
    sys_xdbpd$          xdb.xdb$raw_list_t,
    annotations         xdb.xdb$annotation_list_t,
    map_to_nchar        varbinary(1),   /* SQLINES DEMO *** HAR/NVARCHAR2/NCLOB ? */
    map_to_lob          varbinary(1),           /* SQLINES DEMO *** ings to LOB ? */
    groups              xdb.xdb$xmltype_ref_list_t,
    attrgroups          xdb.xdb$xmltype_ref_list_t,
    id                  varchar(256),
    varray_as_tab       varbinary(1),     /* SQLINES DEMO ***  stored as tables ? */
    schema_owner        varchar(30),
    notations           xdb.xdb$notation_list_t,
    lang                varchar(4000)
)
 alter type     xdb$schema_t modify attribute
(schema_owner varchar2(128)) cascade;

CREATE OR REPLACE type XDB.xdb$simplecontent_t                                       
as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,

    /* SQLINES DEMO *** oll. can be non-null */
    restriction     xdb.xdb$simplecont_res_t,
    extension       xdb.xdb$simplecont_ext_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$simplecont_ext_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base            xdb.xdb$qname,
    id              varchar(256),

    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,
    annotation      xdb.xdb$annotation_t
);

CREATE OR REPLACE type XDB.xdb$simplecont_res_t                                        AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base            xdb.xdb$qname,
    id              varchar(256),
    lcl_smpl_decl   ref sys.xmltype,        /* SQLINES DEMO *** simple type */
    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,
    annotation      xdb.xdb$annotation_t,

    /* Facets */
    fractiondigits  xdb.xdb$numfacet_t,
    totaldigits     xdb.xdb$numfacet_t,
    minlength       xdb.xdb$numfacet_t,
    maxlength       xdb.xdb$numfacet_t,
    whitespace      xdb.xdb$whitespace_t,
    period          xdb.xdb$timefacet_t,
    duration        xdb.xdb$timefacet_t,
    min_inclusive   xdb.xdb$facet_t,
    max_inclusive   xdb.xdb$facet_t,
    pattern         xdb.xdb$facet_list_t,
    enumeration     xdb.xdb$facet_list_t,
    min_exclusive   xdb.xdb$facet_t,
    max_exclusive   xdb.xdb$facet_t,
    length          xdb.xdb$numfacet_t
);

CREATE OR REPLACE type XDB.xdb$simple_derivation_t                                        AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base_type       ref sys.xmltype,
    base            xdb.xdb$qname,
    lcl_smpl_decl   ref sys.xmltype,        /* SQLINES DEMO *** simple type */

    /* Facets */
    fractiondigits  xdb.xdb$numfacet_t,
    totaldigits     xdb.xdb$numfacet_t,
    minlength       xdb.xdb$numfacet_t,
    maxlength       xdb.xdb$numfacet_t,
    length          xdb.xdb$numfacet_t,
    whitespace      xdb.xdb$whitespace_t,
    period          xdb.xdb$timefacet_t,
    duration        xdb.xdb$timefacet_t,
    min_inclusive   xdb.xdb$facet_t,
    max_inclusive   xdb.xdb$facet_t,
    min_exclusive   xdb.xdb$facet_t,
    max_exclusive   xdb.xdb$facet_t,
    pattern         xdb.xdb$facet_list_t,
    enumeration     xdb.xdb$facet_list_t,
    annotation      xdb.xdb$annotation_t,
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$simple_t
                                      
AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    /* SQLINES DEMO *** es not need to be a QName since its namespace
    must always equal the target namespace for the schema */
    name            varchar(256),
    abstract        varbinary(1),   /* SQLINES DEMO *** d */
    /* SQLINES DEMO *** oll. fields is non-null */
    restriction     xdb.xdb$simple_derivation_t,
    list_type       xdb.xdb$list_t,
    union_type      xdb.xdb$union_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar(256),
    final_info      xdb.xdb$derivationChoice,
    typeid          integer,
    sqltype         varchar(30)
)
 alter type     xdb$simple_t modify attribute sqltype varchar2(128) cascade;

CREATE OR REPLACE type XDB.xdb$string_list_t                                       
as VARRAY(2147483647) of varchar2(4000);

CREATE OR REPLACE type XDB.xdb$timefacet_t                                        as object               /* Time Facet */
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    value           datetime,
    fixed           varbinary(1),
    id              varchar(256)
);

CREATE OR REPLACE type XDB.xdb$transientChoice                                        as object
(
    value       varbinary(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$union_t                                        as
object
(
    sys_xdbpd$         xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    member_types       varchar(4000),                 /* members of union */
    simple_types       xdb.xdb$xmltype_ref_list_t,       /* SQLINES DEMO *** s */

    /* SQLINES DEMO *** ll constituents of the union type */
    type_refs          xdb.xdb$xmltype_ref_list_t
);

CREATE OR REPLACE type XDB.xdb$useChoice                                       
as object
(
    value       varbinary(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$whitespaceChoice                                        as object
(
    value       varbinary(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   procedure setValue(IN val VARCHAR(4000))DECLARE ,
       pragma restrict_references(setValue, wnds, wnps, rnps, rnds)
//

delimiter ;


);

CREATE OR REPLACE type XDB.xdb$whitespace_t                                        as object        /* Whitespace facet */
(
    sys_xdbpd$  xdb.xdb$raw_list_t,
    annotation  xdb.xdb$annotation_t,
    value       xdb.xdb$whitespaceChoice,
    fixed       varbinary(1),
    id          varchar(256)
);

CREATE OR REPLACE type XDB.xdb$xmltype_ref_list_t
                                       as varray(2147483647) of ref sys.xmltype;

CREATE OR REPLACE type XDB.xdb$xpathspec_list_t
                                      
as varray(1000) of xdb.xdb$xpathspec_t;

CREATE OR REPLACE type XDB.xdb$xpathspec_t
                                      
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  annotation      xdb.xdb$annotation_t,
  xpath           varchar(4000)
);

CREATE OR REPLACE type XDB.XMLIdxStatsMethods
                                        
  authid current_user as object
(
  -- SQLINES DEMO *** tion cost and selectivity functions
  cost number,

  -- DCLs
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIGetInterfaces (ilist OUT sys.ODCIObjectList)
         returns DOUBLEDECLARE ,

  -- - STATISTICs ---
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsTableFunction(funcInfo  sys.ODCIFuncInfo,
                                         tfStats  OUT sys.ODCITabFuncStats,
                                         args      sys.ODCIArgDescList)
         returns DOUBLE
  begin declare language C name
//

delimiter ;


//

delimiter ;

 `QMIX_TABFUN_STATS` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       funcInfo, funcInfo INDICATOR struct,
       tfStats,  tfStats  INDICATOR struct,
       args,     args     INDICATOR,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsCollect(colinfo   sys.ODCIColInfo,
                                   options   sys.ODCIStatsOptions,
                                   stats OUT VARBINARY,
                                   idxenv    sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_COL_STATS` LIBRARY XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context parameters (
       context,
       colinfo, colinfo INDICATOR struct,
       options, options INDICATOR struct,
       stats,   stats   INDICATOR, stats LENGTH,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsCollect(idxinfo   sys.ODCIIndexInfo,
                                   options   sys.ODCIStatsOptions,
                                   stats OUT VARBINARY,
                                   idxenv    sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_IDX_STATS` LIBRARY XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       options, options INDICATOR struct,
       stats,   stats   INDICATOR, stats LENGTH,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsDelete(colinfo   sys.ODCIColInfo,
                                  statistics OUT VARBINARY,
                                  idxenv    sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_DEL_COLSTATS` LIBRARY XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context parameters (
       context,
       colinfo,    colinfo    INDICATOR struct,
       statistics, statistics INDICATOR, statistics LENGTH,
       idxenv,     idxenv     INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsDelete(idxinfo   sys.ODCIIndexInfo,
                                  statistics OUT VARBINARY,
                                  idxenv    sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_DEL_IDXSTATS` LIBRARY XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context parameters (
       context,
       idxinfo,    idxinfo    INDICATOR struct,
       statistics, statistics INDICATOR, statistics LENGTH,
       idxenv,     idxenv     INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsSelectivity(predinfo sys.ODCIPredInfo,
                                       sel  OUT double,
                                       args     sys.ODCIArgDescList,
                                       strt     double,
                                       stop     double,
                                       expr     VARCHAR(4000),
                                       datai    VARCHAR(4000),
                                       idxenv   sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_SELECTIVITY` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       predinfo,predinfo INDICATOR struct,
       sel,     sel      INDICATOR,
       args,    args     INDICATOR,
       strt,    strt     INDICATOR,
       stop,    stop     INDICATOR,
       expr,    expr     INDICATOR,
       datai,   datai    INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsFunctionCost(funcinfo sys.ODCIFuncInfo,
                                        cost OUT sys.ODCICost,
                                        args     sys.ODCIArgDescList,
                                        expr     VARCHAR(4000),
                                        datai    VARCHAR(4000),
                                        idxenv   sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_FUN_COST` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       funcinfo,funcinfo INDICATOR struct,
       cost,    cost     INDICATOR struct,
       args,    args     INDICATOR,
       expr,    expr     INDICATOR,
       datai,   datai    INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsIndexCost(idxinfo  sys.ODCIIndexInfo,
                                     sel      double,
                                     cost OUT sys.ODCICost,
                                     qi       sys.ODCIQueryInfo,
                                     pred     sys.ODCIPredInfo,
                                     args     sys.ODCIArgDescList,
                                     strt     double,
                                     stop     double,
                                     datai    varchar(4000),
                                     idxenv   sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_IDX_COST` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       sel,     sel     INDICATOR,
       cost,    cost    INDICATOR struct,
       qi,      qi      INDICATOR struct,
       pred,    pred    INDICATOR struct,
       args,    args    INDICATOR,
       strt,    strt    INDICATOR,
       stop,    stop    INDICATOR,
       datai,   datai   INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsExchangePartition(idxinfo sys.ODCIIndexInfo,
                                             tabinfo sys.ODCIIndexInfo,
                                             idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_EXCHANGE_STATS` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       tabinfo, tabinfo INDICATOR struct,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIStatsUpdPartStatistics(idxinfo sys.ODCIIndexInfo,
                                             palist  sys.ODCIPartInfoList,
                                             idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_UPD_PARTSTATS` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       palist,  palist  INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber)
);

CREATE OR REPLACE type XDB.XMLIndexLoad_Imp_t
  authid current_user as object
(
  key RAW(8),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCITableStart(sctx OUT XDB.XMLIndexLoad_Imp_t)
         returns INTEGER
    begin declare language C name
//

delimiter ;

 `QMIX_INSSTART` library XDB.XMLINDEX_LIB
    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    with context
    parameters (
      context,
      sctx,        sctx        INDICATOR STRUCT,
      return INT
    ),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCITableStart(sctx OUT XDB.XMLIndexLoad_Imp_t,
                                 load_cursor SYS_REFCURSOR,
                                 flags Double)
         returns INTEGER
    begin declare language C name
//

delimiter ;

 `QMIX_LOADSTART` library XDB.XMLINDEX_LIB
    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    with context
    parameters (
      context,
      sctx,        sctx        INDICATOR STRUCT,
      load_cursor, load_cursor INDICATOR,
      flags,
      return INT
    ),

  member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCITableFetch(self OUT XDB.XMLIndexLoad_Imp_t,
                                 nrows    Double,
                                 xmlrws  OUT XDB.XMLIndexTab_t)
         returns INTEGER
    begin declare language C name
//

delimiter ;

 `QMIX_LOADFETCH` library XDB.XMLINDEX_LIB
    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT,
      nrows,
      xmlrws OCIColl, xmlrws INDICATOR sb2, xmlrws DURATION OCIDuration,
      return INT
    ),

  member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCITableClose(self XDB.XMLIndexLoad_Imp_t)
         returns INTEGER
    begin declare language C name
//

delimiter ;

 `QMIX_LOADCLOSE` library XDB.XMLINDEX_LIB
    -- SQLINES LICENSE FOR EVALUATION USE ONLY
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT,
      return INT
    )
);

CREATE OR REPLACE type XDB.XMLIndexLoad_t as object
(
  RID    VARCHAR(18),
  PID    VARBINARY(8),
  OK     VARBINARY(1000),
  LOC    VARBINARY(2000),
  VALUE  VARCHAR(4000)
);

CREATE OR REPLACE type XDB.XMLIndexMethods FORCE
                                        
  authid current_user as object
(
  -- SQLINES DEMO *** exStart and used in IndexFetch
  scanctx RAW(8),

  -- DCLs
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIGetInterfaces (ilist OUT sys.ODCIObjectList)
         returns DOUBLEDECLARE ,

  -- DDLs
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexCreate   (idxinfo  sys.ODCIIndexInfo,
                                     idxparms VARCHAR(4000),
                                     idxenv   sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;


//

delimiter ;

 `QMIX_CREATE` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo  INDICATOR struct,
       idxparms,idxparms INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexDrop     (idxinfo sys.ODCIIndexInfo,
                                     idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_DROP` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexAlter    (idxinfo          sys.ODCIIndexInfo,
                                     idxparms  OUT VARCHAR(4000),
                                     opt              DOUBLE,
                                     idxenv           sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_ALTER` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo  INDICATOR struct,
       idxparms,idxparms INDICATOR,
       opt,     opt      INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexTruncate (idxinfo sys.ODCIIndexInfo,
                                     idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_TRUNC` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  -- - DMLs ---
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexInsert (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR(4000),
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_INSERT` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexInsert (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR(4000),
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv,
                                   oid     VARCHAR(4000))
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_INSERT2` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       oid,     oid     INDICATOR,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexDelete (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR(4000),
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_DELETE` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexDelete (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR(4000),
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv,
                                   oid     VARCHAR(4000))
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_DELETE2` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       oid,     oid     INDICATOR,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexUpdate (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR(4000),
                                   olddoc  sys.xmltype,
                                   newdoc  sys.xmltype,
                                   idxenv  sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_UPDATE` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       olddoc,  olddoc  INDICATOR,
       newdoc,  newdoc  INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexUpdate (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR(4000),
                                   olddoc  sys.xmltype,
                                   newdoc  sys.xmltype,
                                   idxenv  sys.ODCIEnv,
                                   oid     VARCHAR(4000))
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_UPDATE2` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       olddoc,  olddoc  INDICATOR,
       newdoc,  newdoc  INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       oid,     oid     INDICATOR,
       RETURN OCINumber),

  -- - Query ---
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexStart (ictx    OUT XMLIndexMethods,
                                  idxinfo        sys.ODCIIndexInfo,
                                  opi            sys.ODCIPredInfo,
                                  oqi            sys.ODCIQueryInfo,
                                  strt           DOUBLE,
                                  stop           DOUBLE,
                                  pathstr        varchar(4000),
                                  idxenv         sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_START` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       ictx,    ictx    INDICATOR struct,
       idxinfo, idxinfo INDICATOR struct,
       opi,     opi     INDICATOR struct,
       oqi,     oqi     INDICATOR struct,
       strt,    strt    INDICATOR,
       stop,    stop    INDICATOR,
       pathstr, pathstr LENGTH,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexFetch (nrows      DOUBLE,
                                  rids   OUT sys.ODCIRidList,
                                  idxenv     sys.ODCIEnv)
         returns  DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_FETCH` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       self,     self INDICATOR struct,
       nrows,   nrows INDICATOR,
       rids,     rids INDICATOR,
       idxenv, idxenv INDICATOR struct,
       return OCINumber),

  member -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexClose (idxenv sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_CLOSE` LIBRARY XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context parameters (
       context,
       self,     self INDICATOR struct,
       idxenv, idxenv INDICATOR struct,
       return OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexExchangePartition (idxPinfo sys.ODCIIndexInfo,
                                              idxTinfo sys.ODCIIndexInfo,
                                              idxenv   sys.ODCIEnv)
         returns DOUBLE
  begin declare language C name
//

delimiter ;

 `QMIX_EXCHANGE` library XDB.XMLINDEX_LIB
     -- SQLINES LICENSE FOR EVALUATION USE ONLY
     with context
     parameters (
       context,
       idxPinfo, idxPinfo INDICATOR struct,
       idxTinfo, idxTinfo INDICATOR struct,
       idxenv,   idxenv   INDICATOR struct,
       RETURN OCINumber),

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexUpdPartMetadata(ixdxinfo sys.ODCIIndexInfo,
                                           palist   sys.ODCIPartInfoList,
                                           idxenv   sys.ODCIEnv)
         returns DOUBLEDECLARE ,

--  SQLINES DEMO *** ABLE TBS / IM/EXPORT ---
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
delimiter //

create   function ODCIIndexGetMetadata(idxinfo   sys.ODCIIndexInfo,
                                       expver    VARCHAR(4000),
                                       newblock OUT double,
                                       idxenv    sys.ODCIEnv)
         returns VARCHAR(4000)DECLARE ,

  -- SQLINES DEMO *** condary indexes on it are already exported in schema-mode
  -- SQLINES DEMO *** ld only expose them for Transportable Tablespaces,
  -- via DataPump

  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
DELIMITER //

CREATE   FUNCTION ODCIIndexUtilGetTableNames(ia sys.ODCIIndexInfo,
                                      read_only INTEGER,
                                      version varchar(4000),
                                      context OUT INTEGER)
  RETURNS BOOLEANDECLARE ,

/* SQLINES DEMO *** n ODCIIndexUtilGetTableNames(idxinfo   IN sys.ODCIIndexInfo,
                                             read_only IN PLS_INTEGER,
                                             version   IN varchar2,
                                             ctx       OUT PLS_INTEGER)
         return BOOLEAN
  is language C name "QMIX_GETTABNAMES" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo,  idxinfo   INDICATOR struct,
       read_only,read_only INDICATOR,
       version,  version   INDICATOR,
       ctx,      ctx       INDICATOR,
       RETURN INDICATOR sb4),
*/
  static -- SQLINES LICENSE FOR EVALUATION USE ONLY
DELIMITER //

CREATE   PROCEDURE ODCIIndexUtilCleanup (IN context  INTEGER)
DECLARE );

CREATE OR REPLACE type XDB.XMLIndexTab_t as TABLE of XDB.XMLIndexLoad_t;
//

DELIMITER ;


//

DELIMITER ;


//

delimiter ;


//

delimiter ;



CREATE OR REPLACE TYPE XDB.XMLTYPE_REF_TABLE_T IS TABLE of REF XMLTYPE;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`APP_ROLE_MEMBERSHIP` 
   (	`ROLE_GUID` VARBINARY(16), 
	`MEMBER_GUID` VARBINARY(16)
   ) 
   ;

ALTER TABLE XDB.APP_ROLE_MEMBERSHIP COMMENT 'Application role membership';
/* Moved to CREATE TABLE
COMMENT ON COLUMN XDB.APP_ROLE_MEMBERSHIP.ROLE_GUID IS 'The GUID for the role/workgroup'; */
/* Moved to CREATE TABLE
COMMENT ON COLUMN XDB.APP_ROLE_MEMBERSHIP.MEMBER_GUID IS 'The GUID of the role member'; */

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`APP_USERS_AND_ROLES` 
   (	`GUID` VARBINARY(16), 
	`NAME` VARCHAR(1024), 
	`ISROLE` VARCHAR(3), 
	 UNIQUE (`NAME`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004848` ON `XDB`.`APP_USERS_AND_ROLES` (`NAME`) 
   ;

ALTER TABLE XDB.APP_USERS_AND_ROLES COMMENT 'Application users and roles/workspaces';
/* Moved to CREATE TABLE
COMMENT ON COLUMN XDB.APP_USERS_AND_ROLES.GUID IS 'The GUID for user or role/workgroup'; */
/* Moved to CREATE TABLE
COMMENT ON COLUMN XDB.APP_USERS_AND_ROLES.NAME IS 'The name of user or role/workgroup'; */
/* Moved to CREATE TABLE
COMMENT ON COLUMN XDB.APP_USERS_AND_ROLES.ISROLE IS 'Whether user or role/workgroup'; */

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`DOCUMENT_LINKS` (`SOURCE_ID`, `TARGET_ID`, `TARGET_PATH`, `LINK_TYPE`, `LINK_FORM`, `SOURCE_TYPE`) AS 
  SELECT
dl.source_id,
dl.target_id,
dl.target_path,
case (sys_op_rawtonum(dl.flags) &1) when 1 then  'Weak'
        else case (sys_op_rawtonum(dl.flags) &2) when 2 then 'Symbolic' else 'Hard' end end,
case (sys_op_rawtonum(dl.flags) &4) when 4 then  'XInclude'  else 'XLink' end,
case (sys_op_rawtonum(dl.flags) &8) when 8 then  'Resource Metadata'
        else 'Resource Content' end
from xdb.xdb$d_link dl, xdb.xdb$resource r
where dl.source_id = r.object_id
and sys_checkacl(r.xmldata.acloid, r.xmldata.ownerid,
xmltype('<privilege
      xmlns="http://xmlns.oracle.com/xdb/acl.xsd"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://xmlns.oracle.com/xdb/acl.xsd
                          http://xmlns.oracle.com/xdb/acl.xsd
                          DAV: http://xmlns.oracle.com/xdb/dav.xsd">
      <read-properties/>
      <read-contents/>
 </privilege>')) = 1;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`JSON$COLLECTION_METADATA` 
   (	`URI_NAME` NVARCHAR(255) NOT NULL, 
	`OWNER` VARCHAR(128) DEFAULT SYS_CONTEXT('USERENV','CURRENT_USER') NOT NULL, 
	`OBJECT_TYPE` VARCHAR(10) DEFAULT 'TABLE' NOT NULL, 
	`OBJECT_SCHEMA` VARCHAR(128) DEFAULT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') NOT NULL, 
	`OBJECT_NAME` VARCHAR(128) NOT NULL, 
	`CREATED_ON` DATETIME (6) DEFAULT sys_extract_utc(CURRENT_TIMESTAMP) NOT NULL, 
	`CREATE_MODE` VARCHAR(10) DEFAULT 'MAP' NOT NULL, 
	`JSON_DESCRIPTOR` VARCHAR(4000) NOT NULL, 
	 CONSTRAINT `JSON$COLLECTION_METADATA_C1` CHECK (OBJECT_TYPE in ('TABLE','VIEW','PACKAGE')), 
	 CONSTRAINT `JSON$COLLECTION_METADATA_C2` CHECK (CREATE_MODE in ('DDL','MAP')), 
	 CONSTRAINT `JSON$COLLECTION_METADATA_PK` PRIMARY KEY (`OWNER`, `URI_NAME`)
 , 
	 CONSTRAINT `JSON$COLLECTION_METADATA_CJ` CHECK (JSON_DESCRIPTOR is json) ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `JSON$COLLECTION_METADATA_PK` ON `XDB`.`JSON$COLLECTION_METADATA` (`OWNER`, `URI_NAME`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`JSON$COLLECTION_METADATA_V` (`URI_NAME`, `OWNER`, `SCHEMA_NAME`, `TABLE_NAME`, `VIEW_NAME`, `PACKAGE_NAME`, `TABLESPACE_NAME`, `STORAGE_INIT_SIZE`, `STORAGE_INCREASE_PCT`, `KEY_COLUMN_NAME`, `KEY_COLUMN_TYPE`, `KEY_COLUMN_LEN`, `KEY_ASSIGNMENT_METHOD`, `KEY_SEQUENCE_NAME`, `KEY_PATH`, `PARTITION_COLUMN_NAME`, `PARTITION_COLUMN_TYPE`, `PARTITION_COLUMN_LEN`, `PARTITION_PATH`, `CONTENT_COLUMN_NAME`, `CONTENT_COLUMN_TYPE`, `CONTENT_COLUMN_LEN`, `CONTENT_COLUMN_JSON_FORMAT`, `CONTENT_VALIDATION`, `CONTENT_LOB_COMPRESS`, `CONTENT_LOB_CACHE`, `CONTENT_LOB_ENCRYPT`, `CONTENT_LOB_TS`, `LAST_MODIFIED_COLUMN_NAME`, `LAST_MODIFIED_INDEX`, `VERSION_COLUMN_NAME`, `VERSIONING_METHOD`, `MEDIA_TYPE_COLUMN_NAME`, `CREATION_TIME_COLUMN_NAME`, `READ_ONLY`) AS 
  select MD.URI_NAME                   URI_NAME,
       MD.OWNER                      OWNER,
       JT.SCHEMA_NAME                SCHEMA_NAME,
       JT.TABLE_NAME                 TABLE_NAME,
       JT.VIEW_NAME                  VIEW_NAME,
       JT.PACKAGE_NAME               PACKAGE_NAME,
       JT.TABLESPACE_NAME            TABLESPACE_NAME,
       JT.STORAGE_INIT_SIZE          STORAGE_INIT_SIZE,
       JT.STORAGE_INCREASE_PCT       STORAGE_INCREASE_PCT,
       JT.KEY_COLUMN_NAME            KEY_COLUMN_NAME,
       JT.KEY_COLUMN_TYPE            KEY_COLUMN_TYPE,
       JT.KEY_COLUMN_LEN             KEY_COLUMN_LEN,
       JT.KEY_ASSIGNMENT_METHOD      KEY_ASSIGNMENT_METHOD,
       JT.KEY_SEQUENCE_NAME          KEY_SEQUENCE_NAME,
       JT.KEY_PATH                   KEY_PATH,
       JT.PARTITION_COLUMN_NAME      PARTITION_COLUMN_NAME,
       JT.PARTITION_COLUMN_TYPE      PARTITION_COLUMN_TYPE,
       JT.PARTITION_COLUMN_LEN       PARTITION_COLUMN_LEN,
       JT.PARTITION_PATH             PARTITION_PATH,
       JT.CONTENT_COLUMN_NAME        CONTENT_COLUMN_NAME,
       JT.CONTENT_COLUMN_TYPE        CONTENT_COLUMN_TYPE,
       JT.CONTENT_COLUMN_LEN         CONTENT_COLUMN_LEN,
       JT.CONTENT_COLUMN_JSON_FORMAT CONTENT_COLUMN_JSON_FORMAT,
       JT.CONTENT_VALIDATION         CONTENT_VALIDATION,
       JT.CONTENT_LOB_COMPRESS       CONTENT_LOB_COMPRESS,
       JT.CONTENT_LOB_CACHE          CONTENT_LOB_CACHE,
       JT.CONTENT_LOB_ENCRYPT        CONTENT_LOB_ENCRYPT,
       JT.CONTENT_LOB_TS             CONTENT_LOB_TS,
       JT.LAST_MODIFIED_COLUMN_NAME  LAST_MODIFIED_COLUMN_NAME,
       JT.LAST_MODIFIED_INDEX        LAST_MODIFIED_INDEX,
       JT.VERSION_COLUMN_NAME        VERSION_COLUMN_NAME,
       JT.VERSIONING_METHOD          VERSIONING_METHOD,
       JT.MEDIA_TYPE_COLUMN_NAME     MEDIA_TYPE_COLUMN_NAME,
       JT.CREATION_TIME_COLUMN_NAME  CREATION_TIME_COLUMN_NAME,
       JT.READ_ONLY                  READ_ONLY
  from XDB.JSON$COLLECTION_METADATA MD,
       Json_Table(MD.JSON_DESCRIPTOR, '$' null on error columns
 `SCHEMA_NAME`                varchar2(128) path '$.schemaName',
 `TABLE_NAME`                 varchar2(128) path '$.tableName',
 `VIEW_NAME`                  varchar2(128) path '$.viewName',
 `PACKAGE_NAME`               varchar2(128) path '$.packageName',
 `TABLESPACE_NAME`            varchar2(128) path '$.tablespace',
 `STORAGE_INIT_SIZE`          number        path '$.storage.size',
 `STORAGE_INCREASE_PCT`       number        path '$.storage.increase',
 `KEY_COLUMN_NAME`            varchar2(128) path '$.keyColumn.name',
 `KEY_COLUMN_TYPE`            varchar2(10)  path '$.keyColumn.sqlType',
 `KEY_COLUMN_LEN`             number        path '$.keyColumn.maxLength',
 `KEY_ASSIGNMENT_METHOD`      varchar2(10)  path '$.keyColumn.assignmentMethod',
 `KEY_SEQUENCE_NAME`          varchar2(128) path '$.keyColumn.sequenceName',
 `KEY_PATH`                   varchar2(255) path '$.keyColumn.path',
 `PARTITION_COLUMN_NAME`      varchar2(128) path '$.partitionColumn.name',
 `PARTITION_COLUMN_TYPE`      varchar2(10)  path '$.partitionColumn.sqlType',
 `PARTITION_COLUMN_LEN`       number        path '$.partitionColumn.maxLength',
 `PARTITION_PATH`             varchar2(255) path '$.partitionColumn.path',
 `CONTENT_COLUMN_NAME`        varchar2(128) path '$.contentColumn.name',
 `CONTENT_COLUMN_TYPE`        varchar2(10)  path '$.contentColumn.sqlType',
 `CONTENT_COLUMN_LEN`         number        path '$.contentColumn.maxLength',
 `CONTENT_COLUMN_JSON_FORMAT` varchar2(10)  path '$.contentColumn.jsonFormat',
 `CONTENT_VALIDATION`         varchar2(10)  path '$.contentColumn.validation',
 `CONTENT_LOB_COMPRESS`       varchar2(10)  path '$.contentColumn.compress',
 `CONTENT_LOB_CACHE`          varchar2(10)  path '$.contentColumn.cache',
 `CONTENT_LOB_ENCRYPT`        varchar2(10)  path '$.contentColumn.encrypt',
 `CONTENT_LOB_TS`             varchar2(128) path '$.contentColumn.tablespace',
 `LAST_MODIFIED_COLUMN_NAME`  varchar2(128) path '$.lastModifiedColumn.name',
 `LAST_MODIFIED_INDEX`        varchar2(128) path '$.lastModifiedColumn.index',
 `VERSION_COLUMN_NAME`        varchar2(128) path '$.versionColumn.name',
 `VERSIONING_METHOD`          varchar2(10)  path '$.versionColumn.method',
 `MEDIA_TYPE_COLUMN_NAME`     varchar2(128) path '$.mediaTypeColumn.name',
 `CREATION_TIME_COLUMN_NAME`  varchar2(128) path '$.creationTimeColumn.name',
 `READ_ONLY`                  varchar2(10)  path '$.readOnly'
                 ) JT;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`JSON$USERS` 
   (	`ID` VARBINARY(16) DEFAULT REPLACE(UUID(), '-', '') NOT NULL, 
	`OWNER` VARCHAR(128) DEFAULT USER() NOT NULL, 
	`USER_NAME` NVARCHAR(255) NOT NULL, 
	`CREATED_ON` DATETIME (6) DEFAULT sys_extract_utc(CURRENT_TIMESTAMP) NOT NULL, 
	`DESCRIPTION` VARCHAR(4000), 
	 CONSTRAINT `JSON$USERS_PK` PRIMARY KEY (`ID`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `JSON$USERS_PK` ON `XDB`.`JSON$USERS` (`ID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `JSON$USERS_U1` ON `XDB`.`JSON$USERS` (`OWNER`, `USER_NAME`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`JSON$USER_COLLECTION_METADATA` (`URI_NAME`, `OBJECT_TYPE`, `OBJECT_SCHEMA`, `OBJECT_NAME`, `CREATED_ON`, `CREATE_MODE`, `JSON_DESCRIPTOR`) AS 
  select URI_NAME,
       OBJECT_TYPE, OBJECT_SCHEMA, OBJECT_NAME,
       CREATED_ON, CREATE_MODE, JSON_DESCRIPTOR
  from XDB.JSON$COLLECTION_METADATA
 where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER');
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`JSON$USER_CREDENTIALS` 
   (	`ID` VARBINARY(16) NOT NULL, 
	`CREDENTIAL_TYPE` VARCHAR(255) NOT NULL, 
	`CREDENTIAL` VARCHAR(4000) NOT NULL, 
	 CONSTRAINT `JSON$USER_CREDENTIALS_PK` PRIMARY KEY (`ID`, `CREDENTIAL_TYPE`)
   ) 
   ;

ALTER TABLE `XDB`.`JSON$USER_CREDENTIALS` ADD CONSTRAINT `JSON$USER_CREDENTIALS_FK` FOREIGN KEY (`ID`)
	  REFERENCES `XDB`.`JSON$USERS` (`ID`) ON DELETE CASCADE;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `JSON$USER_CREDENTIALS_PK` ON `XDB`.`JSON$USER_CREDENTIALS` (`ID`, `CREDENTIAL_TYPE`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`JSON$USER_ROLES` 
   (	`ID` VARBINARY(16) NOT NULL, 
	`OWNER` VARCHAR(128) DEFAULT USER() NOT NULL, 
	`ROLE_NAME` VARCHAR(255) NOT NULL, 
	 CONSTRAINT `JSON$USER_ROLES_PK` PRIMARY KEY (`ID`, `OWNER`, `ROLE_NAME`)
   ) 
   ;

ALTER TABLE `XDB`.`JSON$USER_ROLES` ADD CONSTRAINT `JSON$USER_ROLES_FK` FOREIGN KEY (`ID`)
	  REFERENCES `XDB`.`JSON$USERS` (`ID`) ON DELETE CASCADE;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE INDEX `JSON$USER_ROLES_N1` ON `XDB`.`JSON$USER_ROLES` (`OWNER`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `JSON$USER_ROLES_PK` ON `XDB`.`JSON$USER_ROLES` (`ID`, `OWNER`, `ROLE_NAME`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`PATH_VIEW` (`PATH`, `RES`, `LINK`, `RESID`) AS 
  select /*+ ORDERED */ t2.path path, t.res res,
      xmltype.createxml(xdb.xdb_link_type(NULL, r2.xmldata.dispname, t.name,
                        h.name, h.flags, h.parent_oid, h.child_oid,
                        case (sys_op_rawtonum(h.flags) & 1024)  when 1024 then 
                              xdb.xdb$enum_t(hextoraw('01'))
                               else case (sys_op_rawtonum(h.flags) & 512)  when 512 then 
                                xdb.xdb$enum_t(hextoraw('02'))
                                 else xdb.xdb$enum_t(hextoraw('00')) end end),
                   'http://xmlns.oracle.com/xdb/XDBStandard.xsd', 'LINK') link,
      t.resid
  from  ( select xdb.all_path(9999) paths, coalesce(p) res, p.sys_nc_oid$ resid,
          case (sys_op_rawtonum(p.xmldata.flags) & 8388608)  when 8388608 then 
                 utl_raw.cast_to_varchar2(dbms_lob.substr(p.xmldata.xmllob, 4000))
                  else p.xmldata.dispname end name
          from xdb.xdb$resource p
          where xdb.under_path(coalesce(p), '/', 9999)=1 ) t,
        TABLE( cast(t.paths as xdb.path_array) ) t2,
        xdb.xdb$h_link h, xdb.xdb$resource r2
   where t2.parent_oid = h.parent_oid and t2.childname = h.name and
         t2.parent_oid = r2.sys_nc_oid$;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`RESOURCE_VIEW` (`RES`, `ANY_PATH`, `RESID`) AS 
  select coalesce(p) res, abspath(8888) any_path, sys_nc_oid$ resid
  from xdb.xdb$resource p
  where under_path(coalesce(p), '/', 8888) = 1 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`X$NM4UMSH11LOFA71E0KOM0000LJFI` 
   (	`NMSPCURI` VARCHAR(2000), 
	`ID` VARBINARY(8)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `X$NI4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$NM4UMSH11LOFA71E0KOM0000LJFI` (`ID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `X$NN4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$NM4UMSH11LOFA71E0KOM0000LJFI` (`NMSPCURI`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`X$PT4UMSH11LOFA71E0KOM0000LJFI` 
   (	`PATH` VARBINARY(2000), 
	`ID` VARBINARY(8)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `X$PI4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$PT4UMSH11LOFA71E0KOM0000LJFI` (`ID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `X$PP4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$PT4UMSH11LOFA71E0KOM0000LJFI` (`PATH`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `X$PR4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$PT4UMSH11LOFA71E0KOM0000LJFI` (SYS_PATH_REVERSE(`PATH`)) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`X$QN4UMSH11LOFA71E0KOM0000LJFI` 
   (	`NMSPCID` VARBINARY(8), 
	`LOCALNAME` VARCHAR(2000), 
	`FLAGS` VARBINARY(4), 
	`ID` VARBINARY(8)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `X$QI4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$QN4UMSH11LOFA71E0KOM0000LJFI` (`ID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `X$QQ4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$QN4UMSH11LOFA71E0KOM0000LJFI` (`NMSPCID`, `LOCALNAME`, `FLAGS`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `X$QS4UMSH11LOFA71E0KOM0000LJFI` ON `XDB`.`X$QN4UMSH11LOFA71E0KOM0000LJFI` (`NMSPCID`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ACL` OF XMLTYPE 
 XMLTYPE STORE AS SECUREFILE BINARY XML (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
   XMLSCHEMA `http://xmlns.oracle.com/xdb/acl.xsd` ELEMENT `acl` DISALLOW NONSCHEMA 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP TRIGGER IF EXISTS `XDB`.`XDB$ACL$xd`;

DELIMITER //

CREATE TRIGGER `XDB`.`XDB$ACL$xd` after delete or update on `XDB`.`XDB$ACL` for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$ACL', old.sys_nc_oid$, '9DB6E210D81751C2E0531600000ACDF2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$ACL', old.sys_nc_oid$, '9DB6E210D81751C2E0531600000ACDF2', user() ); END IF; END;
//

DELIMITER ;


/* ALTER TRIGGER `XDB`.`XDB$ACL$xd` ENABLE; */

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004849` ON `XDB`.`XDB$ACL` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019338C00003$$` ON `XDB`.`XDB$ACL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ALL_MODEL` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `all` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ELEMENTS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`CHOICE_KIDS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SEQUENCE_KIDS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANYS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`GROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004833` ON `XDB`.`XDB$ALL_MODEL` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00004$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00005$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00007$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00011$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00012$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00013$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00014$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00015$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00016$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00017$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018872C00018$$` ON `XDB`.`XDB$ALL_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ANY` OF XMLTYPE(	REF(`XMLDATA`.`PROPERTY`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`SMPL_TYPE_DECL`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`TYPE_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`PROPREF_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `any` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004839` ON `XDB`.`XDB$ANY` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018994C00004$$` ON `XDB`.`XDB$ANY` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018994C00005$$` ON `XDB`.`XDB$ANY` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018994C00007$$` ON `XDB`.`XDB$ANY` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018994C00031$$` ON `XDB`.`XDB$ANY` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018994C00032$$` ON `XDB`.`XDB$ANY` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018994C00033$$` ON `XDB`.`XDB$ANY` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ANYATTR` OF XMLTYPE(	REF(`XMLDATA`.`PROPERTY`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`SMPL_TYPE_DECL`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`TYPE_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`PROPREF_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `anyAttribute` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004838` ON `XDB`.`XDB$ANYATTR` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018980C00004$$` ON `XDB`.`XDB$ANYATTR` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018980C00005$$` ON `XDB`.`XDB$ANYATTR` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018980C00007$$` ON `XDB`.`XDB$ANYATTR` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018980C00031$$` ON `XDB`.`XDB$ANYATTR` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018980C00032$$` ON `XDB`.`XDB$ANYATTR` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018980C00033$$` ON `XDB`.`XDB$ANYATTR` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ATTRGROUP_DEF` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `attributeGroup` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ATTRIBUTES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANY_ATTRS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ATTR_GROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004842` ON `XDB`.`XDB$ATTRGROUP_DEF` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00004$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00005$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00007$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00010$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00011$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00012$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00013$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00014$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019036C00015$$` ON `XDB`.`XDB$ATTRGROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ATTRGROUP_REF` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`ATTRGROUP_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `attributeGroup` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004843` ON `XDB`.`XDB$ATTRGROUP_REF` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019056C00004$$` ON `XDB`.`XDB$ATTRGROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019056C00005$$` ON `XDB`.`XDB$ATTRGROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019056C00007$$` ON `XDB`.`XDB$ATTRGROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019056C00012$$` ON `XDB`.`XDB$ATTRGROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019056C00013$$` ON `XDB`.`XDB$ATTRGROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019056C00014$$` ON `XDB`.`XDB$ATTRGROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ATTRIBUTE` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`SMPL_TYPE_DECL`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`TYPE_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPREF_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `attribute` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004837` ON `XDB`.`XDB$ATTRIBUTE` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018966C00004$$` ON `XDB`.`XDB$ATTRIBUTE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018966C00005$$` ON `XDB`.`XDB$ATTRIBUTE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018966C00007$$` ON `XDB`.`XDB$ATTRIBUTE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018966C00031$$` ON `XDB`.`XDB$ATTRIBUTE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018966C00032$$` ON `XDB`.`XDB$ATTRIBUTE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018966C00033$$` ON `XDB`.`XDB$ATTRIBUTE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$CDBPORTS` 
   (	`PDB` DOUBLE, 
	`SERVICE` DOUBLE, 
	`PORT` DOUBLE
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$CHECKOUTS` 
   (	`VCRUID` VARBINARY(16), 
	`WORKSPACEID` DECIMAL(38,0), 
	`VERSION` VARBINARY(16), 
	`ACTID` DECIMAL(38,0), 
	 CONSTRAINT `COKEY` PRIMARY KEY (`VCRUID`, `WORKSPACEID`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `COKEY` ON `XDB`.`XDB$CHECKOUTS` (`VCRUID`, `WORKSPACEID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$CHECKOUTS_VCRUID_IDX` ON `XDB`.`XDB$CHECKOUTS` (`VCRUID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$CHECKOUTS_WORKSPACEID_IDX` ON `XDB`.`XDB$CHECKOUTS` (`WORKSPACEID`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$CHOICE_MODEL` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `choice` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ELEMENTS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`CHOICE_KIDS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SEQUENCE_KIDS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANYS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`GROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004834` ON `XDB`.`XDB$CHOICE_MODEL` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00004$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00005$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00007$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00011$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00012$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00013$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00014$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00015$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00016$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00017$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018896C00018$$` ON `XDB`.`XDB$CHOICE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$COLUMN_INFO` 
   (	`SCHEMA_REF` REF "SYS"."XMLTYPE" , 
	`ELNUM` DECIMAL(38,0), 
	`COLNUM` DECIMAL(38,0), 
	`PROPINFO` VARBINARY(2000)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$COMPLEX_TYPE` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`BASE_TYPE`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`ALL_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`CHOICE_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`SEQUENCE_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`GROUP_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`EXTENSION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`EXTENSION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`EXTENSION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`COMPLEXCONTENT`.`EXTENSION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`SIMPLECONT`.`RESTRICTION`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `complexType` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ATTRIBUTES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANY_ATTRS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ATTR_GROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEXCONTENT`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SUBTYPE_REFS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`RESTRICTION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`EXTENSION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLECONT`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004832` ON `XDB`.`XDB$COMPLEX_TYPE` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00004$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00005$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00007$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00015$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00016$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00017$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00022$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00024$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00027$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00028$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00029$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00034$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00035$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00036$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00038$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00041$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00042$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00043$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00048$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00049$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00050$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00052$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00053$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00054$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00056$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00057$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00058$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00062$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00064$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00065$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00070$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00071$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00072$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00073$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00074$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00075$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00076$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00077$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00078$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00079$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00083$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00084$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00085$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00086$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00090$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00091$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00092$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00093$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00097$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00098$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00099$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00100$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00104$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00105$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00106$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00107$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00111$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00112$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00113$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00114$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00118$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00119$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00120$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00121$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00125$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00126$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00127$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00128$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00132$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00133$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00134$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00135$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00139$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00140$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00141$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00142$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00143$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00144$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00148$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00149$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00150$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00151$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00155$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00156$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00157$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00158$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00162$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00166$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00167$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00168$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00169$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00170$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00171$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00172$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00173$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018678C00174$$` ON `XDB`.`XDB$COMPLEX_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$COMPLEX_TYPE_AK` ON `XDB`.`XDB$COMPLEX_TYPE` (SYS_OP_R2O(`XMLDATA`.`ALL_KID`)) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$COMPLEX_TYPE_CK` ON `XDB`.`XDB$COMPLEX_TYPE` (SYS_OP_R2O(`XMLDATA`.`CHOICE_KID`)) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$COMPLEX_TYPE_SK` ON `XDB`.`XDB$COMPLEX_TYPE` (SYS_OP_R2O(`XMLDATA`.`SEQUENCE_KID`)) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$CONFIG` OF XMLTYPE 
 XMLTYPE STORE AS SECUREFILE BINARY XML (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
   XMLSCHEMA `http://xmlns.oracle.com/xdb/xdbconfig.xsd` ELEMENT `xdbconfig` DISALLOW NONSCHEMA 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP TRIGGER IF EXISTS `XDB`.`XDB$CONFIG$xd`;

DELIMITER //

CREATE TRIGGER `XDB`.`XDB$CONFIG$xd` after delete or update on `XDB`.`XDB$CONFIG` for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$CONFIG', old.sys_nc_oid$, '9DB6E210DBE151C2E0531600000ACDF2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$CONFIG', old.sys_nc_oid$, '9DB6E210DBE151C2E0531600000ACDF2', user() ); END IF; END;
//

DELIMITER ;


/* ALTER TRIGGER `XDB`.`XDB$CONFIG$xd` ENABLE; */
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  DROP TRIGGER IF EXISTS `XDB`.`XDBCONFIG_VALIDATE`;

  DELIMITER //

  CREATE TRIGGER `XDB`.`XDBCONFIG_VALIDATE` before insert or update
on xdb.XDB$CONFIG for each row
  declare xdoc longtext;
begin
  set xdoc = new.sys_nc_rowinfo$;
  xmltype.schemaValidate(xdoc);
end;
//

DELIMITER ;


/* ALTER TRIGGER `XDB`.`XDBCONFIG_VALIDATE` ENABLE; */

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004880` ON `XDB`.`XDB$CONFIG` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019462C00003$$` ON `XDB`.`XDB$CONFIG` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$DBFS_VIRTUAL_FOLDER` 
   (	`HIDDEN_DEF` DOUBLE DEFAULT 1, 
	`MOUNT_PATH` VARCHAR(4000) NOT NULL, 
	 CONSTRAINT `SNGLEROW` UNIQUE (`HIDDEN_DEF`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SNGLEROW` ON `XDB`.`XDB$DBFS_VIRTUAL_FOLDER` (`HIDDEN_DEF`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$DXPTAB` 
   (	`IDXOBJ#` DOUBLE, 
	`PATHTABOBJ#` DOUBLE NOT NULL, 
	`FLAGS` DOUBLE, 
	`RAWSIZE` DOUBLE, 
	`PARAMETERS` "SYS"."XMLTYPE" , 
	`PENDTABOBJ#` DOUBLE, 
	`SNAPSHOT` VARBINARY(20), 
	`TABLESPACE` VARCHAR(128), 
	`TABLE_ATTRS` VARCHAR(4000), 
	`NBPENDTABOBJ#` DOUBLE, 
	`NBERRTABOBJ#` DOUBLE, 
	 CONSTRAINT `XDB$DXPTABPK` PRIMARY KEY (`IDXOBJ#`)
   ) 
 XMLTYPE COLUMN `PARAMETERS` STORE AS SECUREFILE CLOB (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_IL0000019405C00006$$` ON `XDB`.`XDB$DXPTAB` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `XDB$DXPTABPK` ON `XDB`.`XDB$DXPTAB` (`IDXOBJ#`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `XDB$IDXPTAB` ON `XDB`.`XDB$DXPTAB` (`PATHTABOBJ#`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$D_LINK` 
   (	`SOURCE_ID` VARBINARY(16), 
	`TARGET_ID` VARBINARY(16), 
	`TARGET_PATH` VARCHAR(4000), 
	`FLAGS` VARBINARY(8)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE INDEX `XDB$D_LINK_SOURCE_ID` ON `XDB`.`XDB$D_LINK` (`SOURCE_ID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$D_LINK_TARGET_ID` ON `XDB`.`XDB$D_LINK` (`TARGET_ID`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ELEMENT` OF XMLTYPE(	REF(`XMLDATA`.`PROPERTY`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`SMPL_TYPE_DECL`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`TYPE_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`PROPERTY`.`PROPREF_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`CPLX_TYPE_DECL`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`HEAD_ELEM_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `element` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PROPERTY`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SUBS_GROUP_REFS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNIQUES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`KEYS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`KEYREFS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004836` ON `XDB`.`XDB$ELEMENT` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00004$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00005$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00007$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00031$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00032$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00033$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00058$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00067$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00068$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018944C00069$$` ON `XDB`.`XDB$ELEMENT` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$ELEMENT_HER` ON `XDB`.`XDB$ELEMENT` (SYS_OP_R2O(`XMLDATA`.`HEAD_ELEM_REF`)) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$ELEMENT_PR` ON `XDB`.`XDB$ELEMENT` (SYS_OP_R2O(`XMLDATA`.`PROPERTY`.`PROPREF_REF`)) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$ELEMENT_PROPNAME` ON `XDB`.`XDB$ELEMENT` (`XMLDATA`.`PROPERTY`.`NAME`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$ELEMENT_PROPNUMBER` ON `XDB`.`XDB$ELEMENT` (`XMLDATA`.`PROPERTY`.`PROP_NUMBER`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$ELEMENT_PS` ON `XDB`.`XDB$ELEMENT` (SYS_OP_R2O(`XMLDATA`.`PROPERTY`.`PARENT_SCHEMA`)) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$ELEMENT_TR` ON `XDB`.`XDB$ELEMENT` (SYS_OP_R2O(`XMLDATA`.`PROPERTY`.`TYPE_REF`)) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$GROUP_DEF` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`ALL_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`CHOICE_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`SEQUENCE_KID`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `group` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004840` ON `XDB`.`XDB$GROUP_DEF` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019008C00004$$` ON `XDB`.`XDB$GROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019008C00005$$` ON `XDB`.`XDB$GROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019008C00007$$` ON `XDB`.`XDB$GROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019008C00013$$` ON `XDB`.`XDB$GROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019008C00014$$` ON `XDB`.`XDB$GROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019008C00015$$` ON `XDB`.`XDB$GROUP_DEF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$GROUP_REF` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`GROUPREF_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `group` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004841` ON `XDB`.`XDB$GROUP_REF` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019022C00004$$` ON `XDB`.`XDB$GROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019022C00005$$` ON `XDB`.`XDB$GROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019022C00007$$` ON `XDB`.`XDB$GROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019022C00014$$` ON `XDB`.`XDB$GROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019022C00015$$` ON `XDB`.`XDB$GROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019022C00016$$` ON `XDB`.`XDB$GROUP_REF` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$H_INDEX` 
   (	`OID` VARBINARY(16), 
	`ACL_ID` VARBINARY(16), 
	`OWNER_ID` VARBINARY(16), 
	`FLAGS` VARBINARY(4), 
	`CHILDREN` LONGBLOB
   ) 
 ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_IL0000018460C00005$$` ON `XDB`.`XDB$H_INDEX` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$H_INDEX_OID_I` ON `XDB`.`XDB$H_INDEX` (`OID`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$H_LINK` OF `XDB`.`XDB$LINK_T` 
   ( CONSTRAINT `XDB_PK_H_LINK` PRIMARY KEY(`PARENT_OID`, `NAME`)
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX`  ENABLE
   ) OIDINDEX  ( PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ) 
 PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004830` ON `XDB`.`XDB$H_LINK` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB_H_LINK_CHILD_OID` ON `XDB`.`XDB$H_LINK` (`CHILD_OID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `XDB_PK_H_LINK` ON `XDB`.`XDB$H_LINK` (`PARENT_OID`, `NAME`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$IMPORT_NM_INFO` 
   (	`NMSPCURI` VARCHAR(2000), 
	`ID` VARBINARY(8)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$IMPORT_PT_INFO` 
   (	`PATH` VARBINARY(2000), 
	`ID` VARBINARY(8)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$IMPORT_QN_INFO` 
   (	`NMSPCID` VARBINARY(8), 
	`LOCALNAME` VARCHAR(2000), 
	`FLAGS` VARBINARY(4), 
	`ID` VARBINARY(8)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$IMPORT_TT_INFO` 
   (	`GUID` VARBINARY(16), 
	`NMSPCID` VARBINARY(8), 
	`LOCALNAME` VARCHAR(2000), 
	`FLAGS` VARBINARY(4), 
	`ID` VARBINARY(8)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$MOUNTS` 
   (	`DOBJ#` DOUBLE, 
	`DPATH` VARCHAR(4000), 
	`SOBJ#` DOUBLE, 
	`SPATH` VARCHAR(4000), 
	`FLAGS` DOUBLE
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$NLOCKS` OF `XDB`.`XDB$NLOCKS_T` 
 OIDINDEX  ( PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ) 
 PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004846` ON `XDB`.`XDB$NLOCKS` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$NLOCKS_CHILD_NAME_IDX` ON `XDB`.`XDB$NLOCKS` (`CHILD_NAME`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$NLOCKS_PARENT_OID_IDX` ON `XDB`.`XDB$NLOCKS` (`PARENT_OID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$NLOCKS_RAWTOKEN_IDX` ON `XDB`.`XDB$NLOCKS` (`RAWTOKEN`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$NONCEKEY` 
   (	`NONCEKEY` CHAR(32)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$PATH_INDEX_PARAMS` 
   (	`MOUNT_POINT` VARCHAR(2000), 
	`ENUM_COL_CLAUSE` VARCHAR(2000), 
	`NAME` VARCHAR(128), 
	`CONNECT_CLAUSE` VARCHAR(2000)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`XDB$RCLIST_V` (`RCLIST`) AS 
  (select rclist from xdb.xdb$root_info);
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$REPOS` 
   (	`OBJ#` DOUBLE NOT NULL, 
	`FLAGS` DOUBLE, 
	`ROOTINFO#` DOUBLE, 
	`HINDEX#` DOUBLE, 
	`HLINK#` DOUBLE, 
	`RESOURCE#` DOUBLE, 
	`ACL#` DOUBLE, 
	`CONFIG#` DOUBLE, 
	`DLINK#` DOUBLE, 
	`NLOCKS#` DOUBLE, 
	`STATS#` DOUBLE, 
	`CHECKOUTS#` DOUBLE, 
	`RESCONFIG#` DOUBLE, 
	`WKSPC#` DOUBLE, 
	`VERSHIST#` DOUBLE, 
	`PARAMS` "SYS"."XMLTYPE" 
   ) 
 XMLTYPE COLUMN `PARAMS` STORE AS SECUREFILE BINARY XML (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ALLOW NONSCHEMA DISALLOW ANYSCHEMA ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$RESCONFIG` OF XMLTYPE 
 XMLTYPE STORE AS SECUREFILE BINARY XML (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
   XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBResConfig.xsd` ELEMENT `ResConfig` DISALLOW NONSCHEMA 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP TRIGGER IF EXISTS `XDB`.`XDB$RESCONFIG$xd`;

DELIMITER //

CREATE TRIGGER `XDB`.`XDB$RESCONFIG$xd` after delete or update on `XDB`.`XDB$RESCONFIG` for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', old.sys_nc_oid$, '9DB6E210D8A851C2E0531600000ACDF2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', old.sys_nc_oid$, '9DB6E210D8A851C2E0531600000ACDF2', user() ); END IF; END;
//

DELIMITER ;


/* ALTER TRIGGER `XDB`.`XDB$RESCONFIG$xd` ENABLE; */

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004850` ON `XDB`.`XDB$RESCONFIG` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019350C00003$$` ON `XDB`.`XDB$RESCONFIG` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$RESOURCE` OF XMLTYPE(	REF(`XMLDATA`.`XMLREF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`XMLREF`) ALLOW PRIMARY KEY
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBResource.xsd` ELEMENT `Resource` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB(`XMLDATA`.`XMLLOB`) STORE AS SECUREFILE (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB(`XMLDATA`.`RESEXTRA`) STORE AS SECUREFILE (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`PARENTS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SBRESEXTRA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB(`XMLDATA`.`ATTRCOPY`) STORE AS SECUREFILE (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB(`XMLDATA`.`CTSCOPY`) STORE AS SECUREFILE (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RCLIST`.`OID` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004845` ON `XDB`.`XDB$RESOURCE` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00004$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00005$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00025$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00027$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00030$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00031$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00033$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00034$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019124C00037$$` ON `XDB`.`XDB$RESOURCE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$RESOURCE_ACLOID_IDX` ON `XDB`.`XDB$RESOURCE` (`XMLDATA`.`ACLOID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `XDB$RESOURCE_OID_INDEX` ON `XDB`.`XDB$RESOURCE` (SYS_OP_R2O(`XMLDATA`.`XMLREF`)) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDBHI_IDX` ON `XDB`.`XDB$RESOURCE` (OBJECT_VALUE) 
   INDEXTYPE IS `XDB`.`XDBHI_IDXTYP` ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$ROOT_INFO` 
   (	`RESOURCE_ROOT` CHAR(10), 
	`RCLIST` VARBINARY(2000), 
	`FTP_PORT` INT, 
	`FTP_PROTOCOL` VARCHAR(4000), 
	`HTTP_PORT` INT, 
	`HTTP_PROTOCOL` VARCHAR(4000), 
	`HTTP_HOST` VARCHAR(4000), 
	`HTTP2_PORT` INT, 
	`HTTP2_PROTOCOL` VARCHAR(4000), 
	`HTTP2_HOST` VARCHAR(4000), 
	`NFS_PORT` INT, 
	`NFS_PROTOCOL` VARCHAR(4000), 
	`RHTTP_PORT` INT, 
	`RHTTP_PROTOCOL` VARCHAR(4000), 
	`RHTTP_HOST` VARCHAR(4000), 
	`RHTTPS_PORT` INT, 
	`RHTTPS_PROTOCOL` VARCHAR(4000), 
	`RHTTPS_HOST` VARCHAR(4000)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE OR REPLACE VIEW `XDB`.`XDB$ROOT_INFO_V` (`RESOURCE_ROOT`, `RCLIST`, `FTP_PORT`, `FTP_PROTOCOL`, `HTTP_PORT`, `HTTP_PROTOCOL`, `HTTP_HOST`, `HTTP2_PORT`, `HTTP2_PROTOCOL`, `HTTP2_HOST`, `NFS_PORT`, `NFS_PROTOCOL`, `RHTTP_PORT`, `RHTTP_PROTOCOL`, `RHTTP_HOST`, `RHTTPS_PORT`, `RHTTPS_PROTOCOL`, `RHTTPS_HOST`) AS 
  select `RESOURCE_ROOT`,`RCLIST`,`FTP_PORT`,`FTP_PROTOCOL`,`HTTP_PORT`,`HTTP_PROTOCOL`,`HTTP_HOST`,`HTTP2_PORT`,`HTTP2_PROTOCOL`,`HTTP2_HOST`,`NFS_PORT`,`NFS_PROTOCOL`,`RHTTP_PORT`,`RHTTP_PROTOCOL`,`RHTTP_HOST`,`RHTTPS_PORT`,`RHTTPS_PROTOCOL`,`RHTTPS_HOST` from xdb.xdb$root_info;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$SCHEMA` OF XMLTYPE 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `schema` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ELEMENTS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SIMPLE_TYPE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`COMPLEX_TYPES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ATTRIBUTES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`IMPORTS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`INCLUDES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATIONS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`GROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ATTRGROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`NOTATIONS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004844` ON `XDB`.`XDB$SCHEMA` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00004$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00005$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00015$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00016$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00017$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00018$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00019$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00020$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00022$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00023$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00026$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00027$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019070C00031$$` ON `XDB`.`XDB$SCHEMA` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$SCHEMA_URL` ON `XDB`.`XDB$SCHEMA` (`XMLDATA`.`SCHEMA_URL`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$SEQUENCE_MODEL` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `sequence` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ELEMENTS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`CHOICE_KIDS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SEQUENCE_KIDS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANYS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`GROUPS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004835` ON `XDB`.`XDB$SEQUENCE_MODEL` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00004$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00005$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00007$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00011$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00012$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00013$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00014$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00015$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00016$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00017$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018920C00018$$` ON `XDB`.`XDB$SEQUENCE_MODEL` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$SIMPLE_TYPE` OF XMLTYPE(	REF(`XMLDATA`.`PARENT_SCHEMA`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`RESTRICTION`.`BASE_TYPE`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`RESTRICTION`.`LCL_SMPL_DECL`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`LIST_TYPE`.`TYPE_REF`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID, 
	REF(`XMLDATA`.`LIST_TYPE`.`SIMPLE_TYPE`) -- SQLINES LICENSE FOR EVALUATION USE ONLY
 WITH ROWID
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/XDBSchema.xsd` ELEMENT `simpleType` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`FRACTIONDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`FRACTIONDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`FRACTIONDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`FRACTIONDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`TOTALDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`TOTALDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`TOTALDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`TOTALDIGITS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MINLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MINLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MINLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MINLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAXLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAXLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAXLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAXLENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`LENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`LENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`LENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`LENGTH` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`WHITESPACE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`WHITESPACE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`WHITESPACE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`WHITESPACE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`PERIOD` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`PERIOD` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`PERIOD` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`PERIOD` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`DURATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`DURATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`DURATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`DURATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_INCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MIN_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`MAX_EXCLUSIVE` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`PATTERN` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`ENUMERATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`RESTRICTION`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`LIST_TYPE`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`LIST_TYPE`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`LIST_TYPE`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`LIST_TYPE`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNION_TYPE`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNION_TYPE`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNION_TYPE`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNION_TYPE`.`ANNOTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNION_TYPE`.`SIMPLE_TYPES` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`UNION_TYPE`.`TYPE_REFS` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`SYS_XDBPD$` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`APPINFO` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`ANNOTATION`.`DOCUMENTATION` STORE AS SECUREFILE LOB 
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004831` ON `XDB`.`XDB$SIMPLE_TYPE` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00004$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00005$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00007$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00011$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00016$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00017$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00018$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00019$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00023$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00024$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00025$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00026$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00030$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00031$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00032$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00033$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00037$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00038$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00039$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00040$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00044$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00045$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00046$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00047$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00051$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00052$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00053$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00054$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00058$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00059$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00060$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00061$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00065$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00066$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00067$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00068$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00072$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00073$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00074$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00075$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00079$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00080$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00081$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00082$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00086$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00087$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00088$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00089$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00093$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00094$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00095$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00096$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00100$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00101$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00102$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00103$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00104$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00106$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00107$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00108$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00109$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00114$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00115$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00116$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00117$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00119$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00120$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00121$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00122$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000018536C00123$$` ON `XDB`.`XDB$SIMPLE_TYPE` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$STATS` OF XMLTYPE( CONSTRAINT `STATS_PK` PRIMARY KEY(`XMLDATA`.`RESOID`)
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX`  ENABLE
   ) 
  XMLSCHEMA `http://xmlns.oracle.com/xdb/stats.xsd` ELEMENT `ContainerStats` PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
 VARRAY `XMLEXTRA`.`NAMESPACES` STORE AS BASICFILE LOB `NAMESPACES203_L`
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  CACHE 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLEXTRA`.`EXTRADATA` STORE AS BASICFILE LOB `EXTRADATA202_L`
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  CACHE 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY `XMLDATA`.`SYS_XDBPD$` STORE AS BASICFILE LOB `SYS_XDBPD$201_L`
  ( TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  CACHE 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP TRIGGER IF EXISTS `XDB`.`XDB$STATS$xd`;

DELIMITER //

CREATE TRIGGER `XDB`.`XDB$STATS$xd` after delete or update on `XDB`.`XDB$STATS` for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', old.sys_nc_oid$, 'E8637ACC309F27DCE0530100007F32DC' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', old.sys_nc_oid$, 'E8637ACC309F27DCE0530100007F32DC', user() ); END IF; END;
//

DELIMITER ;


/* ALTER TRIGGER `XDB`.`XDB$STATS$xd` ENABLE; */

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `STATS_PK` ON `XDB`.`XDB$STATS` (`XMLDATA`.`RESOID`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_C00621904` ON `XDB`.`XDB$STATS` (`SYS_NC_OID$`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0001637073C00004$$` ON `XDB`.`XDB$STATS` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0001637073C00005$$` ON `XDB`.`XDB$STATS` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0001637073C00007$$` ON `XDB`.`XDB$STATS` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$TSETMAP` 
   (	`GUID` VARBINARY(16) NOT NULL, 
	`TYPE` DOUBLE NOT NULL, 
	`OBJ#` DOUBLE NOT NULL, 
	 CONSTRAINT `XDB$TSETMAP_UNIQ1` UNIQUE (`GUID`, `TYPE`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `XDB$TSETMAP_UNIQ1` ON `XDB`.`XDB$TSETMAP` (`GUID`, `TYPE`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$TTSET` 
   (	`GUID` VARBINARY(16), 
	`TOKSUF` VARCHAR(26), 
	`FLAGS` DOUBLE, 
	`OBJ#` DOUBLE, 
	 UNIQUE (`OBJ#`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_C004828` ON `XDB`.`XDB$TTSET` (`OBJ#`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$XDB_READY` 
   (	`DATA` LONGTEXT
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE GLOBAL TEMPORARY TABLE `XDB`.`XDB$XIDX_IMP_T` 
   (	`INDEX_NAME` VARCHAR(138), 
	`SCHEMA_NAME` VARCHAR(138), 
	`ID` VARCHAR(40), 
	`DATA` LONGTEXT, 
	`GRPPOS` DOUBLE
   ) ON COMMIT PRESERVE ROWS 
 LOB(`DATA`) STORE AS BASICFILE (
  ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE ) ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$XIDX_PARAM_T` 
   (	`USERID` DOUBLE, 
	`PARAM_NAME` VARCHAR(128), 
	`PARAMSTR` LONGTEXT
   ) 
 ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_IL0000019415C00003$$` ON `XDB`.`XDB$XIDX_PARAM_T` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `XDB$IDXPARAM` ON `XDB`.`XDB$XIDX_PARAM_T` (`USERID`, `PARAM_NAME`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$XIDX_PART_TAB` 
   (	`IDXOBJ#` DOUBLE NOT NULL, 
	`PART_NAME` VARCHAR(128) NOT NULL, 
	`TABLESPACE` VARCHAR(128), 
	`PARTITION_ATTRS` VARCHAR(4000), 
	 CONSTRAINT `XDB$XIDX_PART_TAB_PK` PRIMARY KEY (`IDXOBJ#`, `PART_NAME`)
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `XDB$XIDX_PART_TAB_PK` ON `XDB`.`XDB$XIDX_PART_TAB` (`IDXOBJ#`, `PART_NAME`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$XTAB` 
   (	`IDXOBJ#` DOUBLE NOT NULL, 
	`GROUPNAME` NVARCHAR(128) NOT NULL, 
	`XMLTABOBJ#` DOUBLE NOT NULL, 
	`PTABOBJ#` DOUBLE, 
	`XPATH` VARCHAR(4000) NOT NULL, 
	`XQUERY` LONGTEXT, 
	`FLAGS` DOUBLE, 
	`PARAMETERS` "SYS"."XMLTYPE" , 
	`GRPPOS` DOUBLE, 
	`DEPGRPPOS` DOUBLE, 
	`SEGATTRS` VARCHAR(4000), 
	 CONSTRAINT `XDB$XTABPK` PRIMARY KEY (`IDXOBJ#`, `GROUPNAME`, `XMLTABOBJ#`)
   ) 
 XMLTYPE COLUMN `PARAMETERS` STORE AS SECUREFILE CLOB (
  TABLESPACE `SYSAUX` ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE UNIQUE INDEX `SYS_IL0000019436C00006$$` ON `XDB`.`XDB$XTAB` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `SYS_IL0000019436C00009$$` ON `XDB`.`XDB$XTAB` (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE `SYSAUX` 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$IDXXTAB_1` ON `XDB`.`XDB$XTAB` (`IDXOBJ#`, `GROUPNAME`, `PTABOBJ#`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE INDEX `XDB$IDXXTAB_2` ON `XDB`.`XDB$XTAB` (`IDXOBJ#`, `DEPGRPPOS`, `XMLTABOBJ#`) 
   ;
  -- SQLINES LICENSE FOR EVALUATION USE ONLY
  CREATE UNIQUE INDEX `XDB$XTABPK` ON `XDB`.`XDB$XTAB` (`IDXOBJ#`, `GROUPNAME`, `XMLTABOBJ#`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$XTABCOLS` 
   (	`IDXOBJ#` DOUBLE NOT NULL, 
	`GROUPNAME` NVARCHAR(128) NOT NULL, 
	`XMLTABOBJ#` DOUBLE NOT NULL, 
	`COLNAME` NVARCHAR(2000) NOT NULL, 
	`COLTYPE` NVARCHAR(100) NOT NULL, 
	`XPATH` VARCHAR(4000) NOT NULL, 
	`FLAGS` DOUBLE NOT NULL
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE INDEX `XDB$IDXTABCOLS_1` ON `XDB`.`XDB$XTABCOLS` (`IDXOBJ#`, `GROUPNAME`, `XMLTABOBJ#`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB$XTABNMSP` 
   (	`IDXOBJ#` DOUBLE NOT NULL, 
	`GROUPNAME` NVARCHAR(128) NOT NULL, 
	`XMLTABOBJ#` DOUBLE NOT NULL, 
	`PREFIX` NVARCHAR(128), 
	`NAMESPACE` NVARCHAR(2000), 
	`FLAGS` DOUBLE NOT NULL
   ) 
   ;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE INDEX `XDB$IDXTABNMSP_1` ON `XDB`.`XDB$XTABNMSP` (`IDXOBJ#`, `GROUPNAME`, `XMLTABOBJ#`, `FLAGS`) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
CREATE TABLE `XDB`.`XDB_INDEX_DDL_CACHE` 
   (	`ROOT_TABLE_NAME` VARCHAR(128), 
	`ROOT_TABLE_OWNER` VARCHAR(128), 
	`ROOT_COL_NAME` VARCHAR(128), 
	`TABLE_NAME` VARCHAR(128), 
	`TABLE_OWNER` VARCHAR(128), 
	`IDX_OWNER` VARCHAR(128), 
	`IDX_TABLE_NAME` VARCHAR(128), 
	`IDX_NAME` VARCHAR(128), 
	`IDX_TYPE` VARCHAR(27), 
	`CONSTR_NAME` VARCHAR(128), 
	`CONSTR_OWNER` VARCHAR(128)
   ) 
 ;
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP FUNCTION IF EXISTS XDB.contentSchemaIs;

DELIMITER //

CREATE function XDB.contentSchemaIs wrapped
declare a000000
1
abcd
//

DELIMITER ;


abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
1eb 154
7PCJFPfZ1LSmNAj4ehpET9E/1LAwg43IfyAVfC8C2v7qbnVnGARU2q2LykkxF/W8Z2XplOb8
4aSXterwtutN/Rm5QZqwEiCxwlyedMG7BXPAmMZOsUOSoSQMr+fbL/hTuTTr+amUNGr2ZJT+
cHbwtNSF6CM90MtzdkuXpjV5Aje6D4xdsund3My0V3CG82/fS2YeL3nWGXSOH49Nb+8A9QUj
kBUCK1bLgBXryIl/g/SgN37Njstg08XMhhbRsB5JczFg4Fx8YQ1s9iFa+jrjKMwCMA/w1oQZ
9oKyqrWZxcFiQHqOanfbqmoDX1jDK68l2FE9xgWWMHB5sw==
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP FUNCTION IF EXISTS XDB.get_xdb_tablespace;

DELIMITER //

CREATE FUNCTION XDB.get_xdb_tablespace wrapped
declare a000000
1
abcd
//

DELIMITER ;


abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
f3 107
yGrBq9SjQ7pfVFABbFo0k+ST6bYwgwFK7csVfHRGWPiOHMhFf0tgdDp/oE0u3dwOWcyZlJkd
06QwzwkYRjYlLryYcsTLK/glk1MzhM+HRVegVTuqaAXHKEYiyALWFExao6xddA6gOf2WXAI0
t6v73U3shiJX0BunYJGeeGMu+qFflCcommCgwtRGCLnQDRvqHU8w8wQ+ew0u11c67/xUymMH
u2qikzUZBCpJkR9aC9HCjvhH+TdtUsuj78mW0cRneQ==
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP FUNCTION IF EXISTS XDB.under_path_func;

DELIMITER //

CREATE function XDB.under_path_func wrapped
declare a000000
1
abcd
//

DELIMITER ;


abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
49f 32b
k/KtW5jxRk5MAOCs9qJ+rwr+UCkwg41ezCCDfC8Zgp0GHHvzFImUoM1r4wfIV3A+tPfNftI+
Ua9cUBGs8XxNdyyaAx1sE2EmbY6tM7/+ELy70TgVz+mt1oQts1xFD3hCkjAWZYAvvZuHRQoB
GrkLZUap2yf7VpP/4wTmKBm12xwbP05GnaXbMOd3A9t6pT4B+5M6J4Gqz9OCqWWP9KxcfMcI
TFCJ0QfKahE/vAYOSePyNtogN/KMOPL7JPMmc92CNeYDnHFZLzOYZZx8HVps4t1jjhfkQx7d
Dl9bFAEZ8eTzsj5OUZnkQEpIxk9ifmj05/YmBdncI4JlxuES5/0I4rqJAnpapy2EAP7N3dNE
A2NZs7dXzNG83qKIUpJRekh4SztrtZusPJisObXjM9lRs7CL0yBun2O77l/YfJnrERGSB9Qt
FBhnYqUGYTIXAyCyKjj71C6D2QU2jJL/Gsf6ff5VjpLxotvqyJiVkqFqC1wir95OuLewmHkI
HcBNEzI93VIFXchDBVUbYi20KSDrXXcjsAM5/MF7YmW2wMdj5fVMHOVZan+xjUCXgyoCmOsO
2fGN6TgWHEE4D3nZnjMe8h/Xk7nFTCvOH1hNkPkmv0uzMjzEKggEbTOoXRU8p1qXixcLWYHz
wVIKH9NDlnzxZZVk1iotBN+6r78LT7X3UpSbRkRiJVh/oDsDahszJIHXm5mcUgURg2vQU9tP
BuAQFxT3npy+o1eL20qyYYL0C2Z2WEdLL8HFKkazpfGtBA7VeW7XoAC7Yc+RlvNruQ9b+7H6
B+qfRRQx
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP PROCEDURE IF EXISTS XDB.xdb_datastore_proc;

DELIMITER //

CREATE PROCEDURE XDB.xdb_datastore_proc(IN rid CHAR(10),
                                                   INOUT outlob LONGTEXT)
BEGIN
  xdb.dbms_xdbt.xdb_datastore_proc(rid, outlob);
END;
//

DELIMITER ;



-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP FUNCTION IF EXISTS XDB.xdb$ExtName2IntName;

DELIMITER //

CREATE function XDB.xdb$ExtName2IntName
  (schemaURL VARCHAR(4000), schemaOwner VARCHAR(4000) = )
returns varchar(4000) declare authid current_user deterministic
//

DELIMITER ;


is external name `EXT2INT_NAME` library XMLSCHEMA_LIB -- SQLINES LICENSE FOR EVALUATION USE ONLY
 with context
parameters (context, schemaURL OCIString, schemaOwner OCIString,
            return INDICATOR sb4, return OCIString);

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP PROCEDURE IF EXISTS XDB.xdb$InitXDBSchema;

DELIMITER //

CREATE procedure XDB.xdb$InitXDBSchema()
 begin declare language C name
//

DELIMITER ;

 `INIT_XDBSCHEMA`
 library XMLSCHEMA_LIB;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP PROCEDURE IF EXISTS XDB.xdb$patchupDeleteSchema;

DELIMITER //

CREATE procedure XDB.xdb$patchupDeleteSchema ( wrapped
a000000)
DECLARE 1
abcd
abcd
//

DELIMITER ;


abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
75b 2c9
PgsK4fTQHksnxgNZMRyt9YydDVwwg2NczPYFfC8ZA6qVAI7FAy/JKDw1g6lWTwuyBWXxWbdJ
szI3In5QB8uSTr9KXngIiqIxRvDwrv4pufi5ag0r4etg7zT5zj+B5KWbztL4rVX5aLx+14br
M7EdgmbqZUTXuxc10V5GRXzcK2/qTYTIG1q4bArKpn3i6Ny+6VSw+m651WuXRd0NAxOr+z5I
UOH/sQE1Bc5oIaH9UquCHb/KUy3Yfp7V3v2MVcGnr+ECRPIXZtK0T95cSrEbesK7xxToR9RX
XNqk1RuSYNNIuFuOCf1X6vp45dn6dx2N6ilXydcqKzz34VSbL0icUPTu9DrLwwjTocVNiQLl
Pp4o6FMp3maJePBxqPAyYde7UxH0sKcBRH6WAuP5ixRTWfQR3/PjHZbMUT45u9wvV8Ooq5wr
27ANeThKuAYDwEBtof4vY2xDX/3GU40rLnMoGQi/1/fyID1uYZe9t12FXrFRoCoP4InebRFc
jGET+77E2QANHCs60JPGETQN3ZyhegSB+ROaiSxuADUVbIYiPfrcFND3JEYYcm/fBBBY+wVz
o6elPjYTCw3ayY8C0YhZUC5LROtPt5TP6W+06cBxuumq1ckNVlhc3F1xgqPSoyoBrOyy0xe4
c0UPsTjnLO7Hz05D9gQcqrtg3pZq2qgA+pkY73+oA+lncpUHJHeYJi8=
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP PROCEDURE IF EXISTS XDB.xdb$paTchupschema;

DELIMITER //

CREATE procedure XDB.xdb$paTchupschema ( wrapped
a000000)
DECLARE 1
abcd
abcd
//

DELIMITER ;


abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
4c48 77a
/zF/rlBVDdIfVeDVcY70bwxsI4Ewg81xBUqM3wS5MkEVH9WyWswhWAXeK8DdDMhXlBPcwAJh
BfISXt5j5Qksnd+wcHxhqDemExbv8KxzLJ21qS30BlDmn9PvpZpPqs+SCI3P+Pm70Kq8ELUe
u2Q5Ydx/kuG0LLyPVTH+hWzmukv77ST70vNKqf2pmjh+kHDkyeEfXuaJB6SjDg5zvK1mxrLf
iuGbyOmp8Bb45tN7bMo4rUMMdpJYcZ/h7b9777Ub97K94Rf4U4yqT0segBzyiFKpZ2Ccptv1
a2qP0ax/nlryoWYsrB2FiLM4LEmXU8cObTXIMIn2E6gUFJ/QvXNELt3Xnlgjwb2BjEgIKVr3
n1IEa3VxI3yUcsiTsU4JJKD3ePDCPD71YiFsgF8/DGl8Yq4EcQQnLEMlj5vK/9x2G8wn69Lf
6U2LaAb0U38H3AqajYYRe59sQpP/AVh/t31p+PPr2FhDWSek2baF3eIt7FzCW3xLZDKuY8M+
frV3Pok8GDQDw6NIRUq0epV+9VpdGJeGUnBjL+W6TFwjJsQZpBq7AakcmmvK/2yClzPjKoDb
RxKozNmE8i7A6/cY4Mk71qYIMY3AbwNEzIC4M6HheHSmYlBDKNPzvmEBZYguXA6xyspnZ0NG
Na037/I1gNmYr0c4LBBuJarTBiM+zSC/y2ZCxHRikV3tuW/ngNSl1kY1Bv3hmemJYxLciP3r
aG9z/m+KxI89eoqaDKGn+2po+gKzX6xJvP83fyqjo5M7qIC5W2hSBSWJ404ZqJg6cDmO3EH/
qliaTWszqcShdj9p4QdzaKbRsefkkohuUFhGd+HU2R4ebULHcwSyyDurgsE2QpY4Ls3g1YDD
BcxFRJL3oaB56VzfTBswqkGg5dJNhz+QNXRy3ReZx4NmwFjoPKQCXs7NA9GhQgkbg/p98gos
2IjQE/IWJDwIFe/SfQ7soTOW6GjNY3TsHJbXZc+kcN2S3q6/iRTakMzM/+1mSj/0ysVPPrH8
kbc5Qi1sh0+muYaxurmSlK7vo6bj8+hSAfOj4J+A421Svph0Uq+tmowMEZukCmoAmmMiGYCj
80vsiTKnAtsiEwieNdnPcxIFAlHOPOihgxzMzOU59II4PE+gRfFb3SDR4/yX/xArJTrGQWLn
SiiYLoApR95UqAN34cL8kSfjpdE4UR1z6ZG6WKj4SRls3UHfUhbdmVtzAIlpZ0EXLWDdeF9T
ZlMfrH9isxWCcxbl4w5kcKDspmmI9e04S2hHJKxmq6hLJZ7KeItZj7XIaK3+/VAIXtJZA0i1
uiUNn8Wu4yKoko8h5U28mYR9VW3kVh4z4dMWMFFO9P89Q/8imQ3HxotTHq+CcQZMIAU6RkO2
p4KunJmWXQsioXVVajeUxJyuovkU44qqn/1JxsAKPuigVuP07kkcUil8hE50P7LdpyYSuJ3a
u6PsjsB+VFGm2ZE16BuoQOFt0GOr7CEqrFMl6DBypgPe/L51Gl2eQ3F8M0qsZdQ2nn5IxOrr
V1VtgdOBFGDMkCJ5781GDpDCHpWTR+By3rJ6fTsLcj4j1QJWm68TM/nB1z2VUZM7sochHLjs
kHziwdTiKT1hJcB4JotCCEUwiHn7qtGMDdQIPH5PDzz+2Y2GUBQOwRXwyWeximhGWRx6i1MI
tPoPiI15U5c9XqnWlXVQWA0dpXm/yR8K8FVxz62ymnHQudr9c0YehZjL+oDKkQ0pEwoy5dCM
Wvbom92qzX/FLOpuOtKHoA7Sr+hYfYlKfUugl6mN1WD2ATC88DND1OKzzL/wDdRaVdUZ/FJD
BUmDSsFbhYzQqkJA6wopiKvWZqEHRo/j+4UTabVcyicXFmppffMBFsVWraMW387iZm/abq4L
80Qz+Ja1HWlCnDE=
;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP FUNCTION IF EXISTS XDB.XMLIndexInsFunc;

DELIMITER //

CREATE function XDB.XMLIndexInsFunc
       returns XDB.XMLIndexTab_t
declare authid current_user
pipelined
//

DELIMITER ;

 using XDB.XMLIndexLoad_Imp_t;

-- SQLINES LICENSE FOR EVALUATION USE ONLY
DROP FUNCTION IF EXISTS XDB.XMLIndexLoadFunc;

DELIMITER //

CREATE function XDB.XMLIndexLoadFunc(p SYS_REFCURSOR,
                                                flags DOUBLE)
       returns XDB.XMLIndexTab_t
declare authid current_user
parallel_enable (partition
//

DELIMITER ;

 p by ANY)
pipelined using XDB.XMLIndexLoad_Imp_t;

CALL CreateSequence('XDB.CLIENTID_SEQUENCE', 1, 1) ;

CALL CreateSequence('XDB.STATEID_RESTART_SEQUENCE', 1, 1) ;

CALL CreateSequence('XDB."XDB$NAMESUFF_SEQ"', 1, 1) ;

CALL CreateSequence('XDB."XDB$PROPNUM_SEQ"', 1, 1) ;

CALL CreateSequence('XDB."XDB$TYPEID_SEQ"', 1, 1) ;


