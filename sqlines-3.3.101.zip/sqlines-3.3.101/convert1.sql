-- DROP USER XDB;

CREATE USER XDB
-- IDENTIFIED BY <password>
;

CREATE OR REPLACE TYPE XDB."ChildNameCollTyp" AS VARRAY(2147483647) OF VARCHAR2(4000 CHAR);

CREATE OR REPLACE TYPE XDB."ContainerStatsTyp" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","RESOID" RAW(32),"TotalRows" NUMBER,"TotalContainers" NUMBER,"FanOut" NUMBER(38),"ImmediateContainers" NUMBER(38),"LastAnalyzedDate" TIMESTAMP)FINAL INSTANTIABLE ;

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_RESMD FORCE as OBJECT (
        path_name varchar2(4000),
	path_oid raw(16)
);

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_RESMDARR AS VARRAY(65536) OF xdb.DBMS_XMLSCHEMA_RESMD;

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_TABMD FORCE as OBJECT (
        schema_name  varchar2(700),
	element_name varchar2(128),
	table_name   varchar2(128),
	table_oid    raw(16)
);

CREATE OR REPLACE TYPE XDB.DBMS_XMLSCHEMA_TABMDARR AS VARRAY(65536) OF xdb.DBMS_XMLSCHEMA_TABMD;

CREATE OR REPLACE TYPE XDB."FolderListingTyp" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","name" VARCHAR2(4000 CHAR),"size" NUMBER(38),"ChildName" "ChildNameCollTyp")NOT FINAL INSTANTIABLE ;

CREATE OR REPLACE type XDB.funcstats
                                      
authid definer as object
(
  -- user-defined function cost and selectivity functions
  j number,

  static function ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList)
    return number,

  -- function to collect index statistics
  static function ODCIStatsCollect(ia sys.ODCIIndexInfo,
                                   options sys.ODCIStatsOptions,
                                   statistics OUT RAW,
                                   env sys.ODCIEnv)
  return number
  is language C
  name "STATSCOLL_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    options,
    options INDICATOR STRUCT,
    statistics,
    statistics INDICATOR,
    statistics LENGTH,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  -- funtion to delete index statistics
  static function ODCIStatsDelete(ia sys.ODCIIndexInfo,
                                  statistics OUT RAW,
                                  env sys.ODCIEnv)
  return number
  is language C
  name "STATSDEL_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    statistics,
    statistics INDICATOR,
    statistics LENGTH,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  -- index cost
  static function ODCIStatsIndexCost(ia sys.ODCIIndexInfo,
                                     sel number,
                                     cost OUT sys.ODCICost,
                                     qi sys.ODCIQueryInfo,
                                     pred sys.ODCIPredInfo,
                                     args sys.ODCIArgDescList,
                                     strt number,
                                     stop number,
                                     depth number,
                                     valarg varchar2,
                                     env sys.ODCIenv)
  return number
  is language C
  name "STATSINDCOST_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    cost,
    cost INDICATOR STRUCT,
    qi,
    qi INDICATOR STRUCT,
    pred,
    pred INDICATOR STRUCT,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    depth,
    depth INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  static function ODCIStatsIndexCost(ia sys.ODCIIndexInfo,
                                     sel number,
                                     cost OUT sys.ODCICost,
                                     qi sys.ODCIQueryInfo,
                                     pred sys.ODCIPredInfo,
                                     args sys.ODCIArgDescList,
                                     strt number,
                                     stop number,
                                     valarg varchar2,
                                     env sys.ODCIenv)
  return number
  is language C
  name "STATSINDCOST1_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    ia,
    ia INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    cost,
    cost INDICATOR STRUCT,
    qi,
    qi INDICATOR STRUCT,
    pred,
    pred INDICATOR STRUCT,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  -- function cost

  static function ODCIStatsFunctionCost(func sys.ODCIFuncInfo,
                                        cost OUT sys.ODCICost,
                                        args sys.ODCIArgDescList,
                                        colval xmltype,
                                        depth number,
                                        valarg varchar2,
                                        env  sys.ODCIEnv)
  return number
  is language C
  name "STATSFUNCCOST_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    func,
    func INDICATOR STRUCT,
    cost,
    cost INDICATOR STRUCT,
    args,
    args INDICATOR,
    colval,
    colval INDICATOR,
    depth,
    depth INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

  static function ODCIStatsFunctionCost(func sys.ODCIFuncInfo,
                                        cost OUT sys.ODCICost,
                                        args sys.ODCIArgDescList,
                                        colval xmltype,
                                        valarg varchar2,
                                        env  sys.ODCIEnv)
  return number
  is language C
  name "STATSFUNCCOST1_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    func,
    func INDICATOR STRUCT,
    cost,
    cost INDICATOR STRUCT,
    args,
    args INDICATOR,
    colval,
    colval INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

   static function ODCIStatsSelectivity(pred sys.ODCIPredInfo,
                                        sel OUT number,
                                        args sys.ODCIArgDescList,
                                        strt number,
                                        stop number,
                                        colval xmltype,
                                        depth number,
                                        valarg varchar2,
                                       env sys.ODCIenv)
  return number
  is language C
  name "STATSSEL_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    pred,
    pred INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    colval,
    colval INDICATOR,
    depth,
    depth INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber),

 -- selectivity for under_path_func1
  static function ODCIStatsSelectivity(pred sys.ODCIPredInfo,
                                       sel OUT number,
                                       args sys.ODCIArgDescList,
                                       strt number,
                                       stop number,
                                       colval xmltype,
                                       valarg varchar2,
                                       env sys.ODCIenv)
  return number
  is language C
  name "STATSSEL1_XDBHI"
  library XDB.RESOURCE_VIEW_LIB
  with context
  parameters (
    context,
    pred,
    pred INDICATOR STRUCT,
    sel,
    sel INDICATOR,
    args,
    args INDICATOR,
    strt,
    strt INDICATOR,
    stop,
    stop INDICATOR,
    colval,
    colval INDICATOR,
    valarg,
    valarg INDICATOR,
    env,
    env INDICATOR STRUCT,
    return OCINumber)
);

CREATE OR REPLACE type XDB.LockTokenListType as varray(2147483647) of VARCHAR2(128);

CREATE OR REPLACE type XDB.path_array                                       
as varray(32000) of xdb.path_linkinfo;

CREATE OR REPLACE type XDB.path_linkinfo                                        wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
79 aa
g0V6zG8egE2xYLkdFQIyNY27Wowwg5n0dLhcFlpW+uNy+kfZ/0cM2cHAdCulv5vAMsvuJY8J
aee4dAhpqal8xsoXKMbK77KEHe+2RC9eXltNFTFq68aVcrOxlKEC9yaI5jWpC8gKD1o0nbBt
5sgLU0BrWBucGx2mqUqkyQ==
;

CREATE OR REPLACE type XDB.token force as object (qnameid raw(8),
                                                  localname varchar(2000),
                                                  nmspcid raw(8))
NOT PERSISTABLE;

CREATE OR REPLACE type XDB.TokenIDs force is varray(10000) of (raw(8))
NOT PERSISTABLE;

CREATE OR REPLACE type XDB.Tokens force is varray(10000) of (xdb.token)
NOT PERSISTABLE;

CREATE OR REPLACE type XDB.xdb$annotation_list_t                                        as
   varray(65535) of xdb.xdb$annotation_t;

CREATE OR REPLACE type XDB.xdb$annotation_t                                        as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  appinfo         xdb.xdb$appinfo_list_t,
  documentation   xdb.xdb$documentation_list_t
)
 alter type     xdb$annotation_t add attribute (id varchar2(128)) cascade;

CREATE OR REPLACE type XDB.xdb$any_t                                        as object
(
  property         xdb.xdb$property_t,
  namespace        varchar2(2000),
  process_contents xdb.xdb$processChoice,
  min_occurs       integer,
  max_occurs       varchar2(20)   /* in string format incl. "unbounded" */
);

CREATE OR REPLACE type XDB.xdb$appinfo_list_t                                        as varray(1000) of xdb.xdb$appinfo_t;

CREATE OR REPLACE type XDB.xdb$appinfo_t                                       
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  anypart         varchar2(4000),
  source          varchar2(4000)
);

CREATE OR REPLACE type XDB.xdb$attrgroup_def_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    name            varchar2(2000),               /* name of the attr group */

    attributes      xdb.xdb$xmltype_ref_list_t,  /* list of attrs within group */
    any_attrs       xdb.xdb$xmltype_ref_list_t,  /* list of anyAttribute decls. */
    attr_groups     xdb.xdb$xmltype_ref_list_t,          /* list of attr groups */

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$attrgroup_ref_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,

    attrgroup_name  xdb.xdb$qname,   /* name of the attribute group being ref-ed */
    attrgroup_ref   ref sys.xmltype,   /* ref of the attr group being ref-ed */

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$complex_derivation_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base            xdb.xdb$qname,

    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,

    /*
     * only one of the foll. can be non-null
     */
    all_kid         ref sys.xmltype,
    choice_kid      ref sys.xmltype,
    sequence_kid    ref sys.xmltype,
    group_kid       ref sys.xmltype,

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$complex_t
                                      
AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    base_type       ref sys.xmltype,      /* applicable for derived types */
    name            varchar2(256),
    abstract        raw(1),
    mixed           raw(1),
    final_info      xdb.xdb$derivationChoice,
    block           xdb.xdb$derivationChoice,

    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,

    /*
     * only one of the foll. can be non-null, else all have to be null.
     */
    all_kid         ref sys.xmltype,
    choice_kid      ref sys.xmltype,
    sequence_kid    ref sys.xmltype,
    group_kid       ref sys.xmltype,

    complexcontent  xdb.xdb$content_t,

    annotation      xdb.xdb$annotation_t,

    sqltype         varchar2(30),                 /* Name of corr. SQL type */
    sqlschema       varchar2(30),     /* Name of schema containing SQL type */
    maintain_dom    raw(1),
    subtype_refs    xdb.xdb$xmltype_ref_list_t,     /* List of refs to subtypes */
    id              varchar2(256),
    simplecont      xdb.xdb$simplecontent_t,
    typeid          integer
)
 alter type     xdb$complex_t modify attribute
(sqltype varchar2(128), sqlschema varchar2(128)) cascade;

CREATE OR REPLACE type XDB.xdb$content_t                                       
as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    mixed           raw(1),

    /* only one of the foll. can be non-null */
    restriction     xdb.xdb$complex_derivation_t,
    extension       xdb.xdb$complex_derivation_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$derivationChoice
                                       as object
(
    value       raw(2),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$documentation_list_t                                       
  as varray(1000) of xdb.xdb$documentation_t;

CREATE OR REPLACE type XDB.xdb$documentation_t                                        as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  anypart         varchar2(4000),
  source          varchar2(4000),
  lang            varchar2(4000)
);

CREATE OR REPLACE type XDB.xdb$element_t                                       
as object
(
    property        xdb.xdb$property_t,
    subs_group      xdb.xdb$qname,
    num_cols        integer,
    nillable        raw(1),
    final_info      xdb.xdb$derivationChoice,
    block           xdb.xdb$derivationChoice,
    abstract        raw(1),
/* XDB extensions */
    mem_inline      raw(1),
    sql_inline      raw(1),
    java_inline     raw(1),
    maintain_dom    raw(1),
    default_table   varchar2(30),
    default_table_schema   varchar2(30),
    table_props     varchar2(2000),              /* table properties string */
    java_classname  varchar2(2000),
    bean_classname  varchar2(2000),
    base_sqlname    varchar2(61),
    cplx_type_decl  ref sys.xmltype,
    subs_group_refs xdb.xdb$xmltype_ref_list_t, /* REFs to all elements for which
                                             * this is the head element
                                             */
    default_xsl     varchar2(2000),     /* URL of default XSL to be applied */
    min_occurs      integer,
    max_occurs      varchar2(20),     /* in string format incl. "unbounded" */
    is_folder       raw(1),
    maintain_order  raw(1),
    col_props       varchar2(2000),             /* column properties string */
    default_acl     varchar2(2000),                   /* URL of default ACL */
    head_elem_ref  ref sys.xmltype,    /* REF to head element of subs. group */
    uniques        xdb.xdb$keybase_list_t,
    keys           xdb.xdb$keybase_list_t,
    keyrefs        xdb.xdb$keybase_list_t,
    is_translatable raw(1),                  /* Is this element translatable */
    xdb_max_occurs  varchar2(20)                            /* xdb:maxOccurs */
)
 alter type     xdb$element_t modify attribute
(default_table          varchar2(128),
 default_table_schema   varchar2(128)
) cascade;

CREATE OR REPLACE type XDB.xdb$enum_t                                       
as object
(
    value       raw(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$enum_values_t                                       
as VARRAY(1000) of varchar2(1024);

CREATE OR REPLACE type XDB.xdb$enum2_t                                       
as object
(
    value       raw(2),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$extra_list_t                                        as varray(65535) of varchar2(2000);

CREATE OR REPLACE type XDB.xdb$facet_list_t                                        as
VARRAY(65535) of xdb.xdb$facet_t;

CREATE OR REPLACE type XDB.xdb$facet_t                                       
as object                 /* String Facet */
(
   sys_xdbpd$       xdb.xdb$raw_list_t,
   annotation       xdb.xdb$annotation_t,
   value            varchar2(2000),
   fixed            raw(1),
   id               varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$formChoice                                       
as object
(
    value       raw(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$group_def_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    name            varchar2(2000),                /* name of the group */
    /*
     * only one of the foll. can be non-null
     */
    all_kid         ref sys.xmltype,
    choice_kid      ref sys.xmltype,
    sequence_kid    ref sys.xmltype,

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$group_ref_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    min_occurs      integer,
    max_occurs      varchar2(20), /* in string format incl. "unbounded" */

    groupref_name   xdb.xdb$qname,       /* name of the group being referenced */
    groupref_ref    ref sys.xmltype,   /* REF of the group being referenced */

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdbhi_im                                        wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
d2d 37c
GpQKlAFO+SClOmqzj4QxCI/Whzowg82nDNATfC/GEoteXzOiFKAJEuV3twsbr5S02AD/hkbD
gVAA0hnQDwU03zRv363RCTYzX8EITiy2RafntT+1kk6j7fnwpnVjWRrdOzwWJsI5KnwdJ7W2
rZX/r7gbrUzdTOyQhruYFJsD21q4V1QXtvKs8r5XZr2hTShfjDdUXRUvFgxw4osx2nc1c9LL
IfE90xpiM00XhJ5YBgL2kUYtcEwOfGJdNWxpZUwEV3/XguidbPNGmUMmx59y2gRd1pVGVr9M
Vou2ZSHfWZi4AnWNxYToYRhSkC4OsvUJO5dYowezjFJ9AS/me61QWfXNkev7qUqp2070Qziv
Y4X6+nlxhaf5PLFLY0Y2dxNjE57yf8aTrdxnzEKSacoeTmQuqlt0uuiKhwQKjgOTmB7VmLBL
+0URhtkedNwF1E9k1/fAof5yuZz08o5zuipVAsWYMQkLo66840iblVG8QDHfSqgupCKE0Wfa
Wi0a2P2NX2XB2gg/ncfC30gVZ/9ds8Lv4Vv6nkawUPaUIxKscYoq67FQ4mCM2ItUkDZB1Rfe
rG4CCuPV/qG+yCS/TI6/QEWWDLoMCx6Yx3YgOcsnxVfvYxDBp/7irGwc/NhMjfu72HPpNiUD
nyh7JlK/IgCirrzumrq6C2q8mkZ2Q/fCP3qHCSBBBgafeMZKNS0/mReZIJ8DbQ0S46ksGppC
OkpE2m/8d8QykIedP54zLaxzTcuZ0nK2e3rKCFano5AusL2/hRMTtU9IFbU6fgWj+ecSsD6T
Rln20C0B6aDAERrefCQUgXlADH2WJiCE5bwFGryyLrtQGePswZfK2yyMH28kpxn9n5l94dZi
L1FV0Ja1+2mSgGI=
;

CREATE OR REPLACE type XDB.xdb$import_list_t                                        as varray(65535) of xdb.xdb$import_t;

CREATE OR REPLACE type XDB.xdb$import_t                                       
as object
(
    sys_xdbpd$          xdb.xdb$raw_list_t,
    namespace           varchar2(700),
    schema_location     varchar2(700),
    annotation          xdb.xdb$annotation_t,
    id                  varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$include_list_t                                        as varray(65535) of xdb.xdb$include_t;

CREATE OR REPLACE type XDB.xdb$include_t                                       
as object
(
    sys_xdbpd$          xdb.xdb$raw_list_t,
    schema_location     varchar2(700),
    annotation          xdb.xdb$annotation_t,
    id                  varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$javatype                                       
as object
(
    value       raw(2),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$keybase_list_t
                                      
as varray(1000) of xdb.xdb$keybase_t;

CREATE OR REPLACE type XDB.xdb$keybase_t
                                      
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  annotation      xdb.xdb$annotation_t,
  name            varchar2(1000),               /* name of unique/key/keyref */
  refer           xdb.xdb$qname,             /* applicable ONLY for "keyref" */
  selector        xdb.xdb$xpathspec_t,
  fields          xdb.xdb$xpathspec_list_t
);

CREATE OR REPLACE type XDB.xdb$link_t                                        AS OBJECT
(
    parent_oid    raw(16),
    child_oid     raw(16),
    name          varchar2(256),
    flags         raw(4),
    link_sn       raw(16),
    child_acloid  raw(16),
    child_ownerid raw(16),
    parent_rids   raw(2000)
);

CREATE OR REPLACE TYPE XDB."XDB_LINK_TYPE" AS OBJECT ("SYS_XDBPD$" "XDB$RAW_LIST_T","ParentName" VARCHAR2(256 CHAR),"ChildName" VARCHAR2(1024 CHAR),"Name" VARCHAR2(256 CHAR),"Flags" RAW(4),"ParentOid" RAW(16),"ChildOid" RAW(16),"LinkType" "XDB$ENUM_T")FINAL INSTANTIABLE ;

CREATE OR REPLACE type XDB.xdb$list_t                                        as
object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    item_type       xdb.xdb$qname,                               /* item of list */
    type_ref        ref sys.xmltype,          /* LATER - ref to list item type */
    simple_type     ref sys.xmltype            /* locally declared simple type */
);

CREATE OR REPLACE type XDB.xdb$model_t                                        as
object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    min_occurs      integer,
    max_occurs      varchar2(20), /* in string format incl. "unbounded" */

    elements        xdb.xdb$xmltype_ref_list_t,
    choice_kids     xdb.xdb$xmltype_ref_list_t,
    sequence_kids   xdb.xdb$xmltype_ref_list_t,
    anys            xdb.xdb$xmltype_ref_list_t,
    groups          xdb.xdb$xmltype_ref_list_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$nlocks_t                                       
 AS OBJECT
(
    PARENT_OID  RAW(16),
    CHILD_NAME  VARCHAR2(256),
    RAWTOKEN    RAW(18)
);

CREATE OR REPLACE type XDB.xdb$notation_list_t
                                      
as varray(1000) of xdb.xdb$notation_t;

CREATE OR REPLACE type XDB.xdb$notation_t
                                      
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  annotation      xdb.xdb$annotation_t,
  name            varchar2(2000),                    /* name of the notation */
  publicval       varchar2(4000),
  system          varchar2(4000)
);

CREATE OR REPLACE type XDB.xdb$numfacet_t                                       
as object              /* Number Facet */
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    value           integer,
    fixed           raw(1),
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.XDB$OID_LIST_T                                        AS varray(65535) of raw(16);

CREATE OR REPLACE type XDB.xdbpi_im                                       
   authid definer as object(
  notused    RAW(4),


  static function ODCIGetInterfaces (ilist OUT sys.ODCIObjectList) return number,

  static function ODCIIndexCreate(ia sys.odciindexinfo, parms varchar2,
      env sys.odcienv)  return number,

  static function ODCIIndexDrop(ia sys.odciindexinfo, env sys.ODCIEnv)
    return number,

  STATIC FUNCTION ODCIIndexTruncate(ia sys.odciindexinfo, env sys.ODCIEnv)
    RETURN NUMBER,

  static function ODCIIndexInsert(ia sys.odciindexinfo, rid varchar2,
        newval sys.xmltype, env sys.ODCIEnv) return number,

  static function ODCIIndexDelete(ia sys.odciindexinfo, rid varchar2,
    oldval sys.xmltype, env sys.ODCIEnv) return number,

  static function ODCIIndexUpdate(ia sys.odciindexinfo, rid varchar2,
    oldval sys.xmltype, newval sys.xmltype, env sys.ODCIEnv)
    return number,

  static function ODCIIndexStart(sctx IN OUT xdb.xdbpi_im,
      ia sys.odciindexinfo, op sys.odcipredinfo, qi sys.odciqueryinfo,
      strt number, stop number, pathstr varchar2, env sys.odcienv)
      return number,

  member function ODCIIndexFetch(nrows number, rids OUT sys.odciridlist,
     env sys.odcienv) return number,

  member function ODCIIndexClose (env sys.odcienv) return number
);

CREATE OR REPLACE type XDB.XDB$PREDECESSOR_LIST_T                                        AS varray(1000) of raw(16);

CREATE OR REPLACE type XDB.xdb_privileges                                       
as varray(1000) of VARCHAR2(200);

CREATE OR REPLACE type XDB.xdb$processChoice                                        as object
(
    value       raw(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$property_t
                                      
AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    prop_number     integer,
    /* Note that name does not need to be a QName since its namespace
    must always equal the target namespace for the schema */
    name            varchar2(256),
    typename        xdb.xdb$qname,
    mem_byte_length raw(2),       /* buffer size--NULL for variable size*/
    mem_type_code   raw(2),
    system          raw(1),
    mutable         raw(1),
    form            xdb.xdb$formChoice,          /* form choice - qualified/not */
    sqlname         varchar2(30),
    sqltype         varchar2(30),
    sqlschema       varchar2(30),
    java_type       xdb.xdb$javatype,
    default_value   varchar2(4000),
    smpl_type_decl  ref sys.xmltype,          /* Locally declared type */
    type_ref        ref sys.xmltype,          /* Globally declared type */
    /* The following two fields are relevant if the attr/element is defined
     * by a ref to a global attr/element
     */
    propref_name    xdb.xdb$qname,               /* name of global attr/element */
    propref_ref     ref sys.xmltype,           /* REF of global attr/element */
    attr_use        xdb.xdb$useChoice,             /* only applicable for attrs */
    fixed_value     varchar2(2000),
    global          raw(1),     /* TRUE for global attr/element declarations */
    annotation      xdb.xdb$annotation_t,
    sqlcolltype     varchar2(30),                   /* collection type name */
    sqlcollschema   varchar2(30),
    hidden          raw(1),
    transient       xdb.xdb$transientChoice,    /* = none/generated/manifested ? */
    id              varchar2(256),
    baseprop        raw(1) /* are there generated props based on this prop ? */
)
 alter type     xdb$property_t modify attribute
(sqlname         varchar2(128),
 sqltype         varchar2(128),
 sqlschema       varchar2(128),
 sqlcolltype     varchar2(128),
 sqlcollschema   varchar2(128)
) cascade;

CREATE OR REPLACE type XDB.xdb$qname                                       
as object
(
    prefix_code     raw(4), /* Index into schema extras */
    name            varchar2(2000)
);

CREATE OR REPLACE type XDB.xdb$raw_list_t                                       
as varray(2147483647) of raw(2000);

CREATE OR REPLACE type XDB.XDB$RCLIST_T                                        AS OBJECT
(
  OID    XDB$OID_LIST_T
);

CREATE OR REPLACE type XDB.XDB$RESOURCE_T                                        as object
(
  VERSIONID           INTEGER,
  CREATIONDATE        TIMESTAMP,
  MODIFICATIONDATE    TIMESTAMP,
  AUTHOR              VARCHAR2(128),
  DISPNAME            VARCHAR2(128),
  RESCOMMENT          VARCHAR2(128),
  LANGUAGE            VARCHAR2(128),
  CHARSET             VARCHAR2(128),
  CONTYPE             VARCHAR2(128),
  REFCOUNT            RAW(4),
  LOCKS               RAW(2000),
  ACLOID              RAW(16),
  OWNERID             RAW(16),
  CREATORID           RAW(16),
  LASTMODIFIERID      RAW(16),
  ELNUM               INTEGER,
  SCHOID              RAW(16),
  XMLREF              REF SYS.XMLTYPE,
  XMLLOB              BLOB,
  FLAGS               RAW(4),
  RESEXTRA            CLOB,
  ACTIVITYID          INTEGER,
  VCRUID              RAW(16),
  PARENTS             XDB.XDB$PREDECESSOR_LIST_T,
  SBRESEXTRA          XDB.XDB$XMLTYPE_REF_LIST_T,
  SNAPSHOT            RAW(6),
  ATTRCOPY            BLOB,
  CTSCOPY             BLOB,
  NODENUM             RAW(6),
  SIZEONDISK          INTEGER,
  RCLIST              XDB.XDB$RCLIST_T,
  CHECKEDOUTBYID      RAW(16),
  BASEVERSION         RAW(16)
)
 alter type     XDB$RESOURCE_T modify attribute SNAPSHOT RAW(8) cascade;

CREATE OR REPLACE type XDB.xdb$schema_t                                       
as object
(
    schema_url          varchar2(700), /* Maximum key length for an index*/
    target_namespace    varchar2(2000),
    version             varchar2(4000),
    num_props           integer, /* Total # of properties */
    final_default       xdb.xdb$derivationChoice,
    block_default       xdb.xdb$derivationChoice,
    element_form_dflt   xdb.xdb$formChoice,
    attribute_form_dflt xdb.xdb$formChoice,
    elements            xdb.xdb$xmltype_ref_list_t,
    simple_type         xdb.xdb$xmltype_ref_list_t,
    complex_types       xdb.xdb$xmltype_ref_list_t,
    attributes          xdb.xdb$xmltype_ref_list_t,
    imports             xdb.xdb$import_list_t,
    includes            xdb.xdb$include_list_t,
    flags               raw(4),
    sys_xdbpd$          xdb.xdb$raw_list_t,
    annotations         xdb.xdb$annotation_list_t,
    map_to_nchar        raw(1),   /* map strings to NCHAR/NVARCHAR2/NCLOB ? */
    map_to_lob          raw(1),           /* map unbounded strings to LOB ? */
    groups              xdb.xdb$xmltype_ref_list_t,
    attrgroups          xdb.xdb$xmltype_ref_list_t,
    id                  varchar2(256),
    varray_as_tab       raw(1),     /* should varrays be stored as tables ? */
    schema_owner        varchar2(30),
    notations           xdb.xdb$notation_list_t,
    lang                varchar2(4000)
)
 alter type     xdb$schema_t modify attribute
(schema_owner varchar2(128)) cascade;

CREATE OR REPLACE type XDB.xdb$simplecontent_t                                       
as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,

    /* only one of the foll. can be non-null */
    restriction     xdb.xdb$simplecont_res_t,
    extension       xdb.xdb$simplecont_ext_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$simplecont_ext_t                                        as object
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base            xdb.xdb$qname,
    id              varchar2(256),

    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,
    annotation      xdb.xdb$annotation_t
);

CREATE OR REPLACE type XDB.xdb$simplecont_res_t                                        AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base            xdb.xdb$qname,
    id              varchar2(256),
    lcl_smpl_decl   ref sys.xmltype,        /* locally declared simple type */
    attributes      xdb.xdb$xmltype_ref_list_t,
    any_attrs       xdb.xdb$xmltype_ref_list_t,
    attr_groups     xdb.xdb$xmltype_ref_list_t,
    annotation      xdb.xdb$annotation_t,

    /* Facets */
    fractiondigits  xdb.xdb$numfacet_t,
    totaldigits     xdb.xdb$numfacet_t,
    minlength       xdb.xdb$numfacet_t,
    maxlength       xdb.xdb$numfacet_t,
    whitespace      xdb.xdb$whitespace_t,
    period          xdb.xdb$timefacet_t,
    duration        xdb.xdb$timefacet_t,
    min_inclusive   xdb.xdb$facet_t,
    max_inclusive   xdb.xdb$facet_t,
    pattern         xdb.xdb$facet_list_t,
    enumeration     xdb.xdb$facet_list_t,
    min_exclusive   xdb.xdb$facet_t,
    max_exclusive   xdb.xdb$facet_t,
    length          xdb.xdb$numfacet_t
);

CREATE OR REPLACE type XDB.xdb$simple_derivation_t                                        AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    base_type       ref sys.xmltype,
    base            xdb.xdb$qname,
    lcl_smpl_decl   ref sys.xmltype,        /* locally declared simple type */

    /* Facets */
    fractiondigits  xdb.xdb$numfacet_t,
    totaldigits     xdb.xdb$numfacet_t,
    minlength       xdb.xdb$numfacet_t,
    maxlength       xdb.xdb$numfacet_t,
    length          xdb.xdb$numfacet_t,
    whitespace      xdb.xdb$whitespace_t,
    period          xdb.xdb$timefacet_t,
    duration        xdb.xdb$timefacet_t,
    min_inclusive   xdb.xdb$facet_t,
    max_inclusive   xdb.xdb$facet_t,
    min_exclusive   xdb.xdb$facet_t,
    max_exclusive   xdb.xdb$facet_t,
    pattern         xdb.xdb$facet_list_t,
    enumeration     xdb.xdb$facet_list_t,
    annotation      xdb.xdb$annotation_t,
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$simple_t
                                      
AS OBJECT
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    parent_schema   ref sys.xmltype,
    /* Note that name does not need to be a QName since its namespace
    must always equal the target namespace for the schema */
    name            varchar2(256),
    abstract        raw(1),   /* boolean, obsoleted */
    /* Only one of the foll. fields is non-null */
    restriction     xdb.xdb$simple_derivation_t,
    list_type       xdb.xdb$list_t,
    union_type      xdb.xdb$union_t,

    annotation      xdb.xdb$annotation_t,
    id              varchar2(256),
    final_info      xdb.xdb$derivationChoice,
    typeid          integer,
    sqltype         varchar2(30)
)
 alter type     xdb$simple_t modify attribute sqltype varchar2(128) cascade;

CREATE OR REPLACE type XDB.xdb$string_list_t                                       
as VARRAY(2147483647) of varchar2(4000);

CREATE OR REPLACE type XDB.xdb$timefacet_t                                        as object               /* Time Facet */
(
    sys_xdbpd$      xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    value           date,
    fixed           raw(1),
    id              varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$transientChoice                                        as object
(
    value       raw(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$union_t                                        as
object
(
    sys_xdbpd$         xdb.xdb$raw_list_t,
    annotation      xdb.xdb$annotation_t,
    member_types       varchar2(4000),                 /* members of union */
    simple_types       xdb.xdb$xmltype_ref_list_t,       /* local simple types */

    /* LATER - refs to all constituents of the union type */
    type_refs          xdb.xdb$xmltype_ref_list_t
);

CREATE OR REPLACE type XDB.xdb$useChoice                                       
as object
(
    value       raw(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$whitespaceChoice                                        as object
(
    value       raw(1),

member function lookupValue RETURN VARCHAR2,
       pragma restrict_references (lookupValue, wnds, wnps, rnps, rnds),
member procedure setValue(val IN VARCHAR2),
       pragma restrict_references (setValue, wnds, wnps, rnps, rnds)
);

CREATE OR REPLACE type XDB.xdb$whitespace_t                                        as object        /* Whitespace facet */
(
    sys_xdbpd$  xdb.xdb$raw_list_t,
    annotation  xdb.xdb$annotation_t,
    value       xdb.xdb$whitespaceChoice,
    fixed       raw(1),
    id          varchar2(256)
);

CREATE OR REPLACE type XDB.xdb$xmltype_ref_list_t
                                       as varray(2147483647) of ref sys.xmltype;

CREATE OR REPLACE type XDB.xdb$xpathspec_list_t
                                      
as varray(1000) of xdb.xdb$xpathspec_t;

CREATE OR REPLACE type XDB.xdb$xpathspec_t
                                      
as object
(
  sys_xdbpd$      xdb.xdb$raw_list_t,
  annotation      xdb.xdb$annotation_t,
  xpath           varchar2(4000)
);

CREATE OR REPLACE type XDB.XMLIdxStatsMethods
                                        
  authid current_user as object
(
  -- user-defined function cost and selectivity functions
  cost number,

  -- DCLs
  static function ODCIGetInterfaces (ilist OUT sys.ODCIObjectList)
         return NUMBER,

  --- STATISTICs ---
  static function ODCIStatsTableFunction(funcInfo IN  sys.ODCIFuncInfo,
                                         tfStats  OUT sys.ODCITabFuncStats,
                                         args     IN  sys.ODCIArgDescList)
         return NUMBER
  is language C name "QMIX_TABFUN_STATS" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       funcInfo, funcInfo INDICATOR struct,
       tfStats,  tfStats  INDICATOR struct,
       args,     args     INDICATOR,
       return OCINumber),

  static function ODCIStatsCollect(colinfo   sys.ODCIColInfo,
                                   options   sys.ODCIStatsOptions,
                                   stats OUT RAW,
                                   idxenv    sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_COL_STATS" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       colinfo, colinfo INDICATOR struct,
       options, options INDICATOR struct,
       stats,   stats   INDICATOR, stats LENGTH,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static function ODCIStatsCollect(idxinfo   sys.ODCIIndexInfo,
                                   options   sys.ODCIStatsOptions,
                                   stats OUT RAW,
                                   idxenv    sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_IDX_STATS" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       options, options INDICATOR struct,
       stats,   stats   INDICATOR, stats LENGTH,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static function ODCIStatsDelete(colinfo   sys.ODCIColInfo,
                                  statistics OUT RAW,
                                  idxenv    sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_DEL_COLSTATS" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       colinfo,    colinfo    INDICATOR struct,
       statistics, statistics INDICATOR, statistics LENGTH,
       idxenv,     idxenv     INDICATOR struct,
       return OCINumber),

  static function ODCIStatsDelete(idxinfo   sys.ODCIIndexInfo,
                                  statistics OUT RAW,
                                  idxenv    sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_DEL_IDXSTATS" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       idxinfo,    idxinfo    INDICATOR struct,
       statistics, statistics INDICATOR, statistics LENGTH,
       idxenv,     idxenv     INDICATOR struct,
       return OCINumber),

  static function ODCIStatsSelectivity(predinfo sys.ODCIPredInfo,
                                       sel  OUT number,
                                       args     sys.ODCIArgDescList,
                                       strt     number,
                                       stop     number,
                                       expr     VARCHAR2,
                                       datai    VARCHAR2,
                                       idxenv   sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_SELECTIVITY" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       predinfo,predinfo INDICATOR struct,
       sel,     sel      INDICATOR,
       args,    args     INDICATOR,
       strt,    strt     INDICATOR,
       stop,    stop     INDICATOR,
       expr,    expr     INDICATOR,
       datai,   datai    INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       return OCINumber),

  static function ODCIStatsFunctionCost(funcinfo sys.ODCIFuncInfo,
                                        cost OUT sys.ODCICost,
                                        args     sys.ODCIArgDescList,
                                        expr     VARCHAR2,
                                        datai    VARCHAR2,
                                        idxenv   sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_FUN_COST" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       funcinfo,funcinfo INDICATOR struct,
       cost,    cost     INDICATOR struct,
       args,    args     INDICATOR,
       expr,    expr     INDICATOR,
       datai,   datai    INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       return OCINumber),

  static function ODCIStatsIndexCost(idxinfo  sys.ODCIIndexInfo,
                                     sel      number,
                                     cost OUT sys.ODCICost,
                                     qi       sys.ODCIQueryInfo,
                                     pred     sys.ODCIPredInfo,
                                     args     sys.ODCIArgDescList,
                                     strt     number,
                                     stop     number,
                                     datai    varchar2,
                                     idxenv   sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_IDX_COST" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       sel,     sel     INDICATOR,
       cost,    cost    INDICATOR struct,
       qi,      qi      INDICATOR struct,
       pred,    pred    INDICATOR struct,
       args,    args    INDICATOR,
       strt,    strt    INDICATOR,
       stop,    stop    INDICATOR,
       datai,   datai   INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static function ODCIStatsExchangePartition(idxinfo sys.ODCIIndexInfo,
                                             tabinfo sys.ODCIIndexInfo,
                                             idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_EXCHANGE_STATS" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       tabinfo, tabinfo INDICATOR struct,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  static function ODCIStatsUpdPartStatistics(idxinfo sys.ODCIIndexInfo,
                                             palist  sys.ODCIPartInfoList,
                                             idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_UPD_PARTSTATS" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       palist,  palist  INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber)
);

CREATE OR REPLACE type XDB.XMLIndexLoad_Imp_t
  authid current_user as object
(
  key RAW(8),

  static function ODCITableStart(sctx IN OUT XDB.XMLIndexLoad_Imp_t)
         return PLS_INTEGER
    is language C name "QMIX_INSSTART" library XDB.XMLINDEX_LIB
    with context
    parameters (
      context,
      sctx,        sctx        INDICATOR STRUCT,
      return INT
    ),

  static function ODCITableStart(sctx IN OUT XDB.XMLIndexLoad_Imp_t,
                                 load_cursor SYS_REFCURSOR,
                                 flags IN Number)
         return PLS_INTEGER
    is language C name "QMIX_LOADSTART" library XDB.XMLINDEX_LIB
    with context
    parameters (
      context,
      sctx,        sctx        INDICATOR STRUCT,
      load_cursor, load_cursor INDICATOR,
      flags,
      return INT
    ),

  member function ODCITableFetch(self IN OUT XDB.XMLIndexLoad_Imp_t,
                                 nrows    IN Number,
                                 xmlrws  OUT XDB.XMLIndexTab_t)
         return PLS_INTEGER
    as language C name "QMIX_LOADFETCH" library XDB.XMLINDEX_LIB
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT,
      nrows,
      xmlrws OCIColl, xmlrws INDICATOR sb2, xmlrws DURATION OCIDuration,
      return INT
    ),

  member function ODCITableClose(self IN XDB.XMLIndexLoad_Imp_t)
         return PLS_INTEGER
    as language C name "QMIX_LOADCLOSE" library XDB.XMLINDEX_LIB
    with context
    parameters (
      context,
      self, self INDICATOR STRUCT,
      return INT
    )
);

CREATE OR REPLACE type XDB.XMLIndexLoad_t as object
(
  RID    VARCHAR2(18),
  PID    RAW(8),
  OK     RAW(1000),
  LOC    RAW(2000),
  VALUE  VARCHAR2(4000)
);

CREATE OR REPLACE type XDB.XMLIndexMethods FORCE
                                        
  authid current_user as object
(
  -- cursor set by IndexStart and used in IndexFetch
  scanctx RAW(8),

  -- DCLs
  static function ODCIGetInterfaces (ilist OUT sys.ODCIObjectList)
         return NUMBER,

  -- DDLs
  static function ODCIIndexCreate   (idxinfo  sys.ODCIIndexInfo,
                                     idxparms VARCHAR2,
                                     idxenv   sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_CREATE" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo  INDICATOR struct,
       idxparms,idxparms INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexDrop     (idxinfo sys.ODCIIndexInfo,
                                     idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_DROP" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexAlter    (idxinfo          sys.ODCIIndexInfo,
                                     idxparms  IN OUT VARCHAR2,
                                     opt              NUMBER,
                                     idxenv           sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_ALTER" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo  INDICATOR struct,
       idxparms,idxparms INDICATOR,
       opt,     opt      INDICATOR,
       idxenv,  idxenv   INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexTruncate (idxinfo sys.ODCIIndexInfo,
                                     idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_TRUNC" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  --- DMLs ---
  static function ODCIIndexInsert (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR2,
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_INSERT" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexInsert (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR2,
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv,
                                   oid     VARCHAR2)
         return NUMBER
  is language C name "QMIX_INSERT2" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       oid,     oid     INDICATOR,
       RETURN OCINumber),

  static function ODCIIndexDelete (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR2,
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_DELETE" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexDelete (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR2,
                                   doc     sys.xmltype,
                                   idxenv  sys.ODCIEnv,
                                   oid     VARCHAR2)
         return NUMBER
  is language C name "QMIX_DELETE2" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       doc,     doc     INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       oid,     oid     INDICATOR,
       RETURN OCINumber),

  static function ODCIIndexUpdate (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR2,
                                   olddoc  sys.xmltype,
                                   newdoc  sys.xmltype,
                                   idxenv  sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_UPDATE" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       olddoc,  olddoc  INDICATOR,
       newdoc,  newdoc  INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexUpdate (idxinfo sys.ODCIIndexInfo,
                                   rid     VARCHAR2,
                                   olddoc  sys.xmltype,
                                   newdoc  sys.xmltype,
                                   idxenv  sys.ODCIEnv,
                                   oid     VARCHAR2)
         return NUMBER
  is language C name "QMIX_UPDATE2" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo, idxinfo INDICATOR struct,
       rid,     rid     INDICATOR,
       olddoc,  olddoc  INDICATOR,
       newdoc,  newdoc  INDICATOR,
       idxenv,  idxenv  INDICATOR struct,
       oid,     oid     INDICATOR,
       RETURN OCINumber),

  --- Query ---
  static function ODCIIndexStart (ictx    IN OUT XMLIndexMethods,
                                  idxinfo        sys.ODCIIndexInfo,
                                  opi            sys.ODCIPredInfo,
                                  oqi            sys.ODCIQueryInfo,
                                  strt           NUMBER,
                                  stop           NUMBER,
                                  pathstr        varchar2,
                                  idxenv         sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_START" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       ictx,    ictx    INDICATOR struct,
       idxinfo, idxinfo INDICATOR struct,
       opi,     opi     INDICATOR struct,
       oqi,     oqi     INDICATOR struct,
       strt,    strt    INDICATOR,
       stop,    stop    INDICATOR,
       pathstr, pathstr LENGTH,
       idxenv,  idxenv  INDICATOR struct,
       return OCINumber),

  member function ODCIIndexFetch (nrows      NUMBER,
                                  rids   OUT sys.ODCIRidList,
                                  idxenv     sys.ODCIEnv)
         return  NUMBER
  is language C name "QMIX_FETCH" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       self,     self INDICATOR struct,
       nrows,   nrows INDICATOR,
       rids,     rids INDICATOR,
       idxenv, idxenv INDICATOR struct,
       return OCINumber),

  member function ODCIIndexClose (idxenv sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_CLOSE" LIBRARY XDB.XMLINDEX_LIB
     with context parameters (
       context,
       self,     self INDICATOR struct,
       idxenv, idxenv INDICATOR struct,
       return OCINumber),

  static function ODCIIndexExchangePartition (idxPinfo sys.ODCIIndexInfo,
                                              idxTinfo sys.ODCIIndexInfo,
                                              idxenv   sys.ODCIEnv)
         return NUMBER
  is language C name "QMIX_EXCHANGE" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxPinfo, idxPinfo INDICATOR struct,
       idxTinfo, idxTinfo INDICATOR struct,
       idxenv,   idxenv   INDICATOR struct,
       RETURN OCINumber),

  static function ODCIIndexUpdPartMetadata(ixdxinfo sys.ODCIIndexInfo,
                                           palist   sys.ODCIPartInfoList,
                                           idxenv   sys.ODCIEnv)
         return NUMBER,

--- MOVE / TRANSPORTABLE TBS / IM/EXPORT ---
  static function ODCIIndexGetMetadata(idxinfo  IN  sys.ODCIIndexInfo,
                                       expver   IN  VARCHAR2,
                                       newblock OUT number,
                                       idxenv   IN  sys.ODCIEnv)
         return VARCHAR2,

  -- path table and secondary indexes on it are already exported in schema-mode
  -- this routine should only expose them for Transportable Tablespaces,
  -- via DataPump

  static FUNCTION ODCIIndexUtilGetTableNames(ia IN sys.ODCIIndexInfo,
                                      read_only IN PLS_INTEGER,
                                      version IN varchar2,
                                      context OUT PLS_INTEGER)
  RETURN BOOLEAN,

/*
  static function ODCIIndexUtilGetTableNames(idxinfo   IN sys.ODCIIndexInfo,
                                             read_only IN PLS_INTEGER,
                                             version   IN varchar2,
                                             ctx       OUT PLS_INTEGER)
         return BOOLEAN
  is language C name "QMIX_GETTABNAMES" library XDB.XMLINDEX_LIB
     with context
     parameters (
       context,
       idxinfo,  idxinfo   INDICATOR struct,
       read_only,read_only INDICATOR,
       version,  version   INDICATOR,
       ctx,      ctx       INDICATOR,
       RETURN INDICATOR sb4),
*/
  static PROCEDURE ODCIIndexUtilCleanup (context  IN PLS_INTEGER)
);

CREATE OR REPLACE type XDB.XMLIndexTab_t as TABLE of XDB.XMLIndexLoad_t;

CREATE OR REPLACE TYPE XDB.XMLTYPE_REF_TABLE_T IS TABLE of REF XMLTYPE;

CREATE TABLE "XDB"."APP_ROLE_MEMBERSHIP" 
   (	"ROLE_GUID" RAW(16), 
	"MEMBER_GUID" RAW(16)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

COMMENT ON TABLE XDB.APP_ROLE_MEMBERSHIP IS 'Application role membership';
COMMENT ON COLUMN XDB.APP_ROLE_MEMBERSHIP.ROLE_GUID IS 'The GUID for the role/workgroup';
COMMENT ON COLUMN XDB.APP_ROLE_MEMBERSHIP.MEMBER_GUID IS 'The GUID of the role member';

CREATE TABLE "XDB"."APP_USERS_AND_ROLES" 
   (	"GUID" RAW(16), 
	"NAME" VARCHAR2(1024), 
	"ISROLE" VARCHAR2(3), 
	 UNIQUE ("NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."SYS_C004848" ON "XDB"."APP_USERS_AND_ROLES" ("NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

COMMENT ON TABLE XDB.APP_USERS_AND_ROLES IS 'Application users and roles/workspaces';
COMMENT ON COLUMN XDB.APP_USERS_AND_ROLES.GUID IS 'The GUID for user or role/workgroup';
COMMENT ON COLUMN XDB.APP_USERS_AND_ROLES.NAME IS 'The name of user or role/workgroup';
COMMENT ON COLUMN XDB.APP_USERS_AND_ROLES.ISROLE IS 'Whether user or role/workgroup';

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."DOCUMENT_LINKS" ("SOURCE_ID", "TARGET_ID", "TARGET_PATH", "LINK_TYPE", "LINK_FORM", "SOURCE_TYPE") AS 
  SELECT
dl.source_id,
dl.target_id,
dl.target_path,
decode(bitand(sys_op_rawtonum(dl.flags),1),1, 'Weak',
       decode(bitand(sys_op_rawtonum(dl.flags),2),2,'Symbolic','Hard')),
decode(bitand(sys_op_rawtonum(dl.flags),4),4, 'XInclude', 'XLink'),
decode(bitand(sys_op_rawtonum(dl.flags),8),8, 'Resource Metadata',
       'Resource Content')
from xdb.xdb$d_link dl, xdb.xdb$resource r
where dl.source_id = r.object_id
and sys_checkacl(r.xmldata.acloid, r.xmldata.ownerid,
xmltype('<privilege
      xmlns="http://xmlns.oracle.com/xdb/acl.xsd"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://xmlns.oracle.com/xdb/acl.xsd
                          http://xmlns.oracle.com/xdb/acl.xsd
                          DAV: http://xmlns.oracle.com/xdb/dav.xsd">
      <read-properties/>
      <read-contents/>
 </privilege>')) = 1;
;

CREATE TABLE "XDB"."JSON$COLLECTION_METADATA" 
   (	"URI_NAME" NVARCHAR2(255) NOT NULL ENABLE, 
	"OWNER" VARCHAR2(128) DEFAULT SYS_CONTEXT('USERENV','CURRENT_USER') NOT NULL ENABLE, 
	"OBJECT_TYPE" VARCHAR2(10) DEFAULT 'TABLE' NOT NULL ENABLE, 
	"OBJECT_SCHEMA" VARCHAR2(128) DEFAULT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') NOT NULL ENABLE, 
	"OBJECT_NAME" VARCHAR2(128) NOT NULL ENABLE, 
	"CREATED_ON" TIMESTAMP (6) DEFAULT sys_extract_utc(SYSTIMESTAMP) NOT NULL ENABLE, 
	"CREATE_MODE" VARCHAR2(10) DEFAULT 'MAP' NOT NULL ENABLE, 
	"JSON_DESCRIPTOR" VARCHAR2(4000) NOT NULL ENABLE, 
	 CONSTRAINT "JSON$COLLECTION_METADATA_C1" CHECK (OBJECT_TYPE in ('TABLE','VIEW','PACKAGE')) ENABLE, 
	 CONSTRAINT "JSON$COLLECTION_METADATA_C2" CHECK (CREATE_MODE in ('DDL','MAP')) ENABLE, 
	 CONSTRAINT "JSON$COLLECTION_METADATA_PK" PRIMARY KEY ("OWNER", "URI_NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE, 
	 CONSTRAINT "JSON$COLLECTION_METADATA_CJ" CHECK (JSON_DESCRIPTOR is json) ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."JSON$COLLECTION_METADATA_PK" ON "XDB"."JSON$COLLECTION_METADATA" ("OWNER", "URI_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."JSON$COLLECTION_METADATA_V" ("URI_NAME", "OWNER", "SCHEMA_NAME", "TABLE_NAME", "VIEW_NAME", "PACKAGE_NAME", "TABLESPACE_NAME", "STORAGE_INIT_SIZE", "STORAGE_INCREASE_PCT", "KEY_COLUMN_NAME", "KEY_COLUMN_TYPE", "KEY_COLUMN_LEN", "KEY_ASSIGNMENT_METHOD", "KEY_SEQUENCE_NAME", "KEY_PATH", "PARTITION_COLUMN_NAME", "PARTITION_COLUMN_TYPE", "PARTITION_COLUMN_LEN", "PARTITION_PATH", "CONTENT_COLUMN_NAME", "CONTENT_COLUMN_TYPE", "CONTENT_COLUMN_LEN", "CONTENT_COLUMN_JSON_FORMAT", "CONTENT_VALIDATION", "CONTENT_LOB_COMPRESS", "CONTENT_LOB_CACHE", "CONTENT_LOB_ENCRYPT", "CONTENT_LOB_TS", "LAST_MODIFIED_COLUMN_NAME", "LAST_MODIFIED_INDEX", "VERSION_COLUMN_NAME", "VERSIONING_METHOD", "MEDIA_TYPE_COLUMN_NAME", "CREATION_TIME_COLUMN_NAME", "READ_ONLY") AS 
  select MD.URI_NAME                   URI_NAME,
       MD.OWNER                      OWNER,
       JT.SCHEMA_NAME                SCHEMA_NAME,
       JT.TABLE_NAME                 TABLE_NAME,
       JT.VIEW_NAME                  VIEW_NAME,
       JT.PACKAGE_NAME               PACKAGE_NAME,
       JT.TABLESPACE_NAME            TABLESPACE_NAME,
       JT.STORAGE_INIT_SIZE          STORAGE_INIT_SIZE,
       JT.STORAGE_INCREASE_PCT       STORAGE_INCREASE_PCT,
       JT.KEY_COLUMN_NAME            KEY_COLUMN_NAME,
       JT.KEY_COLUMN_TYPE            KEY_COLUMN_TYPE,
       JT.KEY_COLUMN_LEN             KEY_COLUMN_LEN,
       JT.KEY_ASSIGNMENT_METHOD      KEY_ASSIGNMENT_METHOD,
       JT.KEY_SEQUENCE_NAME          KEY_SEQUENCE_NAME,
       JT.KEY_PATH                   KEY_PATH,
       JT.PARTITION_COLUMN_NAME      PARTITION_COLUMN_NAME,
       JT.PARTITION_COLUMN_TYPE      PARTITION_COLUMN_TYPE,
       JT.PARTITION_COLUMN_LEN       PARTITION_COLUMN_LEN,
       JT.PARTITION_PATH             PARTITION_PATH,
       JT.CONTENT_COLUMN_NAME        CONTENT_COLUMN_NAME,
       JT.CONTENT_COLUMN_TYPE        CONTENT_COLUMN_TYPE,
       JT.CONTENT_COLUMN_LEN         CONTENT_COLUMN_LEN,
       JT.CONTENT_COLUMN_JSON_FORMAT CONTENT_COLUMN_JSON_FORMAT,
       JT.CONTENT_VALIDATION         CONTENT_VALIDATION,
       JT.CONTENT_LOB_COMPRESS       CONTENT_LOB_COMPRESS,
       JT.CONTENT_LOB_CACHE          CONTENT_LOB_CACHE,
       JT.CONTENT_LOB_ENCRYPT        CONTENT_LOB_ENCRYPT,
       JT.CONTENT_LOB_TS             CONTENT_LOB_TS,
       JT.LAST_MODIFIED_COLUMN_NAME  LAST_MODIFIED_COLUMN_NAME,
       JT.LAST_MODIFIED_INDEX        LAST_MODIFIED_INDEX,
       JT.VERSION_COLUMN_NAME        VERSION_COLUMN_NAME,
       JT.VERSIONING_METHOD          VERSIONING_METHOD,
       JT.MEDIA_TYPE_COLUMN_NAME     MEDIA_TYPE_COLUMN_NAME,
       JT.CREATION_TIME_COLUMN_NAME  CREATION_TIME_COLUMN_NAME,
       JT.READ_ONLY                  READ_ONLY
  from XDB.JSON$COLLECTION_METADATA MD,
       Json_Table(MD.JSON_DESCRIPTOR, '$' null on error columns
 "SCHEMA_NAME"                varchar2(128) path '$.schemaName',
 "TABLE_NAME"                 varchar2(128) path '$.tableName',
 "VIEW_NAME"                  varchar2(128) path '$.viewName',
 "PACKAGE_NAME"               varchar2(128) path '$.packageName',
 "TABLESPACE_NAME"            varchar2(128) path '$.tablespace',
 "STORAGE_INIT_SIZE"          number        path '$.storage.size',
 "STORAGE_INCREASE_PCT"       number        path '$.storage.increase',
 "KEY_COLUMN_NAME"            varchar2(128) path '$.keyColumn.name',
 "KEY_COLUMN_TYPE"            varchar2(10)  path '$.keyColumn.sqlType',
 "KEY_COLUMN_LEN"             number        path '$.keyColumn.maxLength',
 "KEY_ASSIGNMENT_METHOD"      varchar2(10)  path '$.keyColumn.assignmentMethod',
 "KEY_SEQUENCE_NAME"          varchar2(128) path '$.keyColumn.sequenceName',
 "KEY_PATH"                   varchar2(255) path '$.keyColumn.path',
 "PARTITION_COLUMN_NAME"      varchar2(128) path '$.partitionColumn.name',
 "PARTITION_COLUMN_TYPE"      varchar2(10)  path '$.partitionColumn.sqlType',
 "PARTITION_COLUMN_LEN"       number        path '$.partitionColumn.maxLength',
 "PARTITION_PATH"             varchar2(255) path '$.partitionColumn.path',
 "CONTENT_COLUMN_NAME"        varchar2(128) path '$.contentColumn.name',
 "CONTENT_COLUMN_TYPE"        varchar2(10)  path '$.contentColumn.sqlType',
 "CONTENT_COLUMN_LEN"         number        path '$.contentColumn.maxLength',
 "CONTENT_COLUMN_JSON_FORMAT" varchar2(10)  path '$.contentColumn.jsonFormat',
 "CONTENT_VALIDATION"         varchar2(10)  path '$.contentColumn.validation',
 "CONTENT_LOB_COMPRESS"       varchar2(10)  path '$.contentColumn.compress',
 "CONTENT_LOB_CACHE"          varchar2(10)  path '$.contentColumn.cache',
 "CONTENT_LOB_ENCRYPT"        varchar2(10)  path '$.contentColumn.encrypt',
 "CONTENT_LOB_TS"             varchar2(128) path '$.contentColumn.tablespace',
 "LAST_MODIFIED_COLUMN_NAME"  varchar2(128) path '$.lastModifiedColumn.name',
 "LAST_MODIFIED_INDEX"        varchar2(128) path '$.lastModifiedColumn.index',
 "VERSION_COLUMN_NAME"        varchar2(128) path '$.versionColumn.name',
 "VERSIONING_METHOD"          varchar2(10)  path '$.versionColumn.method',
 "MEDIA_TYPE_COLUMN_NAME"     varchar2(128) path '$.mediaTypeColumn.name',
 "CREATION_TIME_COLUMN_NAME"  varchar2(128) path '$.creationTimeColumn.name',
 "READ_ONLY"                  varchar2(10)  path '$.readOnly'
                 ) JT;
;

CREATE TABLE "XDB"."JSON$USERS" 
   (	"ID" RAW(16) DEFAULT SYS_GUID() NOT NULL ENABLE, 
	"OWNER" VARCHAR2(128) DEFAULT USER NOT NULL ENABLE, 
	"USER_NAME" NVARCHAR2(255) NOT NULL ENABLE, 
	"CREATED_ON" TIMESTAMP (6) DEFAULT sys_extract_utc(SYSTIMESTAMP) NOT NULL ENABLE, 
	"DESCRIPTION" VARCHAR2(4000), 
	 CONSTRAINT "JSON$USERS_PK" PRIMARY KEY ("ID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."JSON$USERS_PK" ON "XDB"."JSON$USERS" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."JSON$USERS_U1" ON "XDB"."JSON$USERS" ("OWNER", "USER_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."JSON$USER_COLLECTION_METADATA" ("URI_NAME", "OBJECT_TYPE", "OBJECT_SCHEMA", "OBJECT_NAME", "CREATED_ON", "CREATE_MODE", "JSON_DESCRIPTOR") AS 
  select URI_NAME,
       OBJECT_TYPE, OBJECT_SCHEMA, OBJECT_NAME,
       CREATED_ON, CREATE_MODE, JSON_DESCRIPTOR
  from XDB.JSON$COLLECTION_METADATA
 where OWNER = SYS_CONTEXT('USERENV','CURRENT_USER');
;

CREATE TABLE "XDB"."JSON$USER_CREDENTIALS" 
   (	"ID" RAW(16) NOT NULL ENABLE, 
	"CREDENTIAL_TYPE" VARCHAR2(255) NOT NULL ENABLE, 
	"CREDENTIAL" VARCHAR2(4000) NOT NULL ENABLE, 
	 CONSTRAINT "JSON$USER_CREDENTIALS_PK" PRIMARY KEY ("ID", "CREDENTIAL_TYPE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

ALTER TABLE "XDB"."JSON$USER_CREDENTIALS" ADD CONSTRAINT "JSON$USER_CREDENTIALS_FK" FOREIGN KEY ("ID")
	  REFERENCES "XDB"."JSON$USERS" ("ID") ON DELETE CASCADE ENABLE;

CREATE UNIQUE INDEX "XDB"."JSON$USER_CREDENTIALS_PK" ON "XDB"."JSON$USER_CREDENTIALS" ("ID", "CREDENTIAL_TYPE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."JSON$USER_ROLES" 
   (	"ID" RAW(16) NOT NULL ENABLE, 
	"OWNER" VARCHAR2(128) DEFAULT USER NOT NULL ENABLE, 
	"ROLE_NAME" VARCHAR2(255) NOT NULL ENABLE, 
	 CONSTRAINT "JSON$USER_ROLES_PK" PRIMARY KEY ("ID", "OWNER", "ROLE_NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

ALTER TABLE "XDB"."JSON$USER_ROLES" ADD CONSTRAINT "JSON$USER_ROLES_FK" FOREIGN KEY ("ID")
	  REFERENCES "XDB"."JSON$USERS" ("ID") ON DELETE CASCADE ENABLE;

CREATE INDEX "XDB"."JSON$USER_ROLES_N1" ON "XDB"."JSON$USER_ROLES" ("OWNER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."JSON$USER_ROLES_PK" ON "XDB"."JSON$USER_ROLES" ("ID", "OWNER", "ROLE_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."PATH_VIEW" ("PATH", "RES", "LINK", "RESID") AS 
  select /*+ ORDERED */ t2.path path, t.res res,
      xmltype.createxml(xdb.xdb_link_type(NULL, r2.xmldata.dispname, t.name,
                        h.name, h.flags, h.parent_oid, h.child_oid,
                        decode(bitand(sys_op_rawtonum(h.flags), 1024), 1024,
                              xdb.xdb$enum_t(hextoraw('01')),
                              decode(bitand(sys_op_rawtonum(h.flags), 512), 512,
                                xdb.xdb$enum_t(hextoraw('02')),
                                xdb.xdb$enum_t(hextoraw('00'))))),
                   'http://xmlns.oracle.com/xdb/XDBStandard.xsd', 'LINK') link,
      t.resid
  from  ( select xdb.all_path(9999) paths, value(p) res, p.sys_nc_oid$ resid,
          decode(bitand(sys_op_rawtonum(p.xmldata.flags), 8388608), 8388608,
                 utl_raw.cast_to_varchar2(dbms_lob.substr(p.xmldata.xmllob, 4000)),
                 p.xmldata.dispname) name
          from xdb.xdb$resource p
          where xdb.under_path(value(p), '/', 9999)=1 ) t,
        TABLE( cast (t.paths as xdb.path_array) ) t2,
        xdb.xdb$h_link h, xdb.xdb$resource r2
   where t2.parent_oid = h.parent_oid and t2.childname = h.name and
         t2.parent_oid = r2.sys_nc_oid$;
;

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."RESOURCE_VIEW" ("RES", "ANY_PATH", "RESID") AS 
  select value(p) res, abspath(8888) any_path, sys_nc_oid$ resid
  from xdb.xdb$resource p
  where under_path(value(p), '/', 8888) = 1 ;
;

CREATE TABLE "XDB"."X$NM4UMSH11LOFA71E0KOM0000LJFI" 
   (	"NMSPCURI" VARCHAR2(2000), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."X$NI4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$NM4UMSH11LOFA71E0KOM0000LJFI" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."X$NN4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$NM4UMSH11LOFA71E0KOM0000LJFI" ("NMSPCURI") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."X$PT4UMSH11LOFA71E0KOM0000LJFI" 
   (	"PATH" RAW(2000), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."X$PI4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$PT4UMSH11LOFA71E0KOM0000LJFI" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."X$PP4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$PT4UMSH11LOFA71E0KOM0000LJFI" ("PATH") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."X$PR4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$PT4UMSH11LOFA71E0KOM0000LJFI" (SYS_PATH_REVERSE("PATH")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."X$QN4UMSH11LOFA71E0KOM0000LJFI" 
   (	"NMSPCID" RAW(8), 
	"LOCALNAME" VARCHAR2(2000), 
	"FLAGS" RAW(4), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."X$QI4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$QN4UMSH11LOFA71E0KOM0000LJFI" ("ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."X$QQ4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$QN4UMSH11LOFA71E0KOM0000LJFI" ("NMSPCID", "LOCALNAME", "FLAGS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."X$QS4UMSH11LOFA71E0KOM0000LJFI" ON "XDB"."X$QN4UMSH11LOFA71E0KOM0000LJFI" ("NMSPCID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$ACL" OF XMLTYPE 
 XMLTYPE STORE AS SECUREFILE BINARY XML (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
   XMLSCHEMA "http://xmlns.oracle.com/xdb/acl.xsd" ELEMENT "acl" DISALLOW NONSCHEMA 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE OR REPLACE NONEDITIONABLE TRIGGER "XDB"."XDB$ACL$xd" after delete or update on "XDB"."XDB$ACL" for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$ACL', :old.sys_nc_oid$, '9DB6E210D81751C2E0531600000ACDF2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$ACL', :old.sys_nc_oid$, '9DB6E210D81751C2E0531600000ACDF2', user ); END IF; END;
/
ALTER TRIGGER "XDB"."XDB$ACL$xd" ENABLE;

CREATE UNIQUE INDEX "XDB"."SYS_C004849" ON "XDB"."XDB$ACL" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019338C00003$$" ON "XDB"."XDB$ACL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$ALL_MODEL" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "all" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ELEMENTS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."CHOICE_KIDS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SEQUENCE_KIDS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANYS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004833" ON "XDB"."XDB$ALL_MODEL" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00004$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00005$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00007$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00011$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00012$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00013$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00014$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00015$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00016$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00017$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018872C00018$$" ON "XDB"."XDB$ALL_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$ANY" OF XMLTYPE   (	REF ("XMLDATA"."PROPERTY"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."SMPL_TYPE_DECL") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."TYPE_REF") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."PROPREF_REF") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "any" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004839" ON "XDB"."XDB$ANY" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018994C00004$$" ON "XDB"."XDB$ANY" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018994C00005$$" ON "XDB"."XDB$ANY" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018994C00007$$" ON "XDB"."XDB$ANY" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018994C00031$$" ON "XDB"."XDB$ANY" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018994C00032$$" ON "XDB"."XDB$ANY" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018994C00033$$" ON "XDB"."XDB$ANY" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$ANYATTR" OF XMLTYPE   (	REF ("XMLDATA"."PROPERTY"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."SMPL_TYPE_DECL") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."TYPE_REF") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."PROPREF_REF") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "anyAttribute" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004838" ON "XDB"."XDB$ANYATTR" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018980C00004$$" ON "XDB"."XDB$ANYATTR" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018980C00005$$" ON "XDB"."XDB$ANYATTR" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018980C00007$$" ON "XDB"."XDB$ANYATTR" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018980C00031$$" ON "XDB"."XDB$ANYATTR" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018980C00032$$" ON "XDB"."XDB$ANYATTR" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018980C00033$$" ON "XDB"."XDB$ANYATTR" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$ATTRGROUP_DEF" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "attributeGroup" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANY_ATTRS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ATTR_GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004842" ON "XDB"."XDB$ATTRGROUP_DEF" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00004$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00005$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00007$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00010$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00011$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00012$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00013$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00014$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019036C00015$$" ON "XDB"."XDB$ATTRGROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$ATTRGROUP_REF" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."ATTRGROUP_REF") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "attributeGroup" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004843" ON "XDB"."XDB$ATTRGROUP_REF" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019056C00004$$" ON "XDB"."XDB$ATTRGROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019056C00005$$" ON "XDB"."XDB$ATTRGROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019056C00007$$" ON "XDB"."XDB$ATTRGROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019056C00012$$" ON "XDB"."XDB$ATTRGROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019056C00013$$" ON "XDB"."XDB$ATTRGROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019056C00014$$" ON "XDB"."XDB$ATTRGROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$ATTRIBUTE" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."SMPL_TYPE_DECL") WITH ROWID, 
	REF ("XMLDATA"."TYPE_REF") WITH ROWID, 
	REF ("XMLDATA"."PROPREF_REF") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "attribute" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004837" ON "XDB"."XDB$ATTRIBUTE" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018966C00004$$" ON "XDB"."XDB$ATTRIBUTE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018966C00005$$" ON "XDB"."XDB$ATTRIBUTE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018966C00007$$" ON "XDB"."XDB$ATTRIBUTE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018966C00031$$" ON "XDB"."XDB$ATTRIBUTE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018966C00032$$" ON "XDB"."XDB$ATTRIBUTE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018966C00033$$" ON "XDB"."XDB$ATTRIBUTE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$CDBPORTS" 
   (	"PDB" NUMBER, 
	"SERVICE" NUMBER, 
	"PORT" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$CHECKOUTS" 
   (	"VCRUID" RAW(16), 
	"WORKSPACEID" NUMBER(*,0), 
	"VERSION" RAW(16), 
	"ACTID" NUMBER(*,0), 
	 CONSTRAINT "COKEY" PRIMARY KEY ("VCRUID", "WORKSPACEID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."COKEY" ON "XDB"."XDB$CHECKOUTS" ("VCRUID", "WORKSPACEID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$CHECKOUTS_VCRUID_IDX" ON "XDB"."XDB$CHECKOUTS" ("VCRUID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$CHECKOUTS_WORKSPACEID_IDX" ON "XDB"."XDB$CHECKOUTS" ("WORKSPACEID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$CHOICE_MODEL" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "choice" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ELEMENTS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."CHOICE_KIDS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SEQUENCE_KIDS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANYS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004834" ON "XDB"."XDB$CHOICE_MODEL" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00004$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00005$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00007$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00011$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00012$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00013$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00014$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00015$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00016$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00017$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018896C00018$$" ON "XDB"."XDB$CHOICE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$COLUMN_INFO" 
   (	"SCHEMA_REF" REF "SYS"."XMLTYPE" , 
	"ELNUM" NUMBER(*,0), 
	"COLNUM" NUMBER(*,0), 
	"PROPINFO" RAW(2000)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$COMPLEX_TYPE" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."BASE_TYPE") WITH ROWID, 
	REF ("XMLDATA"."ALL_KID") WITH ROWID, 
	REF ("XMLDATA"."CHOICE_KID") WITH ROWID, 
	REF ("XMLDATA"."SEQUENCE_KID") WITH ROWID, 
	REF ("XMLDATA"."GROUP_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ALL_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."CHOICE_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."SEQUENCE_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."GROUP_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ALL_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."EXTENSION"."CHOICE_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."EXTENSION"."SEQUENCE_KID") WITH ROWID, 
	REF ("XMLDATA"."COMPLEXCONTENT"."EXTENSION"."GROUP_KID") WITH ROWID, 
	REF ("XMLDATA"."SIMPLECONT"."RESTRICTION"."LCL_SMPL_DECL") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "complexType" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANY_ATTRS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ATTR_GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ANY_ATTRS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ATTR_GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."RESTRICTION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ANY_ATTRS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ATTR_GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."EXTENSION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEXCONTENT"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SUBTYPE_REFS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ANY_ATTRS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ATTR_GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."FRACTIONDIGITS"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."FRACTIONDIGITS"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."FRACTIONDIGITS"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."FRACTIONDIGITS"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."TOTALDIGITS"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."TOTALDIGITS"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."TOTALDIGITS"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."TOTALDIGITS"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MINLENGTH"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MINLENGTH"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MINLENGTH"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MINLENGTH"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAXLENGTH"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAXLENGTH"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAXLENGTH"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAXLENGTH"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."WHITESPACE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."WHITESPACE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."WHITESPACE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."WHITESPACE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."PERIOD"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."PERIOD"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."PERIOD"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."PERIOD"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."DURATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."DURATION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."DURATION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."DURATION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_INCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_INCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_INCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_INCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_INCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_INCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_INCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_INCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."PATTERN" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."ENUMERATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_EXCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_EXCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_EXCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MIN_EXCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_EXCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_EXCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_EXCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."MAX_EXCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."LENGTH"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."LENGTH"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."LENGTH"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."RESTRICTION"."LENGTH"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."ANY_ATTRS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."ATTR_GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."EXTENSION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLECONT"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004832" ON "XDB"."XDB$COMPLEX_TYPE" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00004$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00005$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00007$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00015$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00016$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00017$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00022$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00024$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00027$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00028$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00029$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00034$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00035$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00036$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00038$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00041$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00042$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00043$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00048$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00049$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00050$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00052$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00053$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00054$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00056$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00057$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00058$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00062$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00064$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00065$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00070$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00071$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00072$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00073$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00074$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00075$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00076$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00077$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00078$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00079$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00083$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00084$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00085$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00086$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00090$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00091$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00092$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00093$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00097$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00098$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00099$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00100$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00104$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00105$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00106$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00107$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00111$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00112$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00113$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00114$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00118$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00119$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00120$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00121$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00125$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00126$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00127$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00128$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00132$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00133$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00134$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00135$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00139$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00140$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00141$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00142$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00143$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00144$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00148$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00149$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00150$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00151$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00155$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00156$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00157$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00158$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00162$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00166$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00167$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00168$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00169$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00170$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00171$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00172$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00173$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018678C00174$$" ON "XDB"."XDB$COMPLEX_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE INDEX "XDB"."XDB$COMPLEX_TYPE_AK" ON "XDB"."XDB$COMPLEX_TYPE" (SYS_OP_R2O("XMLDATA"."ALL_KID")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$COMPLEX_TYPE_CK" ON "XDB"."XDB$COMPLEX_TYPE" (SYS_OP_R2O("XMLDATA"."CHOICE_KID")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$COMPLEX_TYPE_SK" ON "XDB"."XDB$COMPLEX_TYPE" (SYS_OP_R2O("XMLDATA"."SEQUENCE_KID")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$CONFIG" OF XMLTYPE 
 XMLTYPE STORE AS SECUREFILE BINARY XML (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
   XMLSCHEMA "http://xmlns.oracle.com/xdb/xdbconfig.xsd" ELEMENT "xdbconfig" DISALLOW NONSCHEMA 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE OR REPLACE NONEDITIONABLE TRIGGER "XDB"."XDB$CONFIG$xd" after delete or update on "XDB"."XDB$CONFIG" for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$CONFIG', :old.sys_nc_oid$, '9DB6E210DBE151C2E0531600000ACDF2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$CONFIG', :old.sys_nc_oid$, '9DB6E210DBE151C2E0531600000ACDF2', user ); END IF; END;
/
ALTER TRIGGER "XDB"."XDB$CONFIG$xd" ENABLE;
  CREATE OR REPLACE NONEDITIONABLE TRIGGER "XDB"."XDBCONFIG_VALIDATE" before insert or update
on xdb.XDB$CONFIG for each row
declare
  xdoc xmltype;
begin
  xdoc := :new.sys_nc_rowinfo$;
  xmltype.schemaValidate(xdoc);
end;
/
ALTER TRIGGER "XDB"."XDBCONFIG_VALIDATE" ENABLE;

CREATE UNIQUE INDEX "XDB"."SYS_C004880" ON "XDB"."XDB$CONFIG" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019462C00003$$" ON "XDB"."XDB$CONFIG" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$DBFS_VIRTUAL_FOLDER" 
   (	"HIDDEN_DEF" NUMBER DEFAULT 1, 
	"MOUNT_PATH" VARCHAR2(4000) NOT NULL ENABLE, 
	 CONSTRAINT "SNGLEROW" UNIQUE ("HIDDEN_DEF")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."SNGLEROW" ON "XDB"."XDB$DBFS_VIRTUAL_FOLDER" ("HIDDEN_DEF") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$DXPTAB" 
   (	"IDXOBJ#" NUMBER, 
	"PATHTABOBJ#" NUMBER NOT NULL ENABLE, 
	"FLAGS" NUMBER, 
	"RAWSIZE" NUMBER, 
	"PARAMETERS" "SYS"."XMLTYPE" , 
	"PENDTABOBJ#" NUMBER, 
	"SNAPSHOT" RAW(20), 
	"TABLESPACE" VARCHAR2(128), 
	"TABLE_ATTRS" VARCHAR2(4000), 
	"NBPENDTABOBJ#" NUMBER, 
	"NBERRTABOBJ#" NUMBER, 
	 CONSTRAINT "XDB$DXPTABPK" PRIMARY KEY ("IDXOBJ#")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 XMLTYPE COLUMN "PARAMETERS" STORE AS SECUREFILE CLOB (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_IL0000019405C00006$$" ON "XDB"."XDB$DXPTAB" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."XDB$DXPTABPK" ON "XDB"."XDB$DXPTAB" ("IDXOBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."XDB$IDXPTAB" ON "XDB"."XDB$DXPTAB" ("PATHTABOBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$D_LINK" 
   (	"SOURCE_ID" RAW(16), 
	"TARGET_ID" RAW(16), 
	"TARGET_PATH" VARCHAR2(4000), 
	"FLAGS" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE INDEX "XDB"."XDB$D_LINK_SOURCE_ID" ON "XDB"."XDB$D_LINK" ("SOURCE_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$D_LINK_TARGET_ID" ON "XDB"."XDB$D_LINK" ("TARGET_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$ELEMENT" OF XMLTYPE   (	REF ("XMLDATA"."PROPERTY"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."SMPL_TYPE_DECL") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."TYPE_REF") WITH ROWID, 
	REF ("XMLDATA"."PROPERTY"."PROPREF_REF") WITH ROWID, 
	REF ("XMLDATA"."CPLX_TYPE_DECL") WITH ROWID, 
	REF ("XMLDATA"."HEAD_ELEM_REF") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "element" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PROPERTY"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SUBS_GROUP_REFS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNIQUES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."KEYS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."KEYREFS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004836" ON "XDB"."XDB$ELEMENT" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00004$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00005$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00007$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00031$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00032$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00033$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00058$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00067$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00068$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018944C00069$$" ON "XDB"."XDB$ELEMENT" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE INDEX "XDB"."XDB$ELEMENT_HER" ON "XDB"."XDB$ELEMENT" (SYS_OP_R2O("XMLDATA"."HEAD_ELEM_REF")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$ELEMENT_PR" ON "XDB"."XDB$ELEMENT" (SYS_OP_R2O("XMLDATA"."PROPERTY"."PROPREF_REF")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$ELEMENT_PROPNAME" ON "XDB"."XDB$ELEMENT" ("XMLDATA"."PROPERTY"."NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$ELEMENT_PROPNUMBER" ON "XDB"."XDB$ELEMENT" ("XMLDATA"."PROPERTY"."PROP_NUMBER") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$ELEMENT_PS" ON "XDB"."XDB$ELEMENT" (SYS_OP_R2O("XMLDATA"."PROPERTY"."PARENT_SCHEMA")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$ELEMENT_TR" ON "XDB"."XDB$ELEMENT" (SYS_OP_R2O("XMLDATA"."PROPERTY"."TYPE_REF")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$GROUP_DEF" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."ALL_KID") WITH ROWID, 
	REF ("XMLDATA"."CHOICE_KID") WITH ROWID, 
	REF ("XMLDATA"."SEQUENCE_KID") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "group" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004840" ON "XDB"."XDB$GROUP_DEF" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019008C00004$$" ON "XDB"."XDB$GROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019008C00005$$" ON "XDB"."XDB$GROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019008C00007$$" ON "XDB"."XDB$GROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019008C00013$$" ON "XDB"."XDB$GROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019008C00014$$" ON "XDB"."XDB$GROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019008C00015$$" ON "XDB"."XDB$GROUP_DEF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$GROUP_REF" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."GROUPREF_REF") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "group" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004841" ON "XDB"."XDB$GROUP_REF" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019022C00004$$" ON "XDB"."XDB$GROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019022C00005$$" ON "XDB"."XDB$GROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019022C00007$$" ON "XDB"."XDB$GROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019022C00014$$" ON "XDB"."XDB$GROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019022C00015$$" ON "XDB"."XDB$GROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019022C00016$$" ON "XDB"."XDB$GROUP_REF" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$H_INDEX" 
   (	"OID" RAW(16), 
	"ACL_ID" RAW(16), 
	"OWNER_ID" RAW(16), 
	"FLAGS" RAW(4), 
	"CHILDREN" BLOB
   ) PCTFREE 99 PCTUSED 1 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 LOB ("CHILDREN") STORE AS BASICFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE LOGGING 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_IL0000018460C00005$$" ON "XDB"."XDB$H_INDEX" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE INDEX "XDB"."XDB$H_INDEX_OID_I" ON "XDB"."XDB$H_INDEX" ("OID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$H_LINK" OF "XDB"."XDB$LINK_T" 
   ( CONSTRAINT "XDB_PK_H_LINK" PRIMARY KEY ("PARENT_OID", "NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) OIDINDEX  ( PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ) 
 PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."SYS_C004830" ON "XDB"."XDB$H_LINK" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB_H_LINK_CHILD_OID" ON "XDB"."XDB$H_LINK" ("CHILD_OID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."XDB_PK_H_LINK" ON "XDB"."XDB$H_LINK" ("PARENT_OID", "NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$IMPORT_NM_INFO" 
   (	"NMSPCURI" VARCHAR2(2000), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$IMPORT_PT_INFO" 
   (	"PATH" RAW(2000), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$IMPORT_QN_INFO" 
   (	"NMSPCID" RAW(8), 
	"LOCALNAME" VARCHAR2(2000), 
	"FLAGS" RAW(4), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$IMPORT_TT_INFO" 
   (	"GUID" RAW(16), 
	"NMSPCID" RAW(8), 
	"LOCALNAME" VARCHAR2(2000), 
	"FLAGS" RAW(4), 
	"ID" RAW(8)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$MOUNTS" 
   (	"DOBJ#" NUMBER, 
	"DPATH" VARCHAR2(4000), 
	"SOBJ#" NUMBER, 
	"SPATH" VARCHAR2(4000), 
	"FLAGS" NUMBER
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$NLOCKS" OF "XDB"."XDB$NLOCKS_T" 
 OIDINDEX  ( PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ) 
 PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."SYS_C004846" ON "XDB"."XDB$NLOCKS" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$NLOCKS_CHILD_NAME_IDX" ON "XDB"."XDB$NLOCKS" ("CHILD_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$NLOCKS_PARENT_OID_IDX" ON "XDB"."XDB$NLOCKS" ("PARENT_OID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$NLOCKS_RAWTOKEN_IDX" ON "XDB"."XDB$NLOCKS" ("RAWTOKEN") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$NONCEKEY" 
   (	"NONCEKEY" CHAR(32)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$PATH_INDEX_PARAMS" 
   (	"MOUNT_POINT" VARCHAR2(2000), 
	"ENUM_COL_CLAUSE" VARCHAR2(2000), 
	"NAME" VARCHAR2(128), 
	"CONNECT_CLAUSE" VARCHAR2(2000)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."XDB$RCLIST_V" ("RCLIST") AS 
  (select rclist from xdb.xdb$root_info);
;

CREATE TABLE "XDB"."XDB$REPOS" 
   (	"OBJ#" NUMBER NOT NULL ENABLE, 
	"FLAGS" NUMBER, 
	"ROOTINFO#" NUMBER, 
	"HINDEX#" NUMBER, 
	"HLINK#" NUMBER, 
	"RESOURCE#" NUMBER, 
	"ACL#" NUMBER, 
	"CONFIG#" NUMBER, 
	"DLINK#" NUMBER, 
	"NLOCKS#" NUMBER, 
	"STATS#" NUMBER, 
	"CHECKOUTS#" NUMBER, 
	"RESCONFIG#" NUMBER, 
	"WKSPC#" NUMBER, 
	"VERSHIST#" NUMBER, 
	"PARAMS" "SYS"."XMLTYPE" 
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 XMLTYPE COLUMN "PARAMS" STORE AS SECUREFILE BINARY XML (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ALLOW NONSCHEMA DISALLOW ANYSCHEMA ;
;

CREATE TABLE "XDB"."XDB$RESCONFIG" OF XMLTYPE 
 XMLTYPE STORE AS SECUREFILE BINARY XML (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
   XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBResConfig.xsd" ELEMENT "ResConfig" DISALLOW NONSCHEMA 
  PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE OR REPLACE NONEDITIONABLE TRIGGER "XDB"."XDB$RESCONFIG$xd" after delete or update on "XDB"."XDB$RESCONFIG" for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, '9DB6E210D8A851C2E0531600000ACDF2' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$RESCONFIG', :old.sys_nc_oid$, '9DB6E210D8A851C2E0531600000ACDF2', user ); END IF; END;
/
ALTER TRIGGER "XDB"."XDB$RESCONFIG$xd" ENABLE;

CREATE UNIQUE INDEX "XDB"."SYS_C004850" ON "XDB"."XDB$RESCONFIG" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019350C00003$$" ON "XDB"."XDB$RESCONFIG" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$RESOURCE" OF XMLTYPE   (	REF ("XMLDATA"."XMLREF") WITH ROWID, 
	REF ("XMLDATA"."XMLREF") ALLOW PRIMARY KEY
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBResource.xsd" ELEMENT "Resource" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("XMLDATA"."XMLLOB") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("XMLDATA"."RESEXTRA") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."PARENTS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SBRESEXTRA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("XMLDATA"."ATTRCOPY") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 LOB ("XMLDATA"."CTSCOPY") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RCLIST"."OID" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004845" ON "XDB"."XDB$RESOURCE" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00004$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00005$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00025$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00027$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00030$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00031$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00033$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00034$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019124C00037$$" ON "XDB"."XDB$RESOURCE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE INDEX "XDB"."XDB$RESOURCE_ACLOID_IDX" ON "XDB"."XDB$RESOURCE" ("XMLDATA"."ACLOID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."XDB$RESOURCE_OID_INDEX" ON "XDB"."XDB$RESOURCE" (SYS_OP_R2O("XMLDATA"."XMLREF")) 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDBHI_IDX" ON "XDB"."XDB$RESOURCE" (OBJECT_VALUE) 
   INDEXTYPE IS "XDB"."XDBHI_IDXTYP" ;
;

CREATE TABLE "XDB"."XDB$ROOT_INFO" 
   (	"RESOURCE_ROOT" ROWID, 
	"RCLIST" RAW(2000), 
	"FTP_PORT" NUMBER(5,0), 
	"FTP_PROTOCOL" VARCHAR2(4000), 
	"HTTP_PORT" NUMBER(5,0), 
	"HTTP_PROTOCOL" VARCHAR2(4000), 
	"HTTP_HOST" VARCHAR2(4000), 
	"HTTP2_PORT" NUMBER(5,0), 
	"HTTP2_PROTOCOL" VARCHAR2(4000), 
	"HTTP2_HOST" VARCHAR2(4000), 
	"NFS_PORT" NUMBER(5,0), 
	"NFS_PROTOCOL" VARCHAR2(4000), 
	"RHTTP_PORT" NUMBER(5,0), 
	"RHTTP_PROTOCOL" VARCHAR2(4000), 
	"RHTTP_HOST" VARCHAR2(4000), 
	"RHTTPS_PORT" NUMBER(5,0), 
	"RHTTPS_PROTOCOL" VARCHAR2(4000), 
	"RHTTPS_HOST" VARCHAR2(4000)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE OR REPLACE FORCE NONEDITIONABLE VIEW "XDB"."XDB$ROOT_INFO_V" ("RESOURCE_ROOT", "RCLIST", "FTP_PORT", "FTP_PROTOCOL", "HTTP_PORT", "HTTP_PROTOCOL", "HTTP_HOST", "HTTP2_PORT", "HTTP2_PROTOCOL", "HTTP2_HOST", "NFS_PORT", "NFS_PROTOCOL", "RHTTP_PORT", "RHTTP_PROTOCOL", "RHTTP_HOST", "RHTTPS_PORT", "RHTTPS_PROTOCOL", "RHTTPS_HOST") AS 
  select "RESOURCE_ROOT","RCLIST","FTP_PORT","FTP_PROTOCOL","HTTP_PORT","HTTP_PROTOCOL","HTTP_HOST","HTTP2_PORT","HTTP2_PROTOCOL","HTTP2_HOST","NFS_PORT","NFS_PROTOCOL","RHTTP_PORT","RHTTP_PROTOCOL","RHTTP_HOST","RHTTPS_PORT","RHTTPS_PROTOCOL","RHTTPS_HOST" from xdb.xdb$root_info;
;

CREATE TABLE "XDB"."XDB$SCHEMA" OF XMLTYPE 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "schema" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ELEMENTS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SIMPLE_TYPE" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."COMPLEX_TYPES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ATTRIBUTES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."IMPORTS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."INCLUDES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATIONS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ATTRGROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."NOTATIONS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004844" ON "XDB"."XDB$SCHEMA" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00004$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00005$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00015$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00016$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00017$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00018$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00019$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00020$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00022$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00023$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00026$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00027$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019070C00031$$" ON "XDB"."XDB$SCHEMA" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE INDEX "XDB"."XDB$SCHEMA_URL" ON "XDB"."XDB$SCHEMA" ("XMLDATA"."SCHEMA_URL") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$SEQUENCE_MODEL" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "sequence" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ELEMENTS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."CHOICE_KIDS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SEQUENCE_KIDS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANYS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."GROUPS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004835" ON "XDB"."XDB$SEQUENCE_MODEL" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00004$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00005$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00007$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00011$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00012$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00013$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00014$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00015$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00016$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00017$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018920C00018$$" ON "XDB"."XDB$SEQUENCE_MODEL" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$SIMPLE_TYPE" OF XMLTYPE   (	REF ("XMLDATA"."PARENT_SCHEMA") WITH ROWID, 
	REF ("XMLDATA"."RESTRICTION"."BASE_TYPE") WITH ROWID, 
	REF ("XMLDATA"."RESTRICTION"."LCL_SMPL_DECL") WITH ROWID, 
	REF ("XMLDATA"."LIST_TYPE"."TYPE_REF") WITH ROWID, 
	REF ("XMLDATA"."LIST_TYPE"."SIMPLE_TYPE") WITH ROWID
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/XDBSchema.xsd" ELEMENT "simpleType" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."FRACTIONDIGITS"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."FRACTIONDIGITS"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."FRACTIONDIGITS"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."FRACTIONDIGITS"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."TOTALDIGITS"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."TOTALDIGITS"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."TOTALDIGITS"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."TOTALDIGITS"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MINLENGTH"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MINLENGTH"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MINLENGTH"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MINLENGTH"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAXLENGTH"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAXLENGTH"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAXLENGTH"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAXLENGTH"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."LENGTH"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."LENGTH"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."LENGTH"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."LENGTH"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."WHITESPACE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."WHITESPACE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."WHITESPACE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."WHITESPACE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."PERIOD"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."PERIOD"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."PERIOD"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."PERIOD"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."DURATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."DURATION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."DURATION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."DURATION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_INCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_INCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_INCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_INCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_INCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_INCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_INCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_INCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_EXCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_EXCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_EXCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MIN_EXCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_EXCLUSIVE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_EXCLUSIVE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_EXCLUSIVE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."MAX_EXCLUSIVE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."PATTERN" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."ENUMERATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."RESTRICTION"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."LIST_TYPE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."LIST_TYPE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."LIST_TYPE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."LIST_TYPE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNION_TYPE"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNION_TYPE"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNION_TYPE"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNION_TYPE"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNION_TYPE"."SIMPLE_TYPES" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."UNION_TYPE"."TYPE_REFS" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."SYS_XDBPD$" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."APPINFO" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."ANNOTATION"."DOCUMENTATION" STORE AS SECUREFILE LOB 
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  CACHE  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_C004831" ON "XDB"."XDB$SIMPLE_TYPE" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00004$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00005$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00007$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00011$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00016$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00017$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00018$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00019$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00023$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00024$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00025$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00026$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00030$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00031$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00032$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00033$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00037$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00038$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00039$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00040$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00044$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00045$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00046$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00047$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00051$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00052$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00053$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00054$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00058$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00059$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00060$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00061$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00065$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00066$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00067$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00068$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00072$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00073$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00074$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00075$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00079$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00080$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00081$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00082$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00086$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00087$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00088$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00089$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00093$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00094$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00095$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00096$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00100$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00101$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00102$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00103$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00104$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00106$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00107$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00108$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00109$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00114$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00115$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00116$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00117$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00119$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00120$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00121$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00122$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000018536C00123$$" ON "XDB"."XDB$SIMPLE_TYPE" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$STATS" OF XMLTYPE   ( CONSTRAINT "STATS_PK" PRIMARY KEY ("XMLDATA"."RESOID")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) 
  XMLSCHEMA "http://xmlns.oracle.com/xdb/stats.xsd" ELEMENT "ContainerStats" PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 VARRAY "XMLEXTRA"."NAMESPACES" STORE AS BASICFILE LOB "NAMESPACES203_L"
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  CACHE 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLEXTRA"."EXTRADATA" STORE AS BASICFILE LOB "EXTRADATA202_L"
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  CACHE 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 VARRAY "XMLDATA"."SYS_XDBPD$" STORE AS BASICFILE LOB "SYS_XDBPD$201_L"
  ( TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  CACHE 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE OR REPLACE NONEDITIONABLE TRIGGER "XDB"."XDB$STATS$xd" after delete or update on "XDB"."XDB$STATS" for each row BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','XDB$STATS', :old.sys_nc_oid$, 'E8637ACC309F27DCE0530100007F32DC' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','XDB$STATS', :old.sys_nc_oid$, 'E8637ACC309F27DCE0530100007F32DC', user ); END IF; END;
/
ALTER TRIGGER "XDB"."XDB$STATS$xd" ENABLE;

CREATE UNIQUE INDEX "XDB"."STATS_PK" ON "XDB"."XDB$STATS" ("XMLDATA"."RESOID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_C00621904" ON "XDB"."XDB$STATS" ("SYS_NC_OID$") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0001637073C00004$$" ON "XDB"."XDB$STATS" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0001637073C00005$$" ON "XDB"."XDB$STATS" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0001637073C00007$$" ON "XDB"."XDB$STATS" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
;

CREATE TABLE "XDB"."XDB$TSETMAP" 
   (	"GUID" RAW(16) NOT NULL ENABLE, 
	"TYPE" NUMBER NOT NULL ENABLE, 
	"OBJ#" NUMBER NOT NULL ENABLE, 
	 CONSTRAINT "XDB$TSETMAP_UNIQ1" UNIQUE ("GUID", "TYPE")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."XDB$TSETMAP_UNIQ1" ON "XDB"."XDB$TSETMAP" ("GUID", "TYPE") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$TTSET" 
   (	"GUID" RAW(16), 
	"TOKSUF" VARCHAR2(26), 
	"FLAGS" NUMBER, 
	"OBJ#" NUMBER, 
	 UNIQUE ("OBJ#")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."SYS_C004828" ON "XDB"."XDB$TTSET" ("OBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$XDB_READY" 
   (	"DATA" CLOB
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 LOB ("DATA") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;
;

CREATE GLOBAL TEMPORARY TABLE "XDB"."XDB$XIDX_IMP_T" 
   (	"INDEX_NAME" VARCHAR2(138), 
	"SCHEMA_NAME" VARCHAR2(138), 
	"ID" VARCHAR2(40), 
	"DATA" CLOB, 
	"GRPPOS" NUMBER
   ) ON COMMIT PRESERVE ROWS 
 LOB ("DATA") STORE AS BASICFILE (
  ENABLE STORAGE IN ROW CHUNK 8192 RETENTION 
  NOCACHE ) ;
;

CREATE TABLE "XDB"."XDB$XIDX_PARAM_T" 
   (	"USERID" NUMBER, 
	"PARAM_NAME" VARCHAR2(128), 
	"PARAMSTR" CLOB
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 LOB ("PARAMSTR") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_IL0000019415C00003$$" ON "XDB"."XDB$XIDX_PARAM_T" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."XDB$IDXPARAM" ON "XDB"."XDB$XIDX_PARAM_T" ("USERID", "PARAM_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$XIDX_PART_TAB" 
   (	"IDXOBJ#" NUMBER NOT NULL ENABLE, 
	"PART_NAME" VARCHAR2(128) NOT NULL ENABLE, 
	"TABLESPACE" VARCHAR2(128), 
	"PARTITION_ATTRS" VARCHAR2(4000), 
	 CONSTRAINT "XDB$XIDX_PART_TAB_PK" PRIMARY KEY ("IDXOBJ#", "PART_NAME")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE UNIQUE INDEX "XDB"."XDB$XIDX_PART_TAB_PK" ON "XDB"."XDB$XIDX_PART_TAB" ("IDXOBJ#", "PART_NAME") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$XTAB" 
   (	"IDXOBJ#" NUMBER NOT NULL ENABLE, 
	"GROUPNAME" NVARCHAR2(128) NOT NULL ENABLE, 
	"XMLTABOBJ#" NUMBER NOT NULL ENABLE, 
	"PTABOBJ#" NUMBER, 
	"XPATH" VARCHAR2(4000) NOT NULL ENABLE, 
	"XQUERY" CLOB, 
	"FLAGS" NUMBER, 
	"PARAMETERS" "SYS"."XMLTYPE" , 
	"GRPPOS" NUMBER, 
	"DEPGRPPOS" NUMBER, 
	"SEGATTRS" VARCHAR2(4000), 
	 CONSTRAINT "XDB$XTABPK" PRIMARY KEY ("IDXOBJ#", "GROUPNAME", "XMLTABOBJ#")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX"  ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
 LOB ("XQUERY") STORE AS SECUREFILE (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) 
 XMLTYPE COLUMN "PARAMETERS" STORE AS SECUREFILE CLOB (
  TABLESPACE "SYSAUX" ENABLE STORAGE IN ROW CHUNK 8192
  NOCACHE LOGGING  NOCOMPRESS  KEEP_DUPLICATES 
  STORAGE(INITIAL 106496 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)) ;

CREATE UNIQUE INDEX "XDB"."SYS_IL0000019436C00006$$" ON "XDB"."XDB$XTAB" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE UNIQUE INDEX "XDB"."SYS_IL0000019436C00009$$" ON "XDB"."XDB$XTAB" (
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" 
  PARALLEL (DEGREE 0 INSTANCES 0) ;
  CREATE INDEX "XDB"."XDB$IDXXTAB_1" ON "XDB"."XDB$XTAB" ("IDXOBJ#", "GROUPNAME", "PTABOBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE INDEX "XDB"."XDB$IDXXTAB_2" ON "XDB"."XDB$XTAB" ("IDXOBJ#", "DEPGRPPOS", "XMLTABOBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
  CREATE UNIQUE INDEX "XDB"."XDB$XTABPK" ON "XDB"."XDB$XTAB" ("IDXOBJ#", "GROUPNAME", "XMLTABOBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$XTABCOLS" 
   (	"IDXOBJ#" NUMBER NOT NULL ENABLE, 
	"GROUPNAME" NVARCHAR2(128) NOT NULL ENABLE, 
	"XMLTABOBJ#" NUMBER NOT NULL ENABLE, 
	"COLNAME" NVARCHAR2(2000) NOT NULL ENABLE, 
	"COLTYPE" NVARCHAR2(100) NOT NULL ENABLE, 
	"XPATH" VARCHAR2(4000) NOT NULL ENABLE, 
	"FLAGS" NUMBER NOT NULL ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE INDEX "XDB"."XDB$IDXTABCOLS_1" ON "XDB"."XDB$XTABCOLS" ("IDXOBJ#", "GROUPNAME", "XMLTABOBJ#") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB$XTABNMSP" 
   (	"IDXOBJ#" NUMBER NOT NULL ENABLE, 
	"GROUPNAME" NVARCHAR2(128) NOT NULL ENABLE, 
	"XMLTABOBJ#" NUMBER NOT NULL ENABLE, 
	"PREFIX" NVARCHAR2(128), 
	"NAMESPACE" NVARCHAR2(2000), 
	"FLAGS" NUMBER NOT NULL ENABLE
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;

CREATE INDEX "XDB"."XDB$IDXTABNMSP_1" ON "XDB"."XDB$XTABNMSP" ("IDXOBJ#", "GROUPNAME", "XMLTABOBJ#", "FLAGS") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE TABLE "XDB"."XDB_INDEX_DDL_CACHE" 
   (	"ROOT_TABLE_NAME" VARCHAR2(128), 
	"ROOT_TABLE_OWNER" VARCHAR2(128), 
	"ROOT_COL_NAME" VARCHAR2(128), 
	"TABLE_NAME" VARCHAR2(128), 
	"TABLE_OWNER" VARCHAR2(128), 
	"IDX_OWNER" VARCHAR2(128), 
	"IDX_TABLE_NAME" VARCHAR2(128), 
	"IDX_NAME" VARCHAR2(128), 
	"IDX_TYPE" VARCHAR2(27), 
	"CONSTR_NAME" VARCHAR2(128), 
	"CONSTR_OWNER" VARCHAR2(128)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 
 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSAUX" ;
;

CREATE OR REPLACE function XDB.contentSchemaIs wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
1eb 154
7PCJFPfZ1LSmNAj4ehpET9E/1LAwg43IfyAVfC8C2v7qbnVnGARU2q2LykkxF/W8Z2XplOb8
4aSXterwtutN/Rm5QZqwEiCxwlyedMG7BXPAmMZOsUOSoSQMr+fbL/hTuTTr+amUNGr2ZJT+
cHbwtNSF6CM90MtzdkuXpjV5Aje6D4xdsund3My0V3CG82/fS2YeL3nWGXSOH49Nb+8A9QUj
kBUCK1bLgBXryIl/g/SgN37Njstg08XMhhbRsB5JczFg4Fx8YQ1s9iFa+jrjKMwCMA/w1oQZ
9oKyqrWZxcFiQHqOanfbqmoDX1jDK68l2FE9xgWWMHB5sw==
;

CREATE OR REPLACE FUNCTION XDB.get_xdb_tablespace wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
f3 107
yGrBq9SjQ7pfVFABbFo0k+ST6bYwgwFK7csVfHRGWPiOHMhFf0tgdDp/oE0u3dwOWcyZlJkd
06QwzwkYRjYlLryYcsTLK/glk1MzhM+HRVegVTuqaAXHKEYiyALWFExao6xddA6gOf2WXAI0
t6v73U3shiJX0BunYJGeeGMu+qFflCcommCgwtRGCLnQDRvqHU8w8wQ+ew0u11c67/xUymMH
u2qikzUZBCpJkR9aC9HCjvhH+TdtUsuj78mW0cRneQ==
;

CREATE OR REPLACE function XDB.under_path_func wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
49f 32b
k/KtW5jxRk5MAOCs9qJ+rwr+UCkwg41ezCCDfC8Zgp0GHHvzFImUoM1r4wfIV3A+tPfNftI+
Ua9cUBGs8XxNdyyaAx1sE2EmbY6tM7/+ELy70TgVz+mt1oQts1xFD3hCkjAWZYAvvZuHRQoB
GrkLZUap2yf7VpP/4wTmKBm12xwbP05GnaXbMOd3A9t6pT4B+5M6J4Gqz9OCqWWP9KxcfMcI
TFCJ0QfKahE/vAYOSePyNtogN/KMOPL7JPMmc92CNeYDnHFZLzOYZZx8HVps4t1jjhfkQx7d
Dl9bFAEZ8eTzsj5OUZnkQEpIxk9ifmj05/YmBdncI4JlxuES5/0I4rqJAnpapy2EAP7N3dNE
A2NZs7dXzNG83qKIUpJRekh4SztrtZusPJisObXjM9lRs7CL0yBun2O77l/YfJnrERGSB9Qt
FBhnYqUGYTIXAyCyKjj71C6D2QU2jJL/Gsf6ff5VjpLxotvqyJiVkqFqC1wir95OuLewmHkI
HcBNEzI93VIFXchDBVUbYi20KSDrXXcjsAM5/MF7YmW2wMdj5fVMHOVZan+xjUCXgyoCmOsO
2fGN6TgWHEE4D3nZnjMe8h/Xk7nFTCvOH1hNkPkmv0uzMjzEKggEbTOoXRU8p1qXixcLWYHz
wVIKH9NDlnzxZZVk1iotBN+6r78LT7X3UpSbRkRiJVh/oDsDahszJIHXm5mcUgURg2vQU9tP
BuAQFxT3npy+o1eL20qyYYL0C2Z2WEdLL8HFKkazpfGtBA7VeW7XoAC7Yc+RlvNruQ9b+7H6
B+qfRRQx
;

CREATE OR REPLACE PROCEDURE XDB.xdb_datastore_proc(rid IN ROWID,
                                                   outlob IN OUT NOCOPY CLOB)
  AUTHID CURRENT_USER IS
BEGIN
  xdb.dbms_xdbt.xdb_datastore_proc(rid, outlob);
END;

CREATE OR REPLACE function XDB.xdb$ExtName2IntName
  (schemaURL IN VARCHAR2, schemaOwner IN VARCHAR2 := '')
return varchar2 authid current_user deterministic
is external name "EXT2INT_NAME" library XMLSCHEMA_LIB with context
parameters (context, schemaURL OCIString, schemaOwner OCIString,
            return INDICATOR sb4, return OCIString);

CREATE OR REPLACE procedure XDB.xdb$InitXDBSchema
 is language C name "INIT_XDBSCHEMA"
 library XMLSCHEMA_LIB;

CREATE OR REPLACE procedure XDB.xdb$patchupDeleteSchema wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
75b 2c9
PgsK4fTQHksnxgNZMRyt9YydDVwwg2NczPYFfC8ZA6qVAI7FAy/JKDw1g6lWTwuyBWXxWbdJ
szI3In5QB8uSTr9KXngIiqIxRvDwrv4pufi5ag0r4etg7zT5zj+B5KWbztL4rVX5aLx+14br
M7EdgmbqZUTXuxc10V5GRXzcK2/qTYTIG1q4bArKpn3i6Ny+6VSw+m651WuXRd0NAxOr+z5I
UOH/sQE1Bc5oIaH9UquCHb/KUy3Yfp7V3v2MVcGnr+ECRPIXZtK0T95cSrEbesK7xxToR9RX
XNqk1RuSYNNIuFuOCf1X6vp45dn6dx2N6ilXydcqKzz34VSbL0icUPTu9DrLwwjTocVNiQLl
Pp4o6FMp3maJePBxqPAyYde7UxH0sKcBRH6WAuP5ixRTWfQR3/PjHZbMUT45u9wvV8Ooq5wr
27ANeThKuAYDwEBtof4vY2xDX/3GU40rLnMoGQi/1/fyID1uYZe9t12FXrFRoCoP4InebRFc
jGET+77E2QANHCs60JPGETQN3ZyhegSB+ROaiSxuADUVbIYiPfrcFND3JEYYcm/fBBBY+wVz
o6elPjYTCw3ayY8C0YhZUC5LROtPt5TP6W+06cBxuumq1ckNVlhc3F1xgqPSoyoBrOyy0xe4
c0UPsTjnLO7Hz05D9gQcqrtg3pZq2qgA+pkY73+oA+lncpUHJHeYJi8=
;

CREATE OR REPLACE procedure XDB.xdb$paTchupschema wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
4c48 77a
/zF/rlBVDdIfVeDVcY70bwxsI4Ewg81xBUqM3wS5MkEVH9WyWswhWAXeK8DdDMhXlBPcwAJh
BfISXt5j5Qksnd+wcHxhqDemExbv8KxzLJ21qS30BlDmn9PvpZpPqs+SCI3P+Pm70Kq8ELUe
u2Q5Ydx/kuG0LLyPVTH+hWzmukv77ST70vNKqf2pmjh+kHDkyeEfXuaJB6SjDg5zvK1mxrLf
iuGbyOmp8Bb45tN7bMo4rUMMdpJYcZ/h7b9777Ub97K94Rf4U4yqT0segBzyiFKpZ2Ccptv1
a2qP0ax/nlryoWYsrB2FiLM4LEmXU8cObTXIMIn2E6gUFJ/QvXNELt3Xnlgjwb2BjEgIKVr3
n1IEa3VxI3yUcsiTsU4JJKD3ePDCPD71YiFsgF8/DGl8Yq4EcQQnLEMlj5vK/9x2G8wn69Lf
6U2LaAb0U38H3AqajYYRe59sQpP/AVh/t31p+PPr2FhDWSek2baF3eIt7FzCW3xLZDKuY8M+
frV3Pok8GDQDw6NIRUq0epV+9VpdGJeGUnBjL+W6TFwjJsQZpBq7AakcmmvK/2yClzPjKoDb
RxKozNmE8i7A6/cY4Mk71qYIMY3AbwNEzIC4M6HheHSmYlBDKNPzvmEBZYguXA6xyspnZ0NG
Na037/I1gNmYr0c4LBBuJarTBiM+zSC/y2ZCxHRikV3tuW/ngNSl1kY1Bv3hmemJYxLciP3r
aG9z/m+KxI89eoqaDKGn+2po+gKzX6xJvP83fyqjo5M7qIC5W2hSBSWJ404ZqJg6cDmO3EH/
qliaTWszqcShdj9p4QdzaKbRsefkkohuUFhGd+HU2R4ebULHcwSyyDurgsE2QpY4Ls3g1YDD
BcxFRJL3oaB56VzfTBswqkGg5dJNhz+QNXRy3ReZx4NmwFjoPKQCXs7NA9GhQgkbg/p98gos
2IjQE/IWJDwIFe/SfQ7soTOW6GjNY3TsHJbXZc+kcN2S3q6/iRTakMzM/+1mSj/0ysVPPrH8
kbc5Qi1sh0+muYaxurmSlK7vo6bj8+hSAfOj4J+A421Svph0Uq+tmowMEZukCmoAmmMiGYCj
80vsiTKnAtsiEwieNdnPcxIFAlHOPOihgxzMzOU59II4PE+gRfFb3SDR4/yX/xArJTrGQWLn
SiiYLoApR95UqAN34cL8kSfjpdE4UR1z6ZG6WKj4SRls3UHfUhbdmVtzAIlpZ0EXLWDdeF9T
ZlMfrH9isxWCcxbl4w5kcKDspmmI9e04S2hHJKxmq6hLJZ7KeItZj7XIaK3+/VAIXtJZA0i1
uiUNn8Wu4yKoko8h5U28mYR9VW3kVh4z4dMWMFFO9P89Q/8imQ3HxotTHq+CcQZMIAU6RkO2
p4KunJmWXQsioXVVajeUxJyuovkU44qqn/1JxsAKPuigVuP07kkcUil8hE50P7LdpyYSuJ3a
u6PsjsB+VFGm2ZE16BuoQOFt0GOr7CEqrFMl6DBypgPe/L51Gl2eQ3F8M0qsZdQ2nn5IxOrr
V1VtgdOBFGDMkCJ5781GDpDCHpWTR+By3rJ6fTsLcj4j1QJWm68TM/nB1z2VUZM7sochHLjs
kHziwdTiKT1hJcB4JotCCEUwiHn7qtGMDdQIPH5PDzz+2Y2GUBQOwRXwyWeximhGWRx6i1MI
tPoPiI15U5c9XqnWlXVQWA0dpXm/yR8K8FVxz62ymnHQudr9c0YehZjL+oDKkQ0pEwoy5dCM
Wvbom92qzX/FLOpuOtKHoA7Sr+hYfYlKfUugl6mN1WD2ATC88DND1OKzzL/wDdRaVdUZ/FJD
BUmDSsFbhYzQqkJA6wopiKvWZqEHRo/j+4UTabVcyicXFmppffMBFsVWraMW387iZm/abq4L
80Qz+Ja1HWlCnDE=
;

CREATE OR REPLACE function XDB.XMLIndexInsFunc
       return XDB.XMLIndexTab_t
authid current_user
pipelined using XDB.XMLIndexLoad_Imp_t;

CREATE OR REPLACE function XDB.XMLIndexLoadFunc(p IN SYS_REFCURSOR,
                                                flags NUMBER)
       return XDB.XMLIndexTab_t
authid current_user
parallel_enable (partition p by ANY)
pipelined using XDB.XMLIndexLoad_Imp_t;

CREATE SEQUENCE XDB.CLIENTID_SEQUENCE INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 10 NOORDER ;

CREATE SEQUENCE XDB.STATEID_RESTART_SEQUENCE INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 NOORDER ;

CREATE SEQUENCE XDB."XDB$NAMESUFF_SEQ" INCREMENT BY 1 MINVALUE 1 MAXVALUE 99999 CYCLE CACHE 20 NOORDER ;

CREATE SEQUENCE XDB."XDB$PROPNUM_SEQ" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 NOORDER ;

CREATE SEQUENCE XDB."XDB$TYPEID_SEQ" INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999999999999999999999999 NOCYCLE CACHE 20 NOORDER ;


